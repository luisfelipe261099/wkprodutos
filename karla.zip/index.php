<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WK Produtos de Limpeza | Soluções Profissionais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
    <!-- Antes da tag </head> -->
<link rel="stylesheet" href="form_styles.css">
<script src="form_validation.js"></script>
    <style>
        :root {
            --primary-blue: #005294;
            --secondary-blue: #0078d4;
            --accent-blue: #00a1ff;
            --dark-blue: #003b6f;
            --white: #ffffff;
            --off-white: #f8f9fa;
            --light-gray: #e9ecef;
            --medium-gray: #6c757d;
            --dark-gray: #343a40;
            --black: #212529;
            --success: #28a745;
            --whatsapp: #25d366;
            --box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }

        body {
            background-color: var(--off-white);
            color: var(--dark-gray);
            line-height: 1.6;
            overflow-x: hidden;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }

        .section-padding {
            padding: 80px 0;
        }

        .btn {
            display: inline-block;
            padding: 12px 24px;
            background-color: var(--primary-blue);
            color: var(--white);
            border: none;
            border-radius: 4px;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
            cursor: pointer;
            text-align: center;
            font-size: 16px;
            box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16);
        }

        .btn:hover {
            background-color: var(--dark-blue);
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.25);
        }

        .btn-outline {
            background-color: transparent;
            border: 2px solid var(--primary-blue);
            color: var(--primary-blue);
        }

        .btn-outline:hover {
            background-color: var(--primary-blue);
            color: var(--white);
        }

        .btn-white {
            background-color: var(--white);
            color: var(--primary-blue);
        }

        .btn-white:hover {
            background-color: var(--off-white);
            color: var(--dark-blue);
        }

        .section-title {
            font-size: 36px;
            font-weight: 700;
            color: var(--primary-blue);
            margin-bottom: 45px;
            text-align: center;
            position: relative;
        }

        .section-title:after {
            content: '';
            position: absolute;
            left: 50%;
            bottom: -15px;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background-color: var(--accent-blue);
        }
        /* Header Styles */
        .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            background-color: var(--white);
            box-shadow: var(--box-shadow);
            transition: var(--transition);
        }

        .header.scrolled {
            padding: 10px 0;
            background-color: rgba(255, 255, 255, 0.95);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
        }

        .logo-icon {
            font-size: 28px;
            color: var(--primary-blue);
            margin-right: 10px;
        }

        .logo-text {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary-blue);
        }

        .nav-menu {
            display: flex;
            list-style: none;
        }

        .nav-item {
            margin-left: 25px;
        }

        .nav-link {
            color: var(--dark-gray);
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition);
            padding: 5px 0;
            position: relative;
            font-size: 16px;
        }

        .nav-link:hover, .nav-link.active {
            color: var(--primary-blue);
        }

        .nav-link:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: var(--primary-blue);
            transition: var(--transition);
        }

        .nav-link:hover:after, .nav-link.active:after {
            width: 100%;
        }

        .mobile-nav-toggle {
            display: none;
            background: transparent;
            border: none;
            color: var(--primary-blue);
            font-size: 24px;
            cursor: pointer;
            z-index: 1001;
        }

        /* Hero Section */
        .hero {
            background: linear-gradient(rgba(0, 82, 148, 0.8), rgba(0, 59, 111, 0.9)), url('https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80') center/cover no-repeat;
            min-height: 100vh;
            color: var(--white);
            display: flex;
            align-items: center;
            text-align: left;
            position: relative;
            overflow: hidden;
        }

        .hero:before {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 150px;
            background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 320'%3E%3Cpath fill='%23ffffff' fill-opacity='1' d='M0,224L48,213.3C96,203,192,181,288,170.7C384,160,480,160,576,181.3C672,203,768,245,864,234.7C960,224,1056,160,1152,138.7C1248,117,1344,139,1392,149.3L1440,160L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z'%3E%3C/path%3E%3C/svg%3E") no-repeat;
            background-size: cover;
        }

        .hero-content {
            max-width: 650px;
            padding-top: 120px;
        }

        .hero-title {
            font-size: 48px;
            font-weight: 700;
            margin-bottom: 20px;
            line-height: 1.2;
        }

        .hero-subtitle {
            font-size: 20px;
            margin-bottom: 30px;
            opacity: 0.9;
        }

        .hero-buttons {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .hero-image {
            position: absolute;
            right: -5%;
            bottom: 10%;
            width: 45%;
            max-width: 600px;
            animation: float 6s ease-in-out infinite;
        }
        .checkbox-group label {
    color: #212529 !important; /* Preto */
    font-weight: 500;
}

/* Torna a categoria mais visível */
.checkbox-category {
    color: #005294 !important; /* Azul primário - pode ajustar para sua preferência */
    font-weight: 600;
}

/* Melhora o contraste para os checkboxes */
.checkbox-container {
    background-color: #f8f9fa; /* Fundo claro */
    border: 1px solid #e9ecef;
    border-radius: 5px;
    padding: 15px;
}

/* Garante que os checkboxes sejam facilmente clicáveis */
.checkbox-group input[type="checkbox"] {
    width: 18px;
    height: 18px;
    margin-right: 10px;
}

/* Melhora a aparência ao passar o mouse */
.checkbox-group:hover {
    background-color: #e9ecef;
    border-radius: 4px;
    transition: background-color 0.2s;
}
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
            100% { transform: translateY(0px); }
        }
        /* About Section */
        .about {
            position: relative;
            background-color: var(--white);
        }

        .about-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            align-items: center;
        }

        .about-image {
            position: relative;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: var(--box-shadow);
        }

        .about-image img {
            width: 100%;
            height: auto;
            display: block;
            transition: var(--transition);
        }

        .about-content h2 {
            font-size: 36px;
            margin-bottom: 25px;
            color: var(--primary-blue);
        }

        .about-text {
            margin-bottom: 30px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 30px;
            margin-top: 40px;
        }

        .stat-item {
            text-align: center;
            background-color: var(--off-white);
            padding: 25px;
            border-radius: 10px;
            box-shadow: var(--box-shadow);
            transition: var(--transition);
        }

        .stat-item:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        }

        .stat-number {
            font-size: 36px;
            font-weight: 700;
            color: var(--primary-blue);
            margin-bottom: 10px;
        }

        .stat-text {
            font-size: 16px;
            color: var(--medium-gray);
        }

        /* Services Section */
        .services {
            background-color: var(--off-white);
            position: relative;
        }

        .service-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 30px;
        }

        .service-card {
            background-color: var(--white);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: var(--box-shadow);
            transition: var(--transition);
        }

        .service-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
        }

        .service-icon {
            width: 70px;
            height: 70px;
            margin: 0 auto;
            background-color: var(--primary-blue);
            color: var(--white);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
            margin-bottom: 20px;
        }

        .service-content {
            padding: 30px;
            text-align: center;
        }

        .service-title {
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--primary-blue);
        }

        .service-text {
            margin-bottom: 20px;
            color: var(--medium-gray);
        }

        /* Products Section */
        .products {
            background-color: var(--white);
        }

        .category-tabs {
            display: flex;
            justify-content: center;
            margin-bottom: 40px;
            flex-wrap: wrap;
            gap: 10px;
        }

        .category-tab {
            padding: 10px 20px;
            border: 2px solid var(--primary-blue);
            background-color: var(--white);
            color: var(--primary-blue);
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            border-radius: 5px;
        }

        .category-tab.active,
        .category-tab:hover {
            background-color: var(--primary-blue);
            color: var(--white);
        }

        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 30px;
        }

        .product-card {
            background-color: var(--white);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: var(--box-shadow);
            transition: var(--transition);
            position: relative;
            border: 1px solid var(--light-gray);
        }

        .product-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
        }

        .product-image {
            height: 200px;
            background-color: var(--off-white);
            overflow: hidden;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .product-image img {
            max-width: 100%;
            max-height: 100%;
            transition: var(--transition);
        }

        .product-card:hover .product-image img {
            transform: scale(1.1);
        }

        .product-badge {
            position: absolute;
            top: 15px;
            right: 15px;
            background-color: var(--primary-blue);
            color: var(--white);
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
        }

        .product-content {
            padding: 20px;
        }

        .product-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 10px;
            color: var(--dark-gray);
        }

        .product-description {
            color: var(--medium-gray);
            margin-bottom: 15px;
            font-size: 14px;
        }

        .product-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .product-pricing {
            display: flex;
            flex-direction: column;
        }

        .product-wholesale,
        .product-retail {
            font-size: 14px;
            color: var(--medium-gray);
        }

        .product-availability {
            padding: 3px 8px;
            background-color: var(--success);
            color: var(--white);
            border-radius: 4px;
            font-size: 12px;
        }

        .product-actions {
            display: flex;
            gap: 10px;
        }

        .product-btn {
            flex: 1;
            padding: 8px 15px;
            font-size: 14px;
        }
        /* Quote Section */
        .quote {
            background: linear-gradient(to right, var(--primary-blue), var(--secondary-blue));
            color: var(--white);
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .quote-content {
            position: relative;
            z-index: 1;
        }

        .quote h2 {
            font-size: 36px;
            margin-bottom: 20px;
            color: var(--white);
        }

        .quote p {
            font-size: 18px;
            margin-bottom: 40px;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }

        .quote-form {
            background-color: var(--white);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            margin: 0 auto;
            text-align: left;
        }

        .form-title {
            font-size: 24px;
            margin-bottom: 30px;
            color: var(--primary-blue);
            text-align: center;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group.full-width {
            grid-column: span 2;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark-gray);
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--light-gray);
            border-radius: 4px;
            font-size: 16px;
            color: var(--dark-gray);
            transition: var(--transition);
        }

        .form-control:focus {
            border-color: var(--primary-blue);
            outline: none;
            box-shadow: 0 0 0 3px rgba(0, 82, 148, 0.1);
        }

        textarea.form-control {
            resize: vertical;
            min-height: 120px;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            margin-bottom: 5px;
        }

        .checkbox-group input {
            margin-right: 10px;
        }

        .form-submit {
            text-align: center;
            margin-top: 20px;
        }

        /* Testimonials */
        .testimonials {
            background-color: var(--off-white);
            position: relative;
        }

        .testimonial-slider {
            max-width: 800px;
            margin: 0 auto;
            overflow: hidden;
            position: relative;
        }

        .testimonial-track {
            display: flex;
            transition: transform 0.5s ease;
        }

        .testimonial-slide {
            min-width: 100%;
            padding: 0 20px;
        }

        .testimonial-card {
            background-color: var(--white);
            border-radius: 10px;
            padding: 30px;
            box-shadow: var(--box-shadow);
            position: relative;
        }

        .testimonial-content {
            margin-bottom: 20px;
            font-style: italic;
            position: relative;
            padding: 0 20px;
        }

        .testimonial-content:before,
        .testimonial-content:after {
            content: '"';
            font-size: 60px;
            position: absolute;
            color: var(--primary-blue);
            opacity: 0.2;
            font-family: Georgia, serif;
        }

        .testimonial-content:before {
            top: -20px;
            left: -10px;
        }

        .testimonial-content:after {
            bottom: -50px;
            right: -10px;
        }

        .testimonial-author {
            display: flex;
            align-items: center;
        }

        .author-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background-color: var(--light-gray);
            overflow: hidden;
            margin-right: 15px;
        }

        .author-name {
            font-weight: 600;
            color: var(--primary-blue);
            margin-bottom: 5px;
        }

        .author-company {
            font-size: 14px;
            color: var(--medium-gray);
        }

        .testimonial-nav {
            display: flex;
            justify-content: center;
            margin-top: 30px;
            gap: 15px;
        }

        .testimonial-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--white);
            color: var(--primary-blue);
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: var(--box-shadow);
        }

        .testimonial-btn:hover {
            background-color: var(--primary-blue);
            color: var(--white);
        }

        .testimonial-dots {
            display: flex;
            justify-content: center;
            margin-top: 20px;
            gap: 8px;
        }

        .testimonial-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: var(--light-gray);
            cursor: pointer;
            transition: var(--transition);
        }

        .testimonial-dot.active {
            background-color: var(--primary-blue);
            transform: scale(1.3);
        }

        /* Contact Section */
        .contact {
            background-color: var(--white);
        }

        .contact-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
        }

        .contact-info {
            background: linear-gradient(135deg, var(--primary-blue), var(--dark-blue));
            padding: 40px;
            border-radius: 10px;
            color: var(--white);
            height: 100%;
        }

        .contact-info-title {
            font-size: 24px;
            margin-bottom: 30px;
            position: relative;
            padding-bottom: 15px;
        }

        .contact-info-title:after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 50px;
            height: 2px;
            background-color: var(--white);
        }

        .contact-detail {
            display: flex;
            margin-bottom: 25px;
        }

        .contact-icon {
            min-width: 40px;
            height: 40px;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 18px;
        }

        .contact-text h4 {
            font-size: 18px;
            margin-bottom: 5px;
        }

        .contact-text p {
            opacity: 0.8;
        }

        .social-links {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .social-link {
            width: 40px;
            height: 40px;
            background-color: rgba(255, 255, 255, 0.1);
            color: var(--white);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            transition: var(--transition);
        }

        .social-link:hover {
            background-color: var(--white);
            color: var(--primary-blue);
            transform: translateY(-5px);
        }

        .contact-map {
            border-radius: 10px;
            overflow: hidden;
            height: 300px;
            margin-top: 30px;
        }

        .contact-map iframe {
            width: 100%;
            height: 100%;
            border: none;
        }

        .contact-form {
            padding: 40px;
            background-color: var(--off-white);
            border-radius: 10px;
            box-shadow: var(--box-shadow);
        }
        /* Footer */
        .footer {
            background-color: var(--dark-blue);
            color: var(--white);
            padding: 80px 0 30px;
            position: relative;
        }

        .footer-top {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            margin-bottom: 60px;
        }

        .footer-col h3 {
            font-size: 20px;
            margin-bottom: 25px;
            position: relative;
            padding-bottom: 15px;
        }

        .footer-col h3:after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 40px;
            height: 2px;
            background-color: var(--accent-blue);
        }

        .footer-about p {
            margin-bottom: 20px;
            opacity: 0.8;
        }

        .footer-links ul {
            list-style: none;
        }

        .footer-links li {
            margin-bottom: 12px;
        }

        .footer-links a {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: var(--transition);
            display: flex;
            align-items: center;
        }

        .footer-links a:hover {
            color: var(--white);
            padding-left: 5px;
        }

        .footer-links a i {
            margin-right: 10px;
            font-size: 12px;
        }

        .footer-newsletter p {
            margin-bottom: 20px;
            opacity: 0.8;
        }

        .newsletter-form {
            display: flex;
        }

        .newsletter-input {
            flex: 1;
            padding: 12px 15px;
            border: none;
            border-radius: 4px 0 0 4px;
            font-size: 14px;
        }

        .newsletter-btn {
            padding: 0 15px;
            background-color: var(--primary-blue);
            color: var(--white);
            border: none;
            border-radius: 0 4px 4px 0;
            cursor: pointer;
            transition: var(--transition);
        }

        .newsletter-btn:hover {
            background-color: var(--accent-blue);
        }

        .footer-bottom {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .copyright {
            opacity: 0.7;
            font-size: 14px;
        }

        /* Back to Top Button */
        .back-to-top {
            position: fixed;
            right: 30px;
            bottom: 100px;
            width: 50px;
            height: 50px;
            background-color: var(--primary-blue);
            color: var(--white);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: var(--transition);
            opacity: 0;
            visibility: hidden;
            z-index: 99;
        }

        .back-to-top.active {
            opacity: 1;
            visibility: visible;
        }

        .back-to-top:hover {
            background-color: var(--dark-blue);
            transform: translateY(-5px);
        }

        /* WhatsApp Float Button */
        .whatsapp-float {
            position: fixed;
            right: 30px;
            bottom: 30px;
            width: 60px;
            height: 60px;
            background-color: var(--whatsapp);
            color: var(--white);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            transition: var(--transition);
            /* Footer */
        .footer {
            background-color: var(--dark-blue);
            color: var(--white);
            padding: 80px 0 30px;
            position: relative;
        }

        .footer-top {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            margin-bottom: 60px;
        }

        .footer-col h3 {
            font-size: 20px;
            margin-bottom: 25px;
            position: relative;
            padding-bottom: 15px;
        }

        .footer-col h3:after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 40px;
            height: 2px;
            background-color: var(--accent-blue);
        }

        .footer-about p {
            margin-bottom: 20px;
            opacity: 0.8;
        }

        .footer-links ul {
            list-style: none;
        }

        .footer-links li {
            margin-bottom: 12px;
        }

        .footer-links a {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: var(--transition);
            display: flex;
            align-items: center;
        }

        .footer-links a:hover {
            color: var(--white);
            padding-left: 5px;
        }

        .footer-links a i {
            margin-right: 10px;
            font-size: 12px;
        }

        .footer-newsletter p {
            margin-bottom: 20px;
            opacity: 0.8;
        }

        .newsletter-form {
            display: flex;
        }

        .newsletter-input {
            flex: 1;
            padding: 12px 15px;
            border: none;
            border-radius: 4px 0 0 4px;
            font-size: 14px;
        }

        .newsletter-btn {
            padding: 0 15px;
            background-color: var(--primary-blue);
            color: var(--white);
            border: none;
            border-radius: 0 4px 4px 0;
            cursor: pointer;
            transition: var(--transition);
        }

        .newsletter-btn:hover {
            background-color: var(--accent-blue);
        }

        .footer-bottom {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .copyright {
            opacity: 0.7;
            font-size: 14px;
        }

        /* Back to Top Button */
        .back-to-top {
            position: fixed;
            right: 30px;
            bottom: 100px;
            width: 50px;
            height: 50px;
            background-color: var(--primary-blue);
            color: var(--white);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: var(--transition);
            opacity: 0;
            visibility: hidden;
            z-index: 99;
        }

        .back-to-top.active {
            opacity: 1;
            visibility: visible;
        }

        .back-to-top:hover {
            background-color: var(--dark-blue);
            transform: translateY(-5px);
        }

        /* WhatsApp Float Button */
        .whatsapp-float {
            position: fixed;
            right: 30px;
            bottom: 30px;
            width: 60px;
            height: 60px;
            background-color: var(--whatsapp);
            color: var(--white);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            transition: var(--transition);
            z-index: 99;
            font-size: 24px;
            animation: pulse 2s infinite;
        }

        .whatsapp-float:hover {
            transform: scale(1.1);
            box-shadow: 0 8px 25px rgba(37, 211, 102, 0.4);
        }

        .whatsapp-tooltip {
            position: absolute;
            right: 75px;
            background-color: var(--white);
            color: var(--dark-gray);
            padding: 8px 15px;
            border-radius: 4px;
            font-size: 14px;
            white-space: nowrap;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }

        .whatsapp-float:hover .whatsapp-tooltip {
            opacity: 1;
            visibility: visible;
        }

        @keyframes pulse {
            0% {
                box-shadow: 0 0 0 0 rgba(37, 211, 102, 0.7);
            }
            70% {
                box-shadow: 0 0 0 15px rgba(37, 211, 102, 0);
            }
            100% {
                box-shadow: 0 0 0 0 rgba(37, 211, 102, 0);
            }
        }

        /* Animations */
        .fade-in {
            animation: fadeIn 1s ease forwards;
        }

        .slide-up {
            animation: slideUp 1s ease forwards;
        }

        .slide-right {
            animation: slideRight 1s ease forwards;
        }

        .slide-left {
            animation: slideLeft 1s ease forwards;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(50px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideRight {
            from { opacity: 0; transform: translateX(-50px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @keyframes slideLeft {
            from { opacity: 0; transform: translateX(-50px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @keyframes zoomIn {
            from { opacity: 0; transform: scale(0.8); }
            to { opacity: 1; transform: scale(1); }
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .hero-image {
                width: 40%;
            }
        }

        @media (max-width: 992px) {
            .section-padding {
                padding: 60px 0;
            }

            .hero-content {
                max-width: 100%;
                text-align: center;
            }

            .hero-buttons {
                justify-content: center;
            }

            .hero-image {
                display: none;
            }

            .about-container,
            .contact-container {
                grid-template-columns: 1fr;
                gap: 40px;
            }

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .section-title {
                font-size: 30px;
            }

            .hero-title {
                font-size: 36px;
            }

            .hero-subtitle {
                font-size: 18px;
            }

            .mobile-nav-toggle {
                display: block;
            }

            .nav-menu {
                position: fixed;
                top: 0;
                right: -100%;
                width: 80%;
                max-width: 300px;
                height: 100vh;
                background-color: var(--white);
                box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
                flex-direction: column;
                justify-content: center;
                align-items: center;
                transition: var(--transition);
                z-index: 999;
            }

            .nav-menu.active {
                right: 0;
            }

            .nav-item {
                margin: 15px 0;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .form-group.full-width {
                grid-column: 1;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 576px) {
            .section-padding {
                padding: 50px 0;
            }

            .btn {
                width: 100%;
                margin-bottom: 10px;
            }

            .hero-buttons {
                flex-direction: column;
            }

            .product-actions {
                flex-direction: column;
            }
        }
    </style>
    <style>
.checkbox-container {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.checkbox-category {
    font-size: 16px;
    font-weight: 600;
    margin-top: 15px;
    margin-bottom: 5px;
    color: var(--primary-blue);
    border-bottom: 1px solid var(--light-gray);
    padding-bottom: 5px;
}

.checkbox-group {
    display: flex;
    align-items: center;
    margin-bottom: 5px;
}

.checkbox-group input {
    margin-right: 10px;
}

@media (max-width: 768px) {
    .form-grid {
        display: flex;
        flex-direction: column;
    }
    
    .form-group {
        width: 100%;
        margin-bottom: 15px;
    }
    
    .form-group.full-width {
        grid-column: 1;
    }
    
    .checkbox-container {
        padding: 10px;
        background-color: var(--off-white);
        border-radius: 5px;
    }
}

@media (min-width: 769px) {
    .checkbox-container {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 10px 20px;
    }
    
    .checkbox-category {
        grid-column: 1 / -1;
    }
}

@media (min-width: 992px) {
    .checkbox-container {
        grid-template-columns: repeat(3, 1fr);
    }
}
</style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container header-container">
            <a href="#" class="logo">
                <span class="logo-icon"><i class="fas fa-spray-can-sparkles"></i></span>
                <span class="logo-text">WK Produtos</span>
            </a>

            <button class="mobile-nav-toggle" id="mobile-nav-toggle">
                <i class="fas fa-bars"></i>
            </button>

            <nav>
                <ul class="nav-menu" id="nav-menu">
                    <li class="nav-item"><a href="#" class="nav-link active">Início</a></li>
                    <li class="nav-item"><a href="#about" class="nav-link">Sobre</a></li>
                    <li class="nav-item"><a href="#services" class="nav-link">Serviços</a></li>
                    <li class="nav-item"><a href="#products" class="nav-link">Produtos</a></li>
                    <li class="nav-item"><a href="#quote" class="nav-link">Cotação</a></li>
                    <li class="nav-item"><a href="#contact" class="nav-link">Contato</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <div class="hero-content" data-aos="fade-right" data-aos-delay="200">
                <h1 class="hero-title animate__animated animate__fadeInDown">Soluções Profissionais em Produtos de Limpeza</h1>
                <p class="hero-subtitle animate__animated animate__fadeInUp animate__delay-1s">Fornecemos produtos de alta qualidade para empresas, indústrias e estabelecimentos comerciais. Atendemos atacado e varejo com os melhores preços do mercado.</p>
                <div class="hero-buttons animate__animated animate__fadeInUp animate__delay-1s">
                    <a href="#products" class="btn">Nossos Produtos</a>
                    <a href="#quote" class="btn btn-white">Solicitar Cotação</a>
                </div>
            </div>

        </div>
    </section>
    <!-- About Section -->
    <section id="about" class="about section-padding">
        <div class="container">
            <h2 class="section-title" data-aos="fade-up">Sobre a WK Produtos de Limpeza</h2>

            <div class="about-container">
                <div class="about-image" data-aos="fade-right" data-aos-delay="200">
                    <img src="https://biossen.com.br/blog/wp-content/uploads/2023/04/27-03-750x410.jpeg" alt="Sobre a WK Produtos de Limpeza">
                </div>

                <div class="about-content" data-aos="fade-left" data-aos-delay="200">
                    <h2>Experiência e Qualidade</h2>
                    <div class="about-text">
                        <p>A WK Produtos de Limpeza é uma empresa especializada no fornecimento de soluções completas em higiene e limpeza para empresas, indústrias, condomínios e estabelecimentos comerciais.</p>
                        <p>Com anos de experiência no mercado, oferecemos produtos de alta qualidade, atendimento personalizado e preços competitivos tanto para clientes de atacado quanto varejo.</p>
                        <p>Nossa equipe está preparada para oferecer as melhores soluções, garantindo economia e eficiência para nossos clientes.</p>
                    </div>

                    <a href="#contact" class="btn">Entre em Contato</a>

                    <div class="stats-grid">
                        <div class="stat-item" data-aos="zoom-in" data-aos-delay="100">
                            <div class="stat-number">98%</div>
                            <div class="stat-text">Clientes Satisfeitos</div>
                        </div>

                        <div class="stat-item" data-aos="zoom-in" data-aos-delay="300">
                            <div class="stat-number">100+</div>
                            <div class="stat-text">Produtos Disponíveis</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="services section-padding">
        <div class="container">
            <h2 class="section-title" data-aos="fade-up">Nossos Serviços</h2>

            <div class="service-grid">
                <div class="service-card" data-aos="fade-up" data-aos-delay="100">
                    <div class="service-content">
                        <div class="service-icon">
                            <i class="fas fa-boxes"></i>
                        </div>
                        <h3 class="service-title">Vendas no Atacado</h3>
                        <p class="service-text">Fornecemos produtos em grandes quantidades para empresas e indústrias com preços especiais e condições exclusivas.</p>
                        <a href="#quote" class="btn btn-outline">Solicitar Cotação</a>
                    </div>
                </div>

                <div class="service-card" data-aos="fade-up" data-aos-delay="200">
                    <div class="service-content">
                        <div class="service-icon">
                            <i class="fas fa-store"></i>
                        </div>
                        <h3 class="service-title">Vendas no Varejo</h3>
                        <p class="service-text">Atendemos clientes que buscam produtos de qualidade em menores quantidades, com preços competitivos.</p>
                        <a href="#quote" class="btn btn-outline">Solicitar Cotação</a>
                    </div>
                </div>

                <div class="service-card" data-aos="fade-up" data-aos-delay="300">
                    <div class="service-content">
                        <div class="service-icon">
                            <i class="fas fa-truck"></i>
                        </div>
                        <h3 class="service-title">Entregas Rápidas</h3>
                        <p class="service-text">Realizamos entregas em toda a região de São José dos Pinhais e Curitiba com agilidade e eficiência.</p>
                        <a href="#contact" class="btn btn-outline">Saiba Mais</a>
                    </div>
                </div>

                <div class="service-card" data-aos="fade-up" data-aos-delay="400">
                    <div class="service-content">
                        <div class="service-icon">
                            <i class="fas fa-handshake"></i>
                        </div>
                        <h3 class="service-title">Contratos Personalizados</h3>
                        <p class="service-text">Desenvolvemos contratos de fornecimento contínuo adaptados às necessidades específicas de cada cliente.</p>
                        <a href="#quote" class="btn btn-outline">Solicitar Proposta</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Products Section -->
    <section id="products" class="products section-padding">
        <div class="container">
            <h2 class="section-title" data-aos="fade-up">Nossos Produtos</h2>

            <div class="category-tabs" data-aos="fade-up" data-aos-delay="100">
                <button class="category-tab active" data-category="all">Todos</button>
                <button class="category-tab" data-category="cleaning">Produtos de Limpeza</button>
                <button class="category-tab" data-category="paper">Papéis e Descartáveis</button>
                <button class="category-tab" data-category="garbage">Sacos de Lixo</button>
            </div>

            <div class="product-grid">
                <!-- Produtos de Limpeza -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="100" data-category="cleaning">
                    <div class="product-image">
                        <img src="https://images.unsplash.com/photo-1585421514284-efb74c2b69ba?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80" alt="Desinfetante 5lts">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Desinfetante 5lts</h3>
                        <p class="product-description">Elimina germes e bactérias, deixando um agradável perfume no ambiente.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <div class="product-card" data-aos="fade-up" data-aos-delay="200" data-category="cleaning">
                    <div class="product-image">
                        <img src="https://p.turbosquid.com/ts-thumb/dg/EoF5s4/iO/fabric_softener_01_blank_thumbnail_0002/jpg/1680889531/600x600/fit_q87/11c78080c295f795cd9ed5d0beb9327995d3288e/fabric_softener_01_blank_thumbnail_0002.jpg" alt="Amaciante 5lts">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Amaciante 5lts</h3>
                        <p class="product-description">Proporciona maciez e perfume duradouro nas roupas.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <div class="product-card" data-aos="fade-up" data-aos-delay="300" data-category="cleaning">
                    <div class="product-image">
                        <img src="https://www.hygibras.com/wp-content/uploads/2021/06/alvejante-sem-cloro-2.png" alt="Alvejante sem cloro 5lts">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Alvejante sem cloro 5lts</h3>
                        <p class="product-description">Remove manchas difíceis sem danificar os tecidos.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Papel e Descartáveis -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="100" data-category="paper">
                    <div class="product-image">
                        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhIQEhAWFhUSEhUVFRUTEBoQFxUbFhcYFhUVFRUYHSggGBslIhUYIjEhJSkrLi4uFx8zODMsNygtLisBCgoKDQ0OFxAPFysdHx0rKystKysrOCsrNysrKy0rLSs3NzArKysrKy0rLS0rKysrKysrKysrKysrKysrKysrK//AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAAAwUCBAYBBwj/xAA7EAACAQICBgcECQQDAAAAAAAAAQIDEQQhBRIxQVGRBhNhcYGhwSIysdEHIzNCUmJy4fCCkqLxQ2Oy/8QAFgEBAQEAAAAAAAAAAAAAAAAAAAEC/8QAFxEBAQEBAAAAAAAAAAAAAAAAAAERIf/aAAwDAQACEQMRAD8A+4gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEOJxMacXObsl/LLiBMDk8Z0jqN/VxUVxa1pP0RFT6R11tUJd8WvgwOxBzNLpS/vUeVT0aNuj0lpyaXV1LvglL1Auwa1PHQavmu9NE8Jp5p3AyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYVaiinJ7Ers5LSWJlWld5Je6uH7lzpqre1Nd79F/OJU9SBodUSrDm3GieyphGhDDazsi3wuHjBWSze172eYanbvZOgrIko1nF35riRAC7hK6ut56aejp5NcPX+M3AAAAAAAAAAAAAAAAAAAAAAAAAAAYFDiXeUn+Z+WS+BFqnqZmgMdQOJKjGosv5/NwGEWaWntM0cHRniK8rQhbJK8pN+7CK3t/u7JNm7E+NfTnpNvEYfCp+zTpOq1ucqkpRTtxSp/5sC90P8AS1CrWUKmF6unJ2U1V15RW5zjqpd9nz3/AEyDvmflbRLvUifpXotNvCYdvb1UV/beK8kgL/R79prsLIrNH+/4P0LMAAAAAAAAAAAAAAAAAAAAAAAAAAAOcvZ24O3LI9TPdLQ1Kl90813716+JrxqAbkWe1di7yGEyaT2ARHxD6bsJJY6lU1fZqYaKT4uE5qS70pQ/uR9xkir09oChjKfV1431XeMk7Si9jafo8vID879GsFOpWhGMW5SkoxXFt5I/S+jsKqVKnSvfq4RjfjZWb8Sh6M9CsNg5urHWnPNRlNL2U9uqlv7TpkgNzR0M2+xIsDXwMLRvxz+RsAAAAAAAAAAAAAAAAAAAAAAAA4fpHpmpOpOlGTjTjJxdsnJrJ3fC98gOoxemqFN2lVV1uj7b8VG9vEqK/TCC9ylKX6moLyucioGlpvGyoUKlaNNzcFfVXfa7tuW19iA6nG9JZVUoulFK9/eba7nkKOJT2M+P4XpfWqvOoorhCKS5u78y9wmkqnvKq79rv5BH0+lUNyE7o4zozperXc04L2Le0pWTvus9jy7TqaUmt3r8AN9rIwjEwpVlsNmEQrBRMalaMLOV7X3K7J5ZfIrdJVYU4urVeSySWfckBZR07B+7Tn4pL1JFphfglzR8+x/TTUyhRj2a0m/JWMcP0ym83Rhb8s2vjcD6PHSsN6ku9L0ZPSxkJbJLueT5M5DRGmaeIvGKcZJXcZcNl01tWa5lp1QHRgo6NecNjy4PNfsW+HqqUVJASgAAAAAAAAAAAAAAAHB6RwetVqtbesnl/UzvDkcQvrqv635u4FHKg1tRNSoF9GKe1Hrw0PwhHI4ropg6rcp4anrPbKK6uT7XKDTb7zLC9FMLD3aL7pVak1ycszqnQieKC4+QGphMNGEdWEFFcIxUVyRt04M9t387GE6qiFMRRvZNrPd+5JgZJ06cs/ahFu0ntaTew1qEm5XZPolfU01wjq8m4+gG2qhr4zDwqxcJq8Xt3dzTWxk7gYOIHA6V+jVVJ69LGzh2ToqrycZQNjAdApQ9/Gay/LQ1Hzc2dlKdiN1+wIh0Poajh0+rTcmrOcneT7OC8EWSNWFZk8HfaFSqNyywEbRa7fRGhSRYYL3fH5AbAAAAAAAAAAAAAAAABymM+3q/q9EdWctjl9fV/Uv/ADECWmS2I6SJgIpIjZNJEU0BDUkalSVyeqQMInwiNjQ/2S7J1VyqzXoQYbaTaG+za/7avnVk/UDdaMJIlMZIK1aiNeUTcmjXnEDGmbtGJr0om/TVsglZxhYkhNrYyJSPVI1gn6+XH4HvXy7ORBcxnPcETSxjW5M9pY/OzVu1fI1GYDIq7TPTQ0fW+74r5G+ZUAAAAAAAAKzSmj9Z68V7Wxrit3iWYA52nGxMkW9WhGW1eO8geAW581cCuaIZlo9H/m8v3I3ou+2f+P7gUlQge3xOjhoaH3m342XkbdHB04e7BJ8bZ89oFNo3Rkpe1NOK7cm/Dd4ljisPq2cVZJWstxvnjQFQeNFjUwkXsy7jWnhJbrPx+YGlJEMom7KhL8L5X+BE6EvwS/tYGFCO8mTIk7ZHusaiVNcKRFrHqkES3MGwmEB4zBkeNxlOmrzko32La33JZs9pVFJKUXdPY0FS0p2afB/7LsoWXdF3inxSJSMwARQAAAAAAAAAAAAAAAAAAAAAMKkrJvgm+RmQY37Of6JfBgUSkFIgUz1SNI2FI91iDWPVIDdisj3tfMxTIsbfq5pbXCS5oI4fEVp4irOpnZu0eyK91dmXnc6Lo8nFSpvZlJfB+nNnmEwCirJFjhKVrvst6+gjVTl3h/dj+lfApWXdNWSXBJCpGYAMqAAAAAAAAAAAAAAAAAAAAABhWhdOPFNc8jMAcapfEyUiXS1DUqy4T9peO1c7msjQm1j3WIbjWAt0zyWyxhRleKfYZFZRxpkiVshcDDdZ0IXlFcX/ALLsrNHU7vW4ev8APMszNWAAIoAAAAAAAAAAAAAAAAAAAAAAADR0rguthZZSWcX6PsZzLi4txkrNbUztCl01jKCj7cesktihtX9W7mWCmsYs5TSGnsXCcnDDx6vdFylKS757+R5R6bbFVwtRcXBqpbnYurjudH1MnHh6m0cZhOmOFck+scHwqU5QXanK2r5nUaP0hSrrWpVIzS26klO3fZlZrbEU27LeZ0qMpbF8uZY4XCKObzfw7iWpIkw1LVilz7yYAy0AAAAAAAAAAAAAAAAAAAAAAAAAACvxmFqS2Ty/D7vw2lVWwEltj42uuZ0oLo5GWEi9xr1NFQf3FyOwq4WEtsV37HzIYaPgnfN9j2F2J1ylHotTqf8AGrcWrIt9HdEMJSlGp1EHOLupON7PsL9I9JqvEj0AgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//Z" alt="Papel Higiênico 300mts">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Papel Higiênico 300mts</h3>
                        <p class="product-description">Papel de alta qualidade para ambientes comerciais de grande circulação.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <div class="product-card" data-aos="fade-up" data-aos-delay="200" data-category="paper">
                    <div class="product-image">
                        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhASEBISEhUVDw8PFRUQFRAQFRAVFRUWFxUVFhUYHSggGBolGxUWITEhJSkrLi4uFx8zODMsNygtLisBCgoKDQ0OFQ8PDysZFRkrLTcrKysrKysrLTctLSs3LTcrLSsrNys3KystKysrKys3KysrKy0rKysrLSsrKysrK//AABEIAOEA4QMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAQIDBAUGB//EADsQAAIBAgIHBQYFAgcBAAAAAAABAhEhAzEEEkFRcYGRBWGhsdETIjLB4fAGQmJygpLxQ1KDk6LC4hT/xAAXAQEBAQEAAAAAAAAAAAAAAAAAAQID/8QAGBEBAQEBAQAAAAAAAAAAAAAAAAERMRL/2gAMAwEAAhEDEQA/APuIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYsXSIR+KSXn0Ayg52L2rH8qcuNkamJ2hiPaor9Kv1ZNHblJLN04mpjdpYccnrP9N/HI4073k2+LqNQmjpQ7XW2LXBpmxDtHDe1ripehxfu1wNo78dKg8px6oypnnNX7sWVsreA0eiBw8PHmspS5uvmbGHpk9tHy9C6OoDSjp6/MlydfAT09flTfGw0boNbR9K1rOz8zZKAAAAAAAAAAAAGti6bCO2vC4GyDmYvab/JHnL0NTFx5y+KT4KiXgTR18XS4Rzkq7ld9EaWL2p/kjzl6I0KEktF8TScSWcmu6NjCootQgipRFidQaoFaihkjAyRwgMKiWUDYhgk60V9LjBhjhGVYO1k67eSS43ZHs65343KGtFZX4epW77jJqlqAY44K4l6E0DCKnT0fE1opnLbNns6d2u6v31EG+ADQAAAAQwMWLpMY2ze5Xf0NLG7Rk7RSXe7v0OXpOLNSxEnVe0ltvnl4mD/AOuSzT6KXkZtVv4k5S+KTfl0K0NaGnrbbjWPmZMPSoy+0yDISSsSO/rbzJoBQhl6FlEDEl92LRgZ44ZljhfbGDWWH92MkcAy+0iu/gUeNJ5Uj4sousNLOxWWMtirxKau+/EsohFJVef3yLRgZEiQKpE0JqRUCRUghsA2VbDZAEMyaLKk48adTE5FYTuuKCu6ADSAAABgAeU0h0nip1p7SV6LeYlKuTrTc79H6GbtGFMfFpm6Ozo3VJ5bTWmt9P5rVfVWOdF2/tppmJ4aez78y6dtq4e/F9LlU67YvuT1WQQobpNd3xPxVSylK31i+gnxf8lUVezwfyYGfC0prPxVV1NyOlL3VlXdR5bjme1Ss18n6MzaO4ynGjyrmqZlV08PTIyXubLd/QpLEbzq/I5E4uE3R7a7l02nY0XEUoprnxKJjEyKJJJUAQKgTUEVIqBJFSCGwqWyGyHMpUC8pFJSKtkNhENhAsiK76BXCyXBeRY2gAAAAA8x29BrHdMpYcW01rK1r9NhoRnTY6b4PXXODyOh+JXFY2HrOnuWd973Zce80MTDfdLdW7/qX1Od6GE060o/21hLptEmttf9SNuq9Sry95NW/MvaR9UUw4v8kk+6MvOMqryIrOoNZVS3weuvEhXp8Mn3rVl0aMalf3o9Pcfo+pk9oqJSe3/EXzQFW6W96PiuefmZtCb11dZ7K+Rj1d1afpesun0MmjOklR1vuVV1AydoQ96vn8idAxdV0eUnS727C/anTvd3yRoRXXq+uwo9CiGzFg4tYxe1rx2ltY0LVFSjZGuEZCHIx1AVZyK1IqVAsQQ2ADDFCaPYEQkTGLbok2bmBoDd5W7tp0MPCUVRKgwThqy4IsAaAAAAAB538UV18J6rlZ2iot5recdajdIycZZ0TcX/AEuzOx+KE9bCaermqtay2We7icnFxFSmJHqnKPqjneidaSrWkv8Ai/R+BjliQfxW/cv+3/oth4dq4c7f7kfC65CWNJfHCvfBqXhZ8rkVeMXslVbpUmnwdn5kRVrpr9jqujMeHGMqvDlR7VSj/lF+iMmvJL3kpU/i119QikYqvutV3XhLpt6Gxo+spK9brNJV5rIwvEjlJOP7lVdX6mTChRqkvvnboFdLtGNreHqcqL2Z9y+bOxpybXLJHD8V3WS5lo6nZ06xatZ7Nif9mbRzuysSsmt8a2Vrf3OgywAQ2RUC1QVqKlBsiooSkRBIlIy4GjueStveXLedLA0SMe972XBo4GhSlnZd+b5HRwdHjHJc9plBcAAFAAAAAAAAGt2hoaxYOMrbU1nF7GeT07Q8bBd41hscVrRp4OPjwPakNEs0fPFOEm9aEotZyhVNLZrK0lzTRmgsS7w8RYi2qdOa1o/M9VpvYmFO6WpK9HC2fcjz+nfh/FhdJYn6o+7NfyjddGYsVqSxoNr2sHhvY9nKSy8DPCEl8M67Up/KS+prLGmqxmtZVpSdE6/u+GT40ZaGrlGcsJ3WrJUTfdF2fIgye2p8cXDq11RkwYxbTi6ZZOqMbxcWFdeKnH/Nhqq5xeRGBPCnJaqVarJtS6SuB3dNXu8ttl0OBiO/O2t8keg0rLlxZ57GXvPZfZd83sLRn0LFpiQrterd0ztZHakzzOuo3zo07Xy3yZ6aqeWXmhBRipNAUQiS+HhOWSqb+BoFPiv3IqNHCwXJ0S+h0NH0GKvK78DajFKytwLFwEACgAAAAAAAAAAAAAAAAAANTTOzsLF+OCb3qsZdVc4uk/hfP2U8/wAs0qPoqeB6UEyDwuN2djYOyeH3walDplFc0zHDSbx9pGErq6STffT4vM98aeN2bhSu4JPfGsfInkcrSZJJJLNWSTq+EVdmphdhYuI6yphx/Vd8or5vkenwdHjD4Ul5vi9plHkcvQ+wsGFG4+0e/E96nCPwrpUw6RCkpLv8ztGri6LrSq8qLmWwc2OG3ZKpuYGgbZPkjehBKyVCwwVhBKyVCwBQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/9k=" alt="Papel Toalha Interfolha">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Papel Toalha Interfolha</h3>
                        <p class="product-description">Ideal para banheiros comerciais, com excelente absorção.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Sacos de Lixo -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="100" data-category="garbage">
                    <div class="product-image">
                        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUTExIVFhUXGRYaGBgYFxgbGBgYFRcYGBcYGxoYHSggGB8lHRUXITEhJSkrMS4uGB8zODMsNygtLisBCgoKDQ0NFQ0PFSsZFRktNysrKystNy0tKysrNysrKysrLS0rLTcrLSstKysrLS0rKzcrNystKystKy4rKystK//AABEIAOIA3wMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABgIDBAUHAQj/xABEEAACAQIDBAgDBgMFBwUAAAABAgMAEQQSIQUxQVEGBxMiYXGBkTJCoRQjUrHB0WJy8DNTgpKyCBUWQ8Lh8VRjc4PS/8QAFQEBAQAAAAAAAAAAAAAAAAAAAAH/xAAVEQEBAAAAAAAAAAAAAAAAAAAAEf/aAAwDAQACEQMRAD8A7jSlKBSlKBSlKBSlKBSlKBSlKBSlKDR9Meka4DDGdkMhuFVAQCSQTvPAAE6XOm41y7bPXVMWVcNBFGDlBaUs5DG2YBFy3tm56+Fdg2zsqLFRNDMuZG9weDKeBHOvmfrL6Jy7Nms+Z45GLRTDS/Aq/JwLeB3jfYBjbR6ytqTy3OLePvCwTuKNeS79/G9brZu3No4vERZcfiT8IU8c1tQqR91rniwOg141zzDkFgXzEcf/AD619H9S/RyOPCJjGT72XNkv8kWayheWYKGJ43oOgYDtOyTtbdplXPbdmt3retZFKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUCla7b224MHC02IkCIOe9jwVRvZjyFcb6Rdd05YLhYFiS/xyWeQjmFByr63oO61EusjZ+ExmDkw088MbkZomkdVySqDkbvHxIPgxrgWP6dbSxCs0mNmVCSAqME9+zC3rQ4Ux3Mkgzm53nUnmefr+lBjQ4ELNGk0ixKSMz3EgUXBJtHmubfL719L9HusfZBRYYsTlEaKozRyKLKAosStq+bsXGhCtusxBHAA6g/Q0hUq5VSOBU81PDTd5+FB9h4LGxzKHikV1NiCrAjXdurIr5dwO2pI1EkReKRTZuzYgkbwdNDfy3+dS/YvXHiV7skceItwv2Up1tpvRz4aEkaXoO50qIdEesXB49uzVjDPe3Yy2Vyd5Ci/eIsdBrpUvoFKUoFKUoFKUoFKUoFKUoFKUoFKUoFKVYxuLSJGkkNlUXJ/IADUkmwAGpJAoK55lRS7sFVQSzMQAAN5JOgFc02t1tLJN9m2bEJ5TcCRzkiuASco+KTd4A8zUS6ytuSY7EJh7PlS5aG/dVt4DgfE6rfMNcpuBuJMXx8seEKFQ32xdQqgLHArKLZ7i7PqTbhccRQZvTuHENaXH4oyTkEiJbBYQDYd0Gygnja9qgB7500G797Vm7Rd5ZDncuxPea97njrc3F+PGsvo3GrSliLrHY7tCeHhwoM/ZPRPF7QYRYWLuJYM7HKiX4ljv3Hdc150u6JybPZI2JZSNHtYF/nUfmOYINdh6qWKrK+pQkLmsdSneJHPVzpv18KowsMW0Jcfh5WDxSZGW5+EquUMv4WFgcw3i3A0HCoEBuDut+v56XrHmGRk4jUDyuNPqa3eM2UcPM+HkPeDABhaxBNgSL6CxB9/TExmEKZcw0zAjUEHL8WvoPegCYg/Q+NevZu9uPHS/rbj4ivThHKmQKcmYKWtorMCVBtzCnwryOK5y6qbXBPEWvfXgeBoMrHxMojaYEodYZ0JzKVOoDfMAeB7y+1TLor1q4vBFY8VfF4ews4I7YAcQx/tP8Wum+ofsvHCMNDL3sNIRnFicjWsJFG8EaXG8hfAVXtHZZw9wcrwupeGQEEML8LbjY68xY8dA+nOj23sPjoRPhpRIh0Nt6tYEqw3qwuNDzHOtnXyX0U6RT7PxCzwsQGID6EpIBqUdQdSL6Eajxr6W6IdK4Now9pEbOAO0iJGeMnde29TY2YaG3gQA31KUoFKUoFKUoFKUoFKUoFKUoFc72nts4raTRXthsCjyvyaWMaFuaqToPxITwFTTpBtD7Ph5ZeKqcvix0Ue5Fcs6NbLzYGbOcv2qZxLJxGGgGaU+rdoPWghOJ2oMIr7QYXmxBf7KrWNgfixLA+JIUcTc7qv7F6vJ8bhDMjFsSwWZlZh94shcDvHc/cLC5sQeG+td0x2bJLj8xjbs3WMRJfREsBCgHDuZCRzY8a+hOi2zxCuW25UH+UW4UHAOknQyTZ0aNimRWe4CqcxFgN5AsDqN16xurTYz4jtuyQyMCLDNlA0JzHQ3tpYaaka1vevbbBnkhQfCO0I8R2jop9RED61hbF2VG0xjglbDolmaVjmEZS2d7ra652A13DUnfQde6vNmvHCwcRgdoxyKzEKQAPh46BTqTvB41AehCZMRiFABdWcrfRQplyqtsp1bQgW57rV1DotsTFYct2+IimuiqGVCjEJ8GYZipIBIuLaWHAVAcIww+1mgYayzynT5USBTC3uWH+Kgs9aWyMjwTHKe2kCPZdEsODfFvJ18xaoj0rw3ZYiHCsLBUZzc3B+7c5tf5RwrsvSDACa8TgHuZ4+NpEBuR6H86gXTDZZfb+GjtpJhHt5/Z8SPzAoIJsLGGBjHIheCXNFPH+Ix6sFPBxmV0PM24mpt1odGckOFxmFcyQdhFESAPhjW8bm3BgxvfiBzrXdOcNEXiSOMK7wI5ddD2kQuhbhrGJBfeSEHCpH1WbSXF4afZeI0DqzRjXc2sijkASrr4MwHwUHMdv4qN3jZECqYluB+MFgxv6D6+dZewMG+JQ4cSAIokkjznQOApdAflzLduV04XJrV7ewDYfESQPvRiv7Gsropj+wmGb4WsACL3OYWHkQSPI0GVslm+/wgCkTKVQOBbtIczLb8JY3W4/ENazOgfSJsE0cg+AlsjG9wlwHRgPiA0uOAKsoB37/AKNdHGxODx2TSaLEnsr71kgVSDr+MNY+QPlpsJgkZyWUdg80E4XdlXF54MTH/CY5VVfDsxzoPovZePSeJJUN1YAjW+/xG/z41lV899XXTVtn437FI4bCySFbm/3bMbJIPAki48b87/QlApSlApSlApSlApSlApSlBDutHFhMKgJtmkHrlR3P+moxtLEZlweyYh97KsZxBH/LRz2zr4E6k+AHOsrr0uYMPlPejkMoHMIAjXH/ANlc32PtpxtCOW+Z1kZhcnV2GW/rmIoOl4LZAxWOTEsgEUeInRLb3aPOFb+RRCviWPIazeSfsklc/Irn/ICfysag22ekIwkWDSLXKZRmI3lWWN3PmWkPjvqQY3aIxGzsRMhF2gmW3JsrBb+NiKDhOPftcdCZAGXC4WB3B+YxQIWHrKcvrUu6vsKC4imAPb7NxDtpa6yzmxt/JlrVYbYMmJkxYjGuJxEcCHfljJM0rHkoQRny866DtDYz4XamHmCH7OMFLCz27oKAsA3K4UflQY3VJ0rcGXZWKYtPhcwib+9iTQAeIFiOakcjWN1qYYRYvCY+MjLIBG511BtZt/4GP+UcqgXT7Dy4XHR4uA2cFZEcbrAi1zuK778LEg6VPNv7RXF7KkzRFcimYKT3o2ExjmQHdZCxtzUrQTWaRWjSVbnsyLEa3QnKfS16jHTV0h2tsrFy92JlmhL8AzowjB5X7Q+xrI6ott/aMLFGwAZVIAB3xxkIrHkSedWOtLEw4jC4cSC0bYiRbi2ZCiyIGXxB1oOVdINps0rZ1ytAoijtc/f4aRSSwG9cquTfmKzsDMyGPEwD7yBg6gXN43uyrzJF5EtxAccRUd2ckg2iisAztKIzfQMZj2RJ5Ah71OMBsMQYt8GGaSNfupJCtsrsocHwUN2qgn+9HMXC31wYHtnw20IrGLEqFJA+GRb906Xva414qahUWCMsXcH3i3ItvYrvA8bbh4aVPZMflwWJwMx73aGXDsTfJLG7HKT8veRd/Fzzpsfo9mxDODkjBViSLACRS9hzNiunJheg2HU5twFsQjnvSLBIuo7xVOxlOv8AFFr51Z6y8MmGw8wjF+1lV0tujZpI5Zlv+EtFnHIuw0G/XYyeOLa0MkKjIqZCLaMygliTpbSYXPgazunEvbYKQjUZkbmNHB3271t3LT5hrQcx6SoBOSDmzBHuNAe0UPp4a19Q9AdrnF7Ow07G7tGoc83TuufUqT618rbUU9q2bU34+Fd96g9oh8A0PGGQ6eDgEfUNQdMpSlApSlApSlApSlApSlByTrrndJ8I4N0UMHS18yyEf/j61zBg0Euew35kccr3Vr8dw9bjhU969dp9niEj/FEv0dz/ANX0rlOIvZSeNz4W03fWgnHSvbqTyLHGV7KELHGb3zBL3YnxNtazeifSgLDPg3fKZ8givwkd1X2sb/4a5mKob1oO6dWa/wC75J4Zh2qGRjBiEuxe5VJFMYGZWHZpmFtLW3AE73b215H2XtHUiXDfaEuRr3Rmjax/9tlNQXo90sywx4xmOVikGNtqUlUAQ4sKN5O5gN4IGuUCt51g4nJBi2DALOrPodHBwJizAjeC7IPSg5Z0P2mX2jDFiy0sc98PKHJOZcR3VIJ3WYowbhaui7IjaNdo7PluzJBKyOfmikgKh/UwwkjgzNyrjEEhfs7aSJqjDfp3h7EV3tpxN2eMQraXBzm9xcJJEWkjYbxaYKwP/wAg5WCNdVe0zgtj7Qx2mZSEizfCXygILcRnlF/KsfpxtKNcFgQHZlmabEpcagSZTlNuIZ3HkKgx6QE7NXZ6Xt24lLDc10y5T5NY1ldMdqLKuCjXRYMMiW8SxJProaC0drKmIjmse0jINiLd5d3kRofMCt50y6dmfERzYdzFmiDSlTZhKxTMpsLWQRIF36a8agrHUHyr2NdToDdTQSh5WkhkZnLMzqosR96C+VpAeBIYAnTVOdTbaXSqH+wUEBLI10PdYLYIM1gzWW1yQO781c3faarhYIhqw7xOuhEsjADx7+u7cN9Yb7RZiWZiSWLb+JNz7m3tQSbaOJWedmBygCM68rspNuNj2ZO7duFhUlw0/bYN420YXRhyNv6Nc5XH2dXHC4PiGqQ4PbYVr30YBW8cvwH6ke1BpOkkWXEuP5Pqi3+t66D/ALPeOyYueI7pYwR5xsxH0dqgm35VkdXHEWPmGNvo30qW9SrgbVjAtrDKfoun50H0VSlKBSlKBSlKBSlKBSlKD5+688h2gLuwdY0sLXU7zv3qdfKoUkKNYfCWBOQ6ob/Mh3ofcVLOu+Qf71ZSCfuYbW3g9+/n5flUEDsABe6i1uY8uXlQUOjglWIBH18RVLLWW5zb9fzqhhoNN3HnQZvRraKwu6S/2E69nL/CD8Mg8UJv6msbbGJxMathJJHyxkrk+WxbPp/Cxs41tqKxyovqDbzFX8diRKq5rlkAQE2uUHwg87bh4WHCg1WGfKQRvUhl8wb10vYO2Fk2XNhwe9AJ8njHMjnU79DK4t/CK502EG8HzFZOyMeIWe+5lK28/Kg1cRtXt68QVdyXoLDE0znnV84YcZFFeDDx/jY+S/vQYrN41Ur1lps8NopN+RKAnyuwvXsuzmQgMQPO1/oTQeYWBn3Lcen61vMLhsq5SB41jYaNFXTMfLNqfIVmbOhkmfJGmQcWkJ+ii7E+AFBW+ARge7r4EipJ1MwAbYQX+COf3yqOP81a3F4JYAczNIwvoAVTS2+3eYajlqQOYrY9TUg/3vE3F1xC+NhGjAn6+1B9G0pSgUpSgUpSgUpSgUpSg+fuufDkbUMpGhjVRfccqgn2zfWoLJh8+crw7xGu7S53cLgnzPKugdceLSedXQgiOSeFrb8yCAm/uR/hNRTojiFTEwGS5TN2Uo5pNeM38PvL+lBowCOFerY+tX+kOznwuJlw7k5oXKBjvZAbxt6qQfWsFZrGgqaqSK9m36buFW6C9GapeMcLeRAt/XrVKHWmbgaDHaNQdbqfI2/M1SYQd0g9autcbjpy31aZQfCgobC2+ZattEeYPrV0rXmWgtqlZ0e0nXcE9UX9qsBa8IoNzsvFzzyCPMddAFXUnflAA3+h8jUrhRIZmshZYB2fZg3bE4uXdESN+UWLDvAHwq30NkjiwcmI7NTiBK0cZJOVRkRybE2Frm7bzYCtnh4IMJhnxGKmCylHGFizfekyf2uIIHwySEmxPwrbdwCJba2h3jEzBmdh2hUaWB+BB+Bbtb8V83zGt51TYq+2YnAIVnxNhe+XOklh4bgKh8Km7TnKDdsg4Fz3UC/wqWFv5DyqY9ENlfYdq4LDkgyiRe0a91BeMkoD4bvMmg+kaUpQKUpQKUpQKUpQKx9o4sQxSStujRnPkqkn8qyKhnW5jjFsyULbNKUiA59owDD/AChqDhP2svhnWXWR52xBPIzK2f8A0p7GrJwtsP2oO+XsnA4B0zRP4XKyj/CK9xd2zNxZSfUW9tGq5hcUq4fFRN86xlf545VP5NJbyNBuOsSEzw4THk96SFFkJvcugswFhbQ5t+unGoNkvz9qn3RnGLi8DJgGvnTO8Wu+5LEedyagIUgkHeLj2oL0Av3d993ieXgeVUNER/5H76HwqkGstvvELfMvxi28fj/f3oMMjUVTJo1VS7gbVROdb0HjGqb169U0HhNeUoKD0mvYhc/l51RWVFCfgA7x38lXj/X70HqYqUqYlYiMksR8tyACT/lX2FeqwN1QFhxJHekYmygcQCSPH8qt4iUfAnwjeeZq9s7F9ge1AvItil9ytrZyOJXeBuva+61BN9iYSFWuy5xhRZSSFUtHcMddO9O0xBO4LUan6TyNio50jHbCZZFIJ71pMyL7aX434Vb2rti2HTDxnu5UaVj80hGYoDxUMzEniSeA1ydgYLs80jDNIqPK4O6KJELBDwzyGy5flVuZ0D6tia6g2tcA25X4VXWl6GbWGLwOGxAOrxrm1vZ1GVx6MGHpW6oFKVxTpf00xM8rJFK8MKkhQhys1j8TMNdeQOnjQdmnxKILu6qObED861OL6W4GP4sVF/hbOfZL1wRlZzd2LHmxLH3NDDUHZMV1l4FPhMkn8qEf68tajEdbkI+DDSH+Z1X8s1cwMIqjsKUT7Fdbsx/s8NGP5mZvyy1F+k/THE48IsyxBY2LKEVhclSveu5vox5Vq+wqtMPQYAB/CvsTzvvPia8fD33hNf4E/atgYbVWkQqUYeCwzKQy90jcVAB9wKrl2bG/xpqTfMNG99x9Qa2KmqZWqiN47o8wN4nDj8J7rj37re48q1wV42BIKniCLacdDwqUuKrRQwswDDkdfzpRFMXhtCyi6nX+W2/0rANTR9kJYqpK3BH4gLjxN/rWjn6MYhfhCyfyNr/lax9r1aNOaoNXZoyjZXUqw4MCD7HWqCKCivbV6BXoQkgDedw4mgvYJLnQXPyjx5nwG/2q/ItlKrr+J/xHkPCszD4UIlvmPxft5VZbDs5sNfAcPM7h/WlBrswGg1NZeLwPZBQxUuwuwBuE/hJGl+fL0NXXwqJvIJGpC7h5sd59qwZnZzYDU/ReFBiSvrccN3pxrc4faci4HEI2W0piA/Fo2dj5HIPY1qTHrYWPiN1ZGDwrTSxQ31kdVJ5AkD6C9B3zqCxr/ZJMLILNAysNdSuIXtRpw3/Wuo1wXoHt9cPt+RGFkxKRRDgFYRoY/cqV9a71QRTrIxkkWFDx4lYGDcTYyAA3RW3g8fSuA7RxGISRpH+9ViS+lnF9S38X5Hw3133rA6MjGRBxIEaIMRmNkINibn5d2+uF4jPEx/5kRv8ACQSuurRsDZhxye1qgYbFqyhka6n6eBHA1lxzA1p58FcibDuATxHwSW+VhwPnu+tMJjs7ZCMkg3oePip4jw/Og3mhplrDhlrMBvQe7qqBq0TVBeoq/QVj9p/V6vRoTRF4CqWWq1hPOrohoMXsqqVLVfMXiBWFLtKBTbNnb8Ka0GQB4VdMVhdu75kD6amo/jOkrrcKI4RzY5nPoNfzqP47aysbs0kvPMcq+1rH1ApBMsXtaIgxt98PwhQwHq2i+dxUY2k+EOqjsj4O0g8iAth6Ma0k2PdtNw5C9h5A3A9BVuCZQe8mcfzEfUVRkk1nYKMrrbXieQ5VkptWBrkwgBRobWbla43+tU4bFKy5h3R4628qovNYC8jWHBRe5/U/Tyr0zMwsB2UY4nQ+wrF+1quoGvM/Eb+fwisTFylj943ki6/X9aBLKCcoNl48z51b7VddCQeANs3Aa8hpoOXGrRcHQLbw3n151X9nfl7/ANaUHid0W41JOrzC58WZTbLChOv4muq/r7VGhhieZPIC/wD2HvUi2JtWTBwOsKL20jXMjm4jCiyhV3E7zc8+NB502R1xwkRshbKyHUENGqkHUaa2r6e6NbWGLwsGJUWEsatbkSO8PQ3HpXyFtLaMk7KGIdwfi1uxPMnfX0D/ALP+0A2z2gaRS8crnJmBYI9muRfcWLUG/wCsnaMC4V4ZJhG7gMoysxIRgdQoJANrXrhELB7yYeTS/fjbcT/EN6H+IV3LrA6NnEqHQDOo08RyvXFNq7GKuWGaKVfmGh8mHzCoMMA5iYxlfe8THuuOdx9HGvMUnhjnXUG6+jxnh6ab9xr1pwbLOuRge7Ivwk8wf+WfPSvJkKkZjlbcsoGhv8rjdY+x8DRWOuMeEhZtVOiyj6Bx+v51t45beu7kQawxJmvG6gHivysOa3/07x476wWgeDWLvxbzGd688p/r1ojePJXgNa6PaKlDIDdRv/EDyI51pptvSX0JUfhW1wPFiDr5Cgl8UV+NXzIifE6jzYD86gT7YkfS8h/xn/pAFWAxGuVB4m7H6k0ipxN0mw6aBi55KCfqdKxcR0la2irGp+Zzmb0Rf1NRMYtwLZ2t/DZR7irQQnULfxsW+p0ojb4jbefg8p/jOVfRE/esDEY6Ru6SEX8K2Uey6n1NWjA53kDwLfoK9+zqN7X8gF/PX6UFjsx4n6D9TXhKjgPqTWR935nxzH9qGdRuUX8FX9b0GKNeF/pTsid27nV53LG5t4bifYVWiX3gnz/YX/SgphTN3VF7a67vP/tWQYJNxUm3lb6Uw+JZGtH8R0AUXJvpa2tfRPQLoSjYGBsbAv2gqS3A2JJTMBubLa/jQfOowcpNzp+lVps62+5/rwr6pPQjBf3C15/wNgv7lao+XR3dBp6VQZ14m/mf03V9Tf8ABGC/uFoOg+B/9OnsKD5a+2rzFGJk0yu1+AVj+Qr6qXodghugQegrIh6O4Zd0S+1B8ybJ6G4qf+xw0l+FxkHqZLV1vo91Qdg6YlcdNFOAf7MIQuYEFQWXvCxO8eNdRhwyr8KgVdoKWW9RXpX0SjxKkgWcbj+h51LK8NB857c2K8DFJF/ZhUeeN4R3Bnj4xk6qP4D+hr6U2/sCPEoVZfI8R5VxrpN0Zkwr6gleDfvUEMjKSL93dkG9NzxnmvLy3ciNxuRTkak3H493o44Hx9wOPuN2dc51JSQbmHHwI41rTjTmyyfdy7swHcfkGHLx9rUFza0cRu2qsdO783gRuP8A2rTohHdCajefi18/hFVYzF5iPlZDuGq6cvDw10qy2JY213fTy5elBe7Mnebeo/r2Br3uDxPt9WufYCsUAndc+Q/U172fl73PstBkfa8puqqDzClj7yXsfEWqzJiXbffzJ/bSgi8/ov53NVCHwHqCf9RAqiz2njfy/YfvQoeVvM2rJUC28+Q3fS1FAvouv9ctaDGER5+w/oVdTDDjr/X9ca3OzujuLnI7OBjfiRYe7a/SplsfqgxcusrqgPAC59zp9Kg5wBwFh/X9bwarhgL6KrMeQ1+g0+ld82N1NYWOxlLSHxOnsKm2y+ieFgA7OJR6CqOH9EOgUzyI7JIACCCGKEe1fQGzo3CgPvtWUkYGgAFV0ClKUClKUClKUClKUClKUHlYG1NmJMpVlBvzrYUoOKdLOhzQksgunLlUB2hs9XGVxfkeIr6ixOGVxYiud9LOgma7xDXkKD56xezVjJBkB5Ab/Xl5a1SsYXkPMC/1ufoKkOI6CY1JCBCzb7MNN58tDrWy2b1V42Ui6Kn81yfraoIYxB3kk+p/PT6Uz8hbzP6D9q7HsvqUOnbSk+A0H0FTLZHVbg4bfdgnxoPnXCbNnlNo43N/wrYfWpRsjqxx0xuUCA87k+1fRuC2JBELLGB6VsFQDcKo4zsfqUXQzyM3hew+lTnZHV3goLZYVvztr71L6UGLh9nxp8KAelZIFe0oFKUoFKUoFKUoFKUoFKUoFKUoFKUoFKUoFeGlKDHKC+4e1XYxSlBcpSlApSlApSlApSlApSlApSlApSlApSlApSlApSlB/9k=" alt="Saco de Lixo 100lts">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Saco de Lixo 100lts - 100un</h3>
                        <p class="product-description">Sacos reforçados, ideal para uso comercial e industrial.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <div class="product-card" data-aos="fade-up" data-aos-delay="200" data-category="garbage">
                    <div class="product-image">
                        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUTExIVFhUXGRYaGBgYFxgbGBgYFRcYGBcYGxoYHSggGB8lHRUXITEhJSkrMS4uGB8zODMsNygtLisBCgoKDQ0NFQ0PFSsZFRktNysrKystNy0tKysrNysrKysrLS0rLTcrLSstKysrLS0rKzcrNystKystKy4rKystK//AABEIAOIA3wMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABgIDBAUHAQj/xABEEAACAQIDBAgDBgMFBwUAAAABAgMAEQQSIQUxQVEGBxMiYXGBkTJCoRQjUrHB0WJy8DNTgpKyCBUWQ8Lh8VRjc4PS/8QAFQEBAQAAAAAAAAAAAAAAAAAAAAH/xAAVEQEBAAAAAAAAAAAAAAAAAAAAEf/aAAwDAQACEQMRAD8A7jSlKBSlKBSlKBSlKBSlKBSlKBSlKDR9Meka4DDGdkMhuFVAQCSQTvPAAE6XOm41y7bPXVMWVcNBFGDlBaUs5DG2YBFy3tm56+Fdg2zsqLFRNDMuZG9weDKeBHOvmfrL6Jy7Nms+Z45GLRTDS/Aq/JwLeB3jfYBjbR6ytqTy3OLePvCwTuKNeS79/G9brZu3No4vERZcfiT8IU8c1tQqR91rniwOg141zzDkFgXzEcf/AD619H9S/RyOPCJjGT72XNkv8kWayheWYKGJ43oOgYDtOyTtbdplXPbdmt3retZFKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUCla7b224MHC02IkCIOe9jwVRvZjyFcb6Rdd05YLhYFiS/xyWeQjmFByr63oO61EusjZ+ExmDkw088MbkZomkdVySqDkbvHxIPgxrgWP6dbSxCs0mNmVCSAqME9+zC3rQ4Ux3Mkgzm53nUnmefr+lBjQ4ELNGk0ixKSMz3EgUXBJtHmubfL719L9HusfZBRYYsTlEaKozRyKLKAosStq+bsXGhCtusxBHAA6g/Q0hUq5VSOBU81PDTd5+FB9h4LGxzKHikV1NiCrAjXdurIr5dwO2pI1EkReKRTZuzYgkbwdNDfy3+dS/YvXHiV7skceItwv2Up1tpvRz4aEkaXoO50qIdEesXB49uzVjDPe3Yy2Vyd5Ci/eIsdBrpUvoFKUoFKUoFKUoFKUoFKUoFKUoFKUoFKVYxuLSJGkkNlUXJ/IADUkmwAGpJAoK55lRS7sFVQSzMQAAN5JOgFc02t1tLJN9m2bEJ5TcCRzkiuASco+KTd4A8zUS6ytuSY7EJh7PlS5aG/dVt4DgfE6rfMNcpuBuJMXx8seEKFQ32xdQqgLHArKLZ7i7PqTbhccRQZvTuHENaXH4oyTkEiJbBYQDYd0Gygnja9qgB7500G797Vm7Rd5ZDncuxPea97njrc3F+PGsvo3GrSliLrHY7tCeHhwoM/ZPRPF7QYRYWLuJYM7HKiX4ljv3Hdc150u6JybPZI2JZSNHtYF/nUfmOYINdh6qWKrK+pQkLmsdSneJHPVzpv18KowsMW0Jcfh5WDxSZGW5+EquUMv4WFgcw3i3A0HCoEBuDut+v56XrHmGRk4jUDyuNPqa3eM2UcPM+HkPeDABhaxBNgSL6CxB9/TExmEKZcw0zAjUEHL8WvoPegCYg/Q+NevZu9uPHS/rbj4ivThHKmQKcmYKWtorMCVBtzCnwryOK5y6qbXBPEWvfXgeBoMrHxMojaYEodYZ0JzKVOoDfMAeB7y+1TLor1q4vBFY8VfF4ews4I7YAcQx/tP8Wum+ofsvHCMNDL3sNIRnFicjWsJFG8EaXG8hfAVXtHZZw9wcrwupeGQEEML8LbjY68xY8dA+nOj23sPjoRPhpRIh0Nt6tYEqw3qwuNDzHOtnXyX0U6RT7PxCzwsQGID6EpIBqUdQdSL6Eajxr6W6IdK4Now9pEbOAO0iJGeMnde29TY2YaG3gQA31KUoFKUoFKUoFKUoFKUoFKUoFc72nts4raTRXthsCjyvyaWMaFuaqToPxITwFTTpBtD7Ph5ZeKqcvix0Ue5Fcs6NbLzYGbOcv2qZxLJxGGgGaU+rdoPWghOJ2oMIr7QYXmxBf7KrWNgfixLA+JIUcTc7qv7F6vJ8bhDMjFsSwWZlZh94shcDvHc/cLC5sQeG+td0x2bJLj8xjbs3WMRJfREsBCgHDuZCRzY8a+hOi2zxCuW25UH+UW4UHAOknQyTZ0aNimRWe4CqcxFgN5AsDqN16xurTYz4jtuyQyMCLDNlA0JzHQ3tpYaaka1vevbbBnkhQfCO0I8R2jop9RED61hbF2VG0xjglbDolmaVjmEZS2d7ra652A13DUnfQde6vNmvHCwcRgdoxyKzEKQAPh46BTqTvB41AehCZMRiFABdWcrfRQplyqtsp1bQgW57rV1DotsTFYct2+IimuiqGVCjEJ8GYZipIBIuLaWHAVAcIww+1mgYayzynT5USBTC3uWH+Kgs9aWyMjwTHKe2kCPZdEsODfFvJ18xaoj0rw3ZYiHCsLBUZzc3B+7c5tf5RwrsvSDACa8TgHuZ4+NpEBuR6H86gXTDZZfb+GjtpJhHt5/Z8SPzAoIJsLGGBjHIheCXNFPH+Ix6sFPBxmV0PM24mpt1odGckOFxmFcyQdhFESAPhjW8bm3BgxvfiBzrXdOcNEXiSOMK7wI5ddD2kQuhbhrGJBfeSEHCpH1WbSXF4afZeI0DqzRjXc2sijkASrr4MwHwUHMdv4qN3jZECqYluB+MFgxv6D6+dZewMG+JQ4cSAIokkjznQOApdAflzLduV04XJrV7ewDYfESQPvRiv7Gsropj+wmGb4WsACL3OYWHkQSPI0GVslm+/wgCkTKVQOBbtIczLb8JY3W4/ENazOgfSJsE0cg+AlsjG9wlwHRgPiA0uOAKsoB37/AKNdHGxODx2TSaLEnsr71kgVSDr+MNY+QPlpsJgkZyWUdg80E4XdlXF54MTH/CY5VVfDsxzoPovZePSeJJUN1YAjW+/xG/z41lV899XXTVtn437FI4bCySFbm/3bMbJIPAki48b87/QlApSlApSlApSlApSlApSlBDutHFhMKgJtmkHrlR3P+moxtLEZlweyYh97KsZxBH/LRz2zr4E6k+AHOsrr0uYMPlPejkMoHMIAjXH/ANlc32PtpxtCOW+Z1kZhcnV2GW/rmIoOl4LZAxWOTEsgEUeInRLb3aPOFb+RRCviWPIazeSfsklc/Irn/ICfysag22ekIwkWDSLXKZRmI3lWWN3PmWkPjvqQY3aIxGzsRMhF2gmW3JsrBb+NiKDhOPftcdCZAGXC4WB3B+YxQIWHrKcvrUu6vsKC4imAPb7NxDtpa6yzmxt/JlrVYbYMmJkxYjGuJxEcCHfljJM0rHkoQRny866DtDYz4XamHmCH7OMFLCz27oKAsA3K4UflQY3VJ0rcGXZWKYtPhcwib+9iTQAeIFiOakcjWN1qYYRYvCY+MjLIBG511BtZt/4GP+UcqgXT7Dy4XHR4uA2cFZEcbrAi1zuK778LEg6VPNv7RXF7KkzRFcimYKT3o2ExjmQHdZCxtzUrQTWaRWjSVbnsyLEa3QnKfS16jHTV0h2tsrFy92JlmhL8AzowjB5X7Q+xrI6ott/aMLFGwAZVIAB3xxkIrHkSedWOtLEw4jC4cSC0bYiRbi2ZCiyIGXxB1oOVdINps0rZ1ytAoijtc/f4aRSSwG9cquTfmKzsDMyGPEwD7yBg6gXN43uyrzJF5EtxAccRUd2ckg2iisAztKIzfQMZj2RJ5Ah71OMBsMQYt8GGaSNfupJCtsrsocHwUN2qgn+9HMXC31wYHtnw20IrGLEqFJA+GRb906Xva414qahUWCMsXcH3i3ItvYrvA8bbh4aVPZMflwWJwMx73aGXDsTfJLG7HKT8veRd/Fzzpsfo9mxDODkjBViSLACRS9hzNiunJheg2HU5twFsQjnvSLBIuo7xVOxlOv8AFFr51Z6y8MmGw8wjF+1lV0tujZpI5Zlv+EtFnHIuw0G/XYyeOLa0MkKjIqZCLaMygliTpbSYXPgazunEvbYKQjUZkbmNHB3271t3LT5hrQcx6SoBOSDmzBHuNAe0UPp4a19Q9AdrnF7Ow07G7tGoc83TuufUqT618rbUU9q2bU34+Fd96g9oh8A0PGGQ6eDgEfUNQdMpSlApSlApSlApSlApSlByTrrndJ8I4N0UMHS18yyEf/j61zBg0Euew35kccr3Vr8dw9bjhU969dp9niEj/FEv0dz/ANX0rlOIvZSeNz4W03fWgnHSvbqTyLHGV7KELHGb3zBL3YnxNtazeifSgLDPg3fKZ8givwkd1X2sb/4a5mKob1oO6dWa/wC75J4Zh2qGRjBiEuxe5VJFMYGZWHZpmFtLW3AE73b215H2XtHUiXDfaEuRr3Rmjax/9tlNQXo90sywx4xmOVikGNtqUlUAQ4sKN5O5gN4IGuUCt51g4nJBi2DALOrPodHBwJizAjeC7IPSg5Z0P2mX2jDFiy0sc98PKHJOZcR3VIJ3WYowbhaui7IjaNdo7PluzJBKyOfmikgKh/UwwkjgzNyrjEEhfs7aSJqjDfp3h7EV3tpxN2eMQraXBzm9xcJJEWkjYbxaYKwP/wAg5WCNdVe0zgtj7Qx2mZSEizfCXygILcRnlF/KsfpxtKNcFgQHZlmabEpcagSZTlNuIZ3HkKgx6QE7NXZ6Xt24lLDc10y5T5NY1ldMdqLKuCjXRYMMiW8SxJProaC0drKmIjmse0jINiLd5d3kRofMCt50y6dmfERzYdzFmiDSlTZhKxTMpsLWQRIF36a8agrHUHyr2NdToDdTQSh5WkhkZnLMzqosR96C+VpAeBIYAnTVOdTbaXSqH+wUEBLI10PdYLYIM1gzWW1yQO781c3faarhYIhqw7xOuhEsjADx7+u7cN9Yb7RZiWZiSWLb+JNz7m3tQSbaOJWedmBygCM68rspNuNj2ZO7duFhUlw0/bYN420YXRhyNv6Nc5XH2dXHC4PiGqQ4PbYVr30YBW8cvwH6ke1BpOkkWXEuP5Pqi3+t66D/ALPeOyYueI7pYwR5xsxH0dqgm35VkdXHEWPmGNvo30qW9SrgbVjAtrDKfoun50H0VSlKBSlKBSlKBSlKBSlKD5+688h2gLuwdY0sLXU7zv3qdfKoUkKNYfCWBOQ6ob/Mh3ofcVLOu+Qf71ZSCfuYbW3g9+/n5flUEDsABe6i1uY8uXlQUOjglWIBH18RVLLWW5zb9fzqhhoNN3HnQZvRraKwu6S/2E69nL/CD8Mg8UJv6msbbGJxMathJJHyxkrk+WxbPp/Cxs41tqKxyovqDbzFX8diRKq5rlkAQE2uUHwg87bh4WHCg1WGfKQRvUhl8wb10vYO2Fk2XNhwe9AJ8njHMjnU79DK4t/CK502EG8HzFZOyMeIWe+5lK28/Kg1cRtXt68QVdyXoLDE0znnV84YcZFFeDDx/jY+S/vQYrN41Ur1lps8NopN+RKAnyuwvXsuzmQgMQPO1/oTQeYWBn3Lcen61vMLhsq5SB41jYaNFXTMfLNqfIVmbOhkmfJGmQcWkJ+ii7E+AFBW+ARge7r4EipJ1MwAbYQX+COf3yqOP81a3F4JYAczNIwvoAVTS2+3eYajlqQOYrY9TUg/3vE3F1xC+NhGjAn6+1B9G0pSgUpSgUpSgUpSgUpSg+fuufDkbUMpGhjVRfccqgn2zfWoLJh8+crw7xGu7S53cLgnzPKugdceLSedXQgiOSeFrb8yCAm/uR/hNRTojiFTEwGS5TN2Uo5pNeM38PvL+lBowCOFerY+tX+kOznwuJlw7k5oXKBjvZAbxt6qQfWsFZrGgqaqSK9m36buFW6C9GapeMcLeRAt/XrVKHWmbgaDHaNQdbqfI2/M1SYQd0g9autcbjpy31aZQfCgobC2+ZattEeYPrV0rXmWgtqlZ0e0nXcE9UX9qsBa8IoNzsvFzzyCPMddAFXUnflAA3+h8jUrhRIZmshZYB2fZg3bE4uXdESN+UWLDvAHwq30NkjiwcmI7NTiBK0cZJOVRkRybE2Frm7bzYCtnh4IMJhnxGKmCylHGFizfekyf2uIIHwySEmxPwrbdwCJba2h3jEzBmdh2hUaWB+BB+Bbtb8V83zGt51TYq+2YnAIVnxNhe+XOklh4bgKh8Km7TnKDdsg4Fz3UC/wqWFv5DyqY9ENlfYdq4LDkgyiRe0a91BeMkoD4bvMmg+kaUpQKUpQKUpQKUpQKx9o4sQxSStujRnPkqkn8qyKhnW5jjFsyULbNKUiA59owDD/AChqDhP2svhnWXWR52xBPIzK2f8A0p7GrJwtsP2oO+XsnA4B0zRP4XKyj/CK9xd2zNxZSfUW9tGq5hcUq4fFRN86xlf545VP5NJbyNBuOsSEzw4THk96SFFkJvcugswFhbQ5t+unGoNkvz9qn3RnGLi8DJgGvnTO8Wu+5LEedyagIUgkHeLj2oL0Av3d993ieXgeVUNER/5H76HwqkGstvvELfMvxi28fj/f3oMMjUVTJo1VS7gbVROdb0HjGqb169U0HhNeUoKD0mvYhc/l51RWVFCfgA7x38lXj/X70HqYqUqYlYiMksR8tyACT/lX2FeqwN1QFhxJHekYmygcQCSPH8qt4iUfAnwjeeZq9s7F9ge1AvItil9ytrZyOJXeBuva+61BN9iYSFWuy5xhRZSSFUtHcMddO9O0xBO4LUan6TyNio50jHbCZZFIJ71pMyL7aX434Vb2rti2HTDxnu5UaVj80hGYoDxUMzEniSeA1ydgYLs80jDNIqPK4O6KJELBDwzyGy5flVuZ0D6tia6g2tcA25X4VXWl6GbWGLwOGxAOrxrm1vZ1GVx6MGHpW6oFKVxTpf00xM8rJFK8MKkhQhys1j8TMNdeQOnjQdmnxKILu6qObED861OL6W4GP4sVF/hbOfZL1wRlZzd2LHmxLH3NDDUHZMV1l4FPhMkn8qEf68tajEdbkI+DDSH+Z1X8s1cwMIqjsKUT7Fdbsx/s8NGP5mZvyy1F+k/THE48IsyxBY2LKEVhclSveu5vox5Vq+wqtMPQYAB/CvsTzvvPia8fD33hNf4E/atgYbVWkQqUYeCwzKQy90jcVAB9wKrl2bG/xpqTfMNG99x9Qa2KmqZWqiN47o8wN4nDj8J7rj37re48q1wV42BIKniCLacdDwqUuKrRQwswDDkdfzpRFMXhtCyi6nX+W2/0rANTR9kJYqpK3BH4gLjxN/rWjn6MYhfhCyfyNr/lax9r1aNOaoNXZoyjZXUqw4MCD7HWqCKCivbV6BXoQkgDedw4mgvYJLnQXPyjx5nwG/2q/ItlKrr+J/xHkPCszD4UIlvmPxft5VZbDs5sNfAcPM7h/WlBrswGg1NZeLwPZBQxUuwuwBuE/hJGl+fL0NXXwqJvIJGpC7h5sd59qwZnZzYDU/ReFBiSvrccN3pxrc4faci4HEI2W0piA/Fo2dj5HIPY1qTHrYWPiN1ZGDwrTSxQ31kdVJ5AkD6C9B3zqCxr/ZJMLILNAysNdSuIXtRpw3/Wuo1wXoHt9cPt+RGFkxKRRDgFYRoY/cqV9a71QRTrIxkkWFDx4lYGDcTYyAA3RW3g8fSuA7RxGISRpH+9ViS+lnF9S38X5Hw3133rA6MjGRBxIEaIMRmNkINibn5d2+uF4jPEx/5kRv8ACQSuurRsDZhxye1qgYbFqyhka6n6eBHA1lxzA1p58FcibDuATxHwSW+VhwPnu+tMJjs7ZCMkg3oePip4jw/Og3mhplrDhlrMBvQe7qqBq0TVBeoq/QVj9p/V6vRoTRF4CqWWq1hPOrohoMXsqqVLVfMXiBWFLtKBTbNnb8Ka0GQB4VdMVhdu75kD6amo/jOkrrcKI4RzY5nPoNfzqP47aysbs0kvPMcq+1rH1ApBMsXtaIgxt98PwhQwHq2i+dxUY2k+EOqjsj4O0g8iAth6Ma0k2PdtNw5C9h5A3A9BVuCZQe8mcfzEfUVRkk1nYKMrrbXieQ5VkptWBrkwgBRobWbla43+tU4bFKy5h3R4628qovNYC8jWHBRe5/U/Tyr0zMwsB2UY4nQ+wrF+1quoGvM/Eb+fwisTFylj943ki6/X9aBLKCcoNl48z51b7VddCQeANs3Aa8hpoOXGrRcHQLbw3n151X9nfl7/ANaUHid0W41JOrzC58WZTbLChOv4muq/r7VGhhieZPIC/wD2HvUi2JtWTBwOsKL20jXMjm4jCiyhV3E7zc8+NB502R1xwkRshbKyHUENGqkHUaa2r6e6NbWGLwsGJUWEsatbkSO8PQ3HpXyFtLaMk7KGIdwfi1uxPMnfX0D/ALP+0A2z2gaRS8crnJmBYI9muRfcWLUG/wCsnaMC4V4ZJhG7gMoysxIRgdQoJANrXrhELB7yYeTS/fjbcT/EN6H+IV3LrA6NnEqHQDOo08RyvXFNq7GKuWGaKVfmGh8mHzCoMMA5iYxlfe8THuuOdx9HGvMUnhjnXUG6+jxnh6ab9xr1pwbLOuRge7Ivwk8wf+WfPSvJkKkZjlbcsoGhv8rjdY+x8DRWOuMeEhZtVOiyj6Bx+v51t45beu7kQawxJmvG6gHivysOa3/07x476wWgeDWLvxbzGd688p/r1ojePJXgNa6PaKlDIDdRv/EDyI51pptvSX0JUfhW1wPFiDr5Cgl8UV+NXzIifE6jzYD86gT7YkfS8h/xn/pAFWAxGuVB4m7H6k0ipxN0mw6aBi55KCfqdKxcR0la2irGp+Zzmb0Rf1NRMYtwLZ2t/DZR7irQQnULfxsW+p0ojb4jbefg8p/jOVfRE/esDEY6Ru6SEX8K2Uey6n1NWjA53kDwLfoK9+zqN7X8gF/PX6UFjsx4n6D9TXhKjgPqTWR935nxzH9qGdRuUX8FX9b0GKNeF/pTsid27nV53LG5t4bifYVWiX3gnz/YX/SgphTN3VF7a67vP/tWQYJNxUm3lb6Uw+JZGtH8R0AUXJvpa2tfRPQLoSjYGBsbAv2gqS3A2JJTMBubLa/jQfOowcpNzp+lVps62+5/rwr6pPQjBf3C15/wNgv7lao+XR3dBp6VQZ14m/mf03V9Tf8ABGC/uFoOg+B/9OnsKD5a+2rzFGJk0yu1+AVj+Qr6qXodghugQegrIh6O4Zd0S+1B8ybJ6G4qf+xw0l+FxkHqZLV1vo91Qdg6YlcdNFOAf7MIQuYEFQWXvCxO8eNdRhwyr8KgVdoKWW9RXpX0SjxKkgWcbj+h51LK8NB857c2K8DFJF/ZhUeeN4R3Bnj4xk6qP4D+hr6U2/sCPEoVZfI8R5VxrpN0Zkwr6gleDfvUEMjKSL93dkG9NzxnmvLy3ciNxuRTkak3H493o44Hx9wOPuN2dc51JSQbmHHwI41rTjTmyyfdy7swHcfkGHLx9rUFza0cRu2qsdO783gRuP8A2rTohHdCajefi18/hFVYzF5iPlZDuGq6cvDw10qy2JY213fTy5elBe7Mnebeo/r2Br3uDxPt9WufYCsUAndc+Q/U172fl73PstBkfa8puqqDzClj7yXsfEWqzJiXbffzJ/bSgi8/ov53NVCHwHqCf9RAqiz2njfy/YfvQoeVvM2rJUC28+Q3fS1FAvouv9ctaDGER5+w/oVdTDDjr/X9ca3OzujuLnI7OBjfiRYe7a/SplsfqgxcusrqgPAC59zp9Kg5wBwFh/X9bwarhgL6KrMeQ1+g0+ld82N1NYWOxlLSHxOnsKm2y+ieFgA7OJR6CqOH9EOgUzyI7JIACCCGKEe1fQGzo3CgPvtWUkYGgAFV0ClKUClKUClKUClKUClKUHlYG1NmJMpVlBvzrYUoOKdLOhzQksgunLlUB2hs9XGVxfkeIr6ixOGVxYiud9LOgma7xDXkKD56xezVjJBkB5Ab/Xl5a1SsYXkPMC/1ufoKkOI6CY1JCBCzb7MNN58tDrWy2b1V42Ui6Kn81yfraoIYxB3kk+p/PT6Uz8hbzP6D9q7HsvqUOnbSk+A0H0FTLZHVbg4bfdgnxoPnXCbNnlNo43N/wrYfWpRsjqxx0xuUCA87k+1fRuC2JBELLGB6VsFQDcKo4zsfqUXQzyM3hew+lTnZHV3goLZYVvztr71L6UGLh9nxp8KAelZIFe0oFKUoFKUoFKUoFKUoFKUoFKUoFKUoFKUoFeGlKDHKC+4e1XYxSlBcpSlApSlApSlApSlApSlApSlApSlApSlApSlApSlB/9k=" alt="Saco de Lixo 40lts">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Saco de Lixo 40lts - 100un</h3>
                        <p class="product-description">Sacos resistentes, perfeitos para escritórios e pequenos comércios.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Papel toalha bobina -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="300" data-category="paper">
                    <div class="product-image">
                        <img src="https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcQSvjwunXc8yNpaqA3WYpvxM4Or6IGBry1inEYtzOkdEMU4mQ2wH_J2BSY8_7i__keVFgXJ4I6cWB_Gnp06_zAf1hQ7w-wziTL-GjKtY0X0Cqn5bek7dGO6XJXwRg-0ZmDMd21OUQ&usqp=CAc" alt="Papel Toalha Bobina 200mts">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Papel Toalha Bobina 200mts</h3>
                        <p class="product-description">Papel toalha em bobina de alta qualidade e absorção para uso comercial.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Copo descartável -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="100" data-category="paper">
                    <div class="product-image">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRhCNonJWtJ8Oizy9kWOWRwOetvPHjHCdPLMw&s" alt="Copo Descartável cx 2500 un">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Copo Descartável cx 2500 un</h3>
                        <p class="product-description">Copos descartáveis de qualidade para uso em empresas e eventos.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Luva para limpeza -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="200" data-category="cleaning">
                    <div class="product-image">
                        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUSExIVEBUVFRUXFRUVDxUWEBUVFRIXFhUSFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQFy0dHR0tLS0rLSstLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAO4A1AMBEQACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAAABQMEBgIBB//EAD4QAAIBAgIGCAQDBgYDAAAAAAABAgMRBCEFEjFBUXEGImGBkbHB8DJCodETUuEjYnKCorIHFENjkvEkM8L/xAAaAQEAAgMBAAAAAAAAAAAAAAAAAQMCBAUG/8QAKxEBAAICAQMDBAEEAwAAAAAAAAECAxEEEiExBTJREyJBYTMVUnGBFCNC/9oADAMBAAIRAxEAPwD7iAAAAAAAAAAAARsBI8TMYtE+B6ZAAAAAACNwAkAAAAAAAAAAAAAAAAAAAAUqmlKSlq612ttk2l2Nmlk5+HHbpme6yMVpjenWJx8IJP4m9iW3n2IZ+dixV6t734RXHMyUfiuUtacn2L5V2I4F+RfJfqvb/TarSIjTnFaSc/2cJNK+cltfYnuRbfnXmn06yxjFqdyu4CGoWcS047xO/JkiJg3PRtQAAEWJrxpxc5bEsyvLlripN7eITWs2nUE9DpLTm2kmrXtntOL/AFus2mOltTxZ15U8FjZTnJyk32blyObPMyWvuZWxSIjR7g6/yt8ju8HkxaOi092rlx67wsqrG9rq/C+Zv/Wx76eqNqumfh2WIAAAAAAAAAAAAAAAAKdOaT/DWpF9eS56q/M15HM9Q5sYa9NfMrsWPqll6bSyV2972vvPMbm07bhhSyVy2OyC/G4y7smVb3KTLRdBWvsL8cbYyd4aF2kdTiY+rJEKck9jE77VAAAr6SRbou25r1OZ6tEzg7fK7BP3sCk4S1uDv4Hj7TqXSOMPXSd1sea5Fu2GkeJ0jPXSi7bc+GRhXLbr3E6ZRWNald0Nl37eLfE2Md5i21cx2anCVbq29Hq+Dn+pTU+YaGSupWDeVgAAAAAAAAAAAPJO2bySImdRsZqXSuLlJQinGLtdvOXauGZw8vq8xk1Su4bMYO3eSLFYzWcpyebzbOLlvOW82n8tisRWNQ60bi4PZmYx2TKzjcZFKyebMrTuOyFXR2GU3du75oxiNJlpcJTsjbxV0rmTTBwyvxO/wcWqdXy1ss99LJvqgAAQY6jr05R4rLnuKOVj+pitVlSdWiWBxNPaeFy17upEuMHPbDhmuW9GNJmY0lzNWlcwn7ZTEmmEnaRtR8sJPsJiEmnc6fC5PReO6jLTcG6Z6iJ3G4aL0kAAAAAAAAAABnemGklGm6MXaU1m18sd/e9nicr1LlRjp0R5ldhpudsbTjGOSy78+8843FfS9W0ElvYxeZkQ0K34cLk63IUrHyqSk28ksu9mxWkQNZ0ZjkmUW11IbLDm5hrtXJxTjZWPT469NYhpzO5dGaAAABEjC6Yo6s5LhJ/c8TzsfTltH7dLFO6wSynqTUt18+TyZp4/K1cxMbMjIJKVTq9qy+wrb7TSbCSeV3td/BmeOv5RLXaOrbuzI9N6ZyN/bMtLNTXcwO21gAAAAAAAABxXqqEXJ5KKbfJK7Mb2isTM/giN9nynSGMlVqTqyzebtuXBcll4Hj8uWcuSZl0axqNEM8bLW2iawlPOq5KF9+f1y+hHTFRYxUb03bgV1nuE+Dg/HyNm0jedHYWSNWveyJa/BRzR1uHXqyQoyT2NT0TVAAAAAGO6SwtVl22f0/Q8l6tXpzz+2/x53VmcdZo5NfLYXKdXXpwlxSvzWT8jLNUh5hp9a35k/FZ/crolbpSyXY7epdTxphLRYGrkjf41+mYmFV42eUp3SZ6zFfrpFmhManTssQAAAAAAAAzvTfHKnh9S9nUdv5VnL0Xec71LJ04un5W4a7l86nWThK3YebrHdvFVKg5Ps39iLNoWJSvLsWwiRYnXsrWvdWz2FcV7iPDUczKZG30NTskVY/ciWp0es+47/p8fe1s3hbxNZQi5Pcjq58v0qTf4UVjc6KKGkpyd72XBLI87/VMs23+G5/x66NaNdSjrbLbeCO7xuVXLj6/GvLVvSazovhpyMpNQWslv48jnX9Yr16pG4Wxx513MqFZSVzp8fkVzV3Cm1ZrLM9KV+0/lXqcD1eInN/pt8f2spjo2i32HH6dNhJgouNCCeTs3bm2/UnNO57JhAqtpx/iXmVUhJrB9Zrj5r2zOvu0iTnRc8jdxeVctDgZ5NcD0fAvuk1+GlljutHQVAAAAAAAAPm3+J9Z/iwjuUF4uTv5LwOD6pfeWI+IbfHjttmaFNqkk9rd36HMleFkmYjilC+YmRJ+GYbF/AULtIxtI2OjadkicUd2MtDgFtPRenR5a2aXWlYXpTXZ5Zm1zazOC0R8K8c6tBDo95HkKuip6cxr/APTB7ba/pH18CL8i1azjrPafLGKRvqlNonD6sSMNOxMtDouLs3xsvA9N6VSYpNvlqZ57kHSmX7V/wr1OX6vbWf8A0v48fazbhrtX2bbce1nJizYd4qdlYxkgspxlOpGK/Mm3wSd2WU1HlJw6n7Rdra8cvUwj3wg90ZJZG9SdSqk8wcrS5nb4Voi/+WtljcGB2GuAAAAAAAA+d9N462Kz+WMPVnnfU++b/Tcwe1naxz1yGSCFuNC0UU7Shk0iQ40HRv1jCe41GEjYuxQwk8wW89D6d4lrZfKev8MuT8jfy66J38Kq+WSw1fVg5cPaR4i9uncumW4OnrzcnndmrSOqdplosPTsjp4qqbSe0IWilwR63DjilIrDRtO52yfSLOtLsUfJHlPV53yJb/Hj7ClQscyFyriIXJkdYWkoRb3snYpVK/WV9zXmTEd0w0mjalnY2az3VtFQlnHmvM63Gn7oa947SanoWoAAAAAAAA+d9LJ3xNTs1V4QR5rnzvPLdxeyGZxFTrWNJar4id2hIa1J9VcjXFCSbZmNNoFWjYqie5LSUEbWNhJvgd53vTvEtbN5e6TnalN9lvHL1Nvl26cNpYUjdoYnEztHV4s8Lybd+l06wm0bCxnhqwtJ/hFmuaOtxo3esKL+Ds9S02L0nLWqzf7z+mXoeJ59uvkWl08UapClJGosQSiTpDiWywC2VHWqJbtr7txlWQ/0c879pbWe7GWlw8skdXj21qVNoOEekidw0XpIAAAAAAiew+WaXxGtVqS4zl4XdjyfIt1ZbT+3QpGqwz89pSycJ5iRdVS5UJqFK7RjMh/gYWaKxosOzapLGTLDVLM63DzdFlGSNw60pUi6clfasue1G5zuRi+hPdXjpPVDG1I3keHiJtbcujvsaYOkdDFVVJrgUtbN2t5nX4MVjJ1WnWlGTeuy3jsdGnFu6b3K+86nK5uPFjmYnv8AhTTHNpY+pM8dMzady6Udo0hZOjblonSHKiNCq42kRoN8BTzvxa8i6kMZPqGw6GJXY4oyvFcj0mGd0ho28uy1AAAAAA8kRbxI+QYva+Z4+/ul0a+C6sYJQAWqBhYNsFAqkOcMiA4oMupLGV6nI3KW0wmHtZ3RGWeqE17STzodY530/uW7XqELG1SquVlZIu3pBVjs2aeWJmVtdRCi6ZXFE7eanv33mXSbcuA0PHH3795jQgVLNe/f6mOg1wcSyvZEmtFm3jtphJtgn1e9no+HO8e2lfynNtgAAAAAPGY28SPkGP2vm/M8hf3S6NfBbVMEoQLmFRhYOsIimQ1wwgM6LLaMZW4yL4lDtyJmRBq5leu4lbsi7xA4dQw2K1SNyJrtKGdMdCdo5QMZqnaNx9++4wmBw4+/fvIx0kU4e/fvMRAYYeBnEIX6aL6QxkywHw97PRcD+Jp5fctG6rAAAAAHkiLeB8dxjzfP1PHX90ujXwXzMUo0BdwkSq0h3hFsKw0oEi/SMqolZgy2EO2zJDyJNY7ivj69ml2X9PRmV5IcQqEQlJczhEvHmJEckYSlDJGEskVjAS0YGUQSZUIZFkVYrCL6wxlf0f8AD3v0O7wP42rl8rRuqwAAAAB4yLeJHx7HR6zXa/M8ff3S6NfBfMwSjREhhgolVg8w0dhgGNFAXaRnCJWIFsIdmSElKm5NJb/dy/BhnJbphjaYiNyU6QpSjUalt+jW5oxz4bYrzWzKlomu0dORWlYjMnqHesRMp05bMdmkcjGZSjZESlYoIshBjSViyPLGUly+WBhgF1e9nc4UaxNbJ5WTcVgAAAAAIkfIdKRtUmv3pf3M8hm7Xn/LoV8FdQrZOIkSGuj43KbB9hoGAvUomQt00WQhNEsiEJEW1qiZNMDh9VXe1/RcD0PC40Y6bnzLTyW3KDTWC/EhdLrR2dq3ojn8f6tNx5hOO+pZa55yW4lpyMUpUyEvWQOWQOEvfv3tGhapZGW9C7CRZWWOkiZfE7lBng11F72nouLGsUNK/uTmwxAAAAAAB8p6Q09WvVX+5L6ts8nyo1ltH7b+Od1gjqGuzcxRjIdaLiVWGgoRMRcpRMoglZjEtiGKWKLIhC3gqOtK+5efA6fB4/XfqnxCnLbUaNEd9rAgZTTeD/DqXS6ss1z3o83zsH0sm48S3MVt1UIs0VqeEjFLtsDkgdwiTECxTQmBZgZ0hEpGX0juwk4pRskuCPUY41SIaM+XZmAAAAAAA+Z9MY2xNTnF+MEeX58azy3cXthmKjNJa9pIiQ90erGvPkPcK72JgMYxsXRGmKxqFsVQ7hBt2W8vw4pvbUMLTqNnFGkoqy9s9NhxRjr0w1JncpC1AApaVwn4lNres48+BqczB9XHMfmGdL9M7ZF7Ty9o1Om9DqMjFKWMgOosCaCMkJ4IRGxYhEsiEJIK8ori15mzxqdWSsfthedRJyj0zSAAAAAAAAfMemsv/Kqfy/2RPL+oTvPLew+yGaaNJYnoRMLSGuGdimUnGElkmTCDytDWgmuBsXruu4Yx2lLhamtFPfsZZjt10iUT5McDR+bwO76fg1HXLWy2/C6dRSAAAAzOn8Ko1NZKymr/AM2/0PO+pYIpk6o/LbwWmY1JWjmrnpCXcJkCxTkTsWqZlVErMS6GKTDLrx5+hucP+aqrJ4Nz0LVAAAAAAAAfKulrvian8bvySX6HlObP/fZvYvbBGjUlYsUiuUr0JWRiH+i4a0BEIk10VVunB7UbOC246ZYylpx1JtbpbOZhWv08vT+JJ8H1GNorkexwV6ccQ0LeUhagAAABQ03hlOlLc49ZPl+hpc/DGTFP67rMVtWZCE9zyf0Z5WL99S3tJooyBbuMRJBsC9QZZVC3Fl8Sxd0ZWkn2l/Hv05YlheNwcHpWmAAAAAAAA+UdL2v81Vtvkv7Vf63PKc7+ezfxe2Ciktr4I0pZpaZjKVmtK0VzIGl0FKyROOdSxkxrw/Dmqi2PaW3icdotCPK9iFeOst2aLcsdVYtH47sYOaUrpPikerw26scT8w0rRqXZagAAABDi/gl/DLyKs/8AFb/Ca+YYqDTVpK6+q7UeLtES6Tt0JLOL1lxW1c0V/dVLqNVPajLriUadxpb4u5MSLtBMvp4YytJGe0PWzKLalEnFGV4p9h6nDbqpE/LRtGpdlqAAAAAAAfIOkLviaz/3J/STPH8mf+63+XQpH2wpR2GvLJ3T2kJd4uXwoiBq9Fw/ZpiESdYdqcdVmxT769MsPDzCNrWpvde3IjFPnHP+ifk/pRskuCR67DXpxxHw0bTuXZagAAABHiI3jJcYtfQryxukx+kx5YKns5Hify6SbD1XudmBbc0/ij3ojUT5S8/y62xd+xuzI6JjwbW6EXvTLaTP5hjKxYtQ9UuGfkNoNcA+ou/zPTcGd4Ky0snulYNxgAAAAAPGRbtA+O4/Oc3xnJ+MmeLvO72n9y6MeIVUYSlJAgcVpXkIS2+hlemuQp3Yyu0ZasjKlumyFutHNTRdk3FovCP0dUpXSfFHrMOT6lIt8tG0anTstQAAAA8ZEx2GBrQ1Zy4XafieIyV6ckx+3SrO4Ryyd0YMjHBVlLJ932EIlLVo6ruidCzh5xltSTLqzEsZTdXcvoZaQG2wGmjo2h3s9H6dH/TDUze5aN9UAAAAAPGRbwPj+IjnPsb82eJn32/zLpR4UjGR0pARwzYS3OgpdVEY57okxrQzuZ2qhaou8bGxX7q6YmmBfUXeeg9OneCGpl9ywb6sAAAAAYbS8Wq012v65nkOZHTmtH7b+P2wo1ZtR7e318TW6drFenjXC145Pg/vYdAd4TSUJLVk7cNZNfUy6ZQs0Y55Z8s0RETEi8olyHreQQZaO+DvZ6P0/wDhhp5fctG8rAAAAAARI+TaRhq1a0eFSS/rkeLyRrJeP3LpVndYKp7StLmTAkw0MxI1+g55GFZ0iT2SubHlg6o5Mmk6sSb4NdXvZ6bgRrE1MvuTm6rAAAAAGH0tPWrTl+814Zeh47m36s9p/boY41SFeMjV3LN3HAQlmoq/Zl422k9RpHDR1neLs73zjt5uNrkxcPMK4r5VFu12o2vYtrfflitMs0h5YBrg11Eel4Uaww0snulObbAAAAAAAHzLpJS1cVWX7yfjG/qzyPMr08m8OhjndIZ+ptNZmiWb5EhhhKfv35+phaUtDo/L3f35vaU/lEtDh5dVM2qzuGEurZ3MkGmAndW4HofTcm8fT8NXLHfa0dJUAAAAGRIwUpa0pPjJvxZ4jLO72n9ulXw4lErZJKNZxYgNKclJJlkITQgZ1qxWLF0IeMINcH8EeR6bifw1ad/dKY2WAAAAAAAMB03pWxDf5qcX4OSfkjzPqlNcjfzEN3BP2MfXe/mc5ckhTslx3/YiUmeDp2V/DPt/75MqtIZ4aps+3v8A72mCGhoK0Y7t/ibNfEMJWbF+kLej3n3HT9MtrJMKM0djA7rXAAAARYqerCUuEW/BFWa3TSZ/SaxuYhgqLPE77unpPJBD2mr5BK1RyZnDGTGmy6GKUyHMiQ0wL6i97z0nCtvDVpZPdKwbbAAAAAAAGI/xCptSpyXzRlH/AItP/wCjz/rFJi9bNrjz2mGLVJylbdv9+PicmGy7qq8uPv34lcpNsEpNJW92K5DjDYayMUG1FZLsSRs0YSuxRtRG4YJsIrSRvcDtmhXk71MTvtYAAAAp6SYmUKdo/O9VvgrbO85nqme2PFqPz2XYKxNmQhLM8o31iDJ2h3GJIuYdmcShcpMsrLFPcs2h5ImO6F7R11l7udr06bRuv4a+bS8dZQAAAAAADL9OMO5xopJt672Jt/Dsy95HG9XrM1rqNztscee87JcP0VxEl8Kgn+aWfgrnOp6fyLR7dLpzUhfodCZfNWt2Rhf6tmzT0a//AKuwnkR+IXqHRNR/15v+VGX9Ej83Y/8AJn4XIaCtsqy74oy/odf75R/yJ+E8dGNf6j/4os/o9f75ROaUiwTXzf0/qZR6ZNfF0fVe/wCXmrWs/oI4WWlomsxKJyRMLiOvCp6AAAEWJoRqRcZK6fu6K8uKuWs1tG4lNbTWdwzOkNBShnG812LrLmvseZ5XpV8U7p3hu4+RFvPYtjRfvac2azHlcnhTZAsYeDRlWULlO5bEoTIsrWbTqIYz2WaOFk9uS7dvgdLj8DJfvbspvliPC/SpKOw7eLDXHGoa1rTPlIWoAAAAAAAAAAAAAAAAAAAAAAAAAENbDQl8UYvmlcpyYMd/dWJZRaY8Sgei6X5bcpP7mtb03jz/AOWf1r/L2Ojaa+X+p/cj+mcb+0+tf5SrBwXyr6strwcFfFWM5LfKSMEtiS5I2K46V9saYTMy7MwAAAAAf//Z" alt="Luva para limpeza">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Luva para limpeza</h3>
                        <p class="product-description">Luvas resistentes para proteção durante a limpeza doméstica e profissional.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Desodorizador aerosol -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="300" data-category="cleaning">
                    <div class="product-image">
                        <img src="https://images.tcdn.com.br/img/img_prod/1014612/90_odorizador_bom_ar_air_wick_aerosol_aerossol_aromatizante_de_ambiente_360ml_unidade_3365_1_a2ee7ac4fc45d9858de0a235c03ef901.jpg" alt="Desor. aerosol Bom ar">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Desor. aerosol Bom ar</h3>
                        <p class="product-description">Desodorizador de ambientes com fragrâncias agradáveis e duradouras.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Água sanitária -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="100" data-category="cleaning">
                    <div class="product-image">
                        <img src="https://p.turbosquid.com/ts-thumb/dg/EoF5s4/iO/fabric_softener_01_blank_thumbnail_0002/jpg/1680889531/600x600/fit_q87/11c78080c295f795cd9ed5d0beb9327995d3288e/fabric_softener_01_blank_thumbnail_0002.jpg" alt="Água sanitária tipo q boa 5lts">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Água sanitária tipo q boa 5lts</h3>
                        <p class="product-description">Água sanitária de alta qualidade para limpeza e desinfecção de ambientes.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Sabão líquido lava roupa -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="200" data-category="cleaning">
                    <div class="product-image">
                        <img src="https://p.turbosquid.com/ts-thumb/dg/EoF5s4/iO/fabric_softener_01_blank_thumbnail_0002/jpg/1680889531/600x600/fit_q87/11c78080c295f795cd9ed5d0beb9327995d3288e/fabric_softener_01_blank_thumbnail_0002.jpg" alt="Sabão líquido lava roupa 5lts">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Sabão líquido lava roupa 5lts</h3>
                        <p class="product-description">Sabão líquido concentrado para lavagem de roupas com alto poder de limpeza.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Multiuso -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="300" data-category="cleaning">
                    <div class="product-image">
                        <img src="https://p.turbosquid.com/ts-thumb/dg/EoF5s4/iO/fabric_softener_01_blank_thumbnail_0002/jpg/1680889531/600x600/fit_q87/11c78080c295f795cd9ed5d0beb9327995d3288e/fabric_softener_01_blank_thumbnail_0002.jpg" alt="Multiuso 5lts">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Multiuso 5lts</h3>
                        <p class="product-description">Limpador multiuso para diversas superfícies com alto poder de limpeza.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Hipoclorito -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="100" data-category="cleaning">
                    <div class="product-image">
                        <img src="https://p.turbosquid.com/ts-thumb/dg/EoF5s4/iO/fabric_softener_01_blank_thumbnail_0002/jpg/1680889531/600x600/fit_q87/11c78080c295f795cd9ed5d0beb9327995d3288e/fabric_softener_01_blank_thumbnail_0002.jpg" alt="Hipoclorito 5lts">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Hipoclorito 5lts</h3>
                        <p class="product-description">Hipoclorito de sódio para desinfecção e sanitização de ambientes.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Álcool perfumado -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="200" data-category="cleaning">
                    <div class="product-image">
                        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw8QDw0PDw8PDQ0NDQ0NDQ0NDQ8NDQ0NFREWFhURFRUYHSogGRolHRUTIjEhJSkrMi8uFx8zODMsNygtLjABCgoKDg0OGhAQGisiHyAwNSs3LS0tLSsrKy0tLS0tLS0tLS03LS0rLS0tNy0tLS0uKy0tLS0tKy0tLS0tLS0tLf/AABEIAMIBAwMBIgACEQEDEQH/xAAbAAADAAMBAQAAAAAAAAAAAAAAAQIDBQYEB//EAD8QAAICAQMCAwUFBQUIAwAAAAABAhEDBBIhBTETQVEGImFxkRQjMoGhQlJyscEHM2Ky0SRDc4KS0uHwFRY0/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAECBAMFBv/EAC0RAQACAQMCAwYHAQAAAAAAAAABAhEDBCESMQVBURMUQmGRoRUycbHR4fAi/9oADAMBAAIRAxEAPwD67QqLFR1WQKi6FQEgVQqAVBRVAAkMaQ0gBFISKQDQwQyAjFlz44/jnCD/AMc4xf6j1c9uPJL92En+h8+y5K3V5t3z3MG83vu+OM5bdns/eM84w7ta/A3XjYW/RZsd/wAzN35XmuPifMMk+JWl2fc6L+z7O3DPC3UZRkl5Ju02vTsvocdp4lOteKTXGWnd+GRo6c6kWzh1TRDMkiGes8lDJKZICBoYMkTRLRZLAkRYiBImUS0BLQqKEBAx0BI2oigogRQi6EBNBRQATQ6GAAhgNIAQ0BSABgMgebqMoLDlc2owWOW6UmopKvU+e48+PwsnvNvnj7y18XFc/ofQupaqGLFPJNKSirUG0t8vJHzle0lPUNxjuy70oQ0XixUfjKWaN+f7Jm19h7zMWxM444+bZtdxbSiYiO7WTz45RnTkrq/dyxX0rk6r+zzJjvUpP32se1SbuUI2m1fem18rRyGPr2o5UZYY27VdM5+q1PxO09ieruSliy+Huk5ZI5I43g3Sb5i4uUvnd/kRo+ETt7Rfpnho3W91NSk1ntLq5GORkZjka3loYimIkIVFCAkTKEBIMYiBImUxASIpkgIAADbiGFAITKoQE0FFUAE0MdBQCGkMaABgBAZ4up9Sx4I3J3Jr3Yeb+PyM3UMk4Ycs8aTyRxylBPtuS8z4lqeoa/Pkm8mVW5Pdxul37VaRq2u39tbmeIWrXLqusdUnnk3OXHNJcJL4I12KLvhfzbofS8Wtaj4c9PUZx97Jp9LCTvjm7sz67RaxOSz5G2pNPbsir9agkezpRWk9EY+vP0W7diUfgj0Y358Jmt+xyf8AvJL/AJpf6lz6dmahWdpeTXD7+b8/zO1or2ymefN2PS+stVHK9y7Kf7S+fqb2MlJJppp9muUfM5aPWrdtzwkuEt8Y1+Vp8/I3fsXm1X2jLiySg8SwqTUG3HxL/ErSrulS9DyN1t6xE3qrNeMuwYimSzz1AAABLENiAQhsQCEyhECWSy2SwJAAA3ADYgATGACAYAFAAAAAMAGgAgefqcJSwZlB7ZvFOpVdcHxzTN3Lf4mRp023tTd/Bf1PtU42mvVNfVHOaP2W0cG21myNttyll2Jtv0hRs2e5pozPV5+i1ZcZj1c6UYucEnxGOfNSfwW6hOTbtuTfq5Nt/U+gLpGki6+zYnfnNPJ9dzCeDFG1HBgi16YYL+hs/EtOO1U5cGkvWvzM2OF1z8uTq9TkcfwqK44qEUayerybl73mvJEfiOfh+6Mta8cuUpZE3xcZQ7Hr9nME467mcuNIpuL2+8pSa5p80/MrW6nJFxalSunwjadIySeSF008Heknak7/AKGPV3/X/wAdPdOOG5YmMTMygBiBsBCGIBCGACYhkgDJGSQAAsANwIYAIBiAAAYCGgAAABgCAAAH5nlxK1NP14+R6mYFJKN+jbv+Zzt3harz58tRbpvZfbi6+Zj1Hr2pW2+FVXyTnzqSdPdaatdr7GDX5l9mnJ/sw9/zSSdS7fBSLW4jJTm2HOdWya3KrwTxaPFb2vJh+0aicK4k02owv933uO7TtLj5+0mr0mojj6j4OXT5JxhHW4IeE8bfnkh2r1rt8ex1H/zTzYcuTGtzhN40/CyJt1a9xu2/k3ycH12GXVYNRHJjzY5Y5e742OCc5xt+640nF9uPqzPGtaJy1zo16fm+ja+F438HFnu6LNPNg558DN6U+Ys1HRZvJosDle96bDvvupqCTv42mbD2fyS8XBHhxePUXzymnGlW35+f18ulvzwzeTqGJjYmd3MgEAAIAATEMQAyGUSwJsAEAAAAbmwEOyAAAAIYCCDAEASBiABgABBHOdW8eM5y3tY391p8KuMXklKO7LOuW0k6V17z9DozmfaHXyWPbGEJJTeRZJZnhqEVzOMl8JNWnxZXqitomf8AdiaTeMR3erTxXieHFtrFhXiJ81NtOO5/vNOT/wDUZ86rG1GKVR4jFUvWkkajQayUIuKeng5Vm2rPByqUHzJt88pcvur9DPj1ebIoJPDvaySkoSUouMZRVpqTV8q+f2haeqF6V6Jcv1fXzdqLjjUHbjLZjqNtJpykr7P8JptRrN8ZZMlxjCE5NyX7Eb97jypfmdX1vR0uYqVq33ST8+PS7OO63Fyw6mEU7lp86fHL+7lwefMYtiXqxaJrmGy9h+tQ1OHPGCaWny7IuSpzxyW6MmvJ2p/odJ0VJZ9Oqim46l3dSfwquVyvP0OU/s36RLT6N5JtOescMyS524kmoc/G2/zR0vSpr7Xok5PdKOt2xvh1GFt8eV/qapjFqw82ZzEzLrmJjZLNLkAEAAxAwACRiYAQymICRDYgJAAA3KGiEWQgwAAAAABAMQDAQAMAAANJ1LRYs0kskFNxc4pu7SlV1XyX0N2aecvv0nxbTVvu6ujPrzzWPV30e8vJ1iOHG8OFQlKeolDF93KUXHFuScm/L0vu+eRYupYYpylswxlnngwNvnMk1FyS/i/p6i1nSpZNQ86zNTWSEorlwWJYnGKa85KcpS/N9rPHpOkyvDJanHlWDF9nzRjCM0pRmpVB37suI3avz7s04rhz5YepdV07eoj4qk8CSyVbUblt2qu73Jql58HKz1MJ5cSxJShkxeLOTUk1GT2wVPs21Lv6G51PszkjijWpnLNhnjeOaxRpYoOTS2+bublfqYdB0KOHK8inNrZCEMcnxFxht3Pzb79/VnO1NPPHd2rqXiPk2OkzJwUdixOMElBJKCSVJRrsvh5B0rGnqdBLm4/bFx4m3mEO9e75ftevHdmPJmjBqD/FOGRx4viCtt+i7fVE6JL7V0l+7zk1aVx3PnDfuunt7eq/MpaJ66qTjEu0Yhsk7uQENiABAwACWNk2ACBiAQmxskBWBLAIbpFEopAMYhkAAAABDEAMAEAwEFgM5T2kxzWZZVGMvsumnqG9r3Oalugo1/wqfwb9TqzT9a1Eo41OMJ5HcltxrdTq7v8AJr9DneemYt6LR6OfyavVPFmyQzKKw4cVNYoylly5HNx5qlGpYbaXk2eGWeWlzS0uN5mlm0mOUo4Ocn3bnKblVNySx479IN97Nvpuq58cZRekzZpRlJOUJLa5XLe7a7fhqru2vJWajrGo8ObhppqbzPDhjJydY9ifjzTiqptrb2e38Suy068RxhOMuT61ruoSlqZwnqMUL1Dx44YnJqPjLBFLjl/im/Nd/Q8/UtXrXqsTWHVRhilplBKUVieOWOTm8r7Sk3tUv3Un51e+651XMo4JbZadZVm8SKeKeXG0/u3zVp2n5VST7tHPT12pnU2692bcW4+7Lc1FUov3X7lyvi36E03FZ7lqW7xEvNLDq5S1c5YvvMsFGTnnVZIPU+9jik3ti8aivkvOzuOh4dj0UK3PHHw91J7axU3z27fqcv0ec8uVqck5OEd23coUmuya4/a/lbo63ombflXuNbG/xNJrh26/8+Zni976s5xiPRaYiK+bo2JgBqcwSMQAICQGIBMAJYCACWMlhBAAAbhMpMx2FgZUxpmKxpgZLHZjsLIF2FkWFgU2KybCwKsLIsLAuzTa+WoU5whjnkhLwnCSjBpcy8WEm6XlGnfefpFs2tnzHrkcv2nUTjJ/3jT2NxfHH9Dto7b289Mzharp4ZtRFbfs1NuU5XmxrbJrdT9PedWr82YXn1LnH/ZnHG9lyeTFLZbW9upW6Xavjfkjl9RmywWNeJlTcLf3k1y5P4mKOqyeeTI/nkm/6myvg0zH5o+k/wAu3tJdm46dyms+y/Aj4e/yblk3V8a8P9DkNVpsri1GDjLdJxm8SklbXZVSpOXw4jw02kRyyfeUn822XEtXwfp+P7f2jr7x6vb0jSOE3OU4xilkSxKMYtptbbe5v3VfHna/d52vTs2PHmxQjubyy2tq69eb+SXC8zU6aX8j0aP/APRg+GSP+ZET4bSkTMzMzH6R+ykzl2tisTYrPNczsLJCwHZNiYmwG2DZNisCrJbFYrAbZLYmJsAsCbADcWOytobAJsNw9obQDcG4NobQDcLcPaLaA7FYUAAIoKAk4PWyvUZmk397LlVXc7/afL9X4Pj5ljzSg1kknGckn387XP1NuxjN5WqOtx5xv/C1y16mvivivqbeO1/3tZY1x70cb/6lZgyxwfswSdc3n3c+tbT3NPUxHThZ44mWIPH8Yr82ZMcY+co3a5t1XyOs2GXE5JKlf50ezRSay4nKorxYNy3Jpe8u/YwY5w/ei+PJr6iyTjeP3JZUsmP3VFq+e1vyfwMmtzWR320loytEyPnMubGIptGNyAGJsiUjG5MDJvJeQxORDmBmeQl5DF4iJ3gZXkYnkMO4OQMm8DHQwOq2htMlBRUY6DaXQUTkY9obTJQUBi2iaM1CaAw7Q2mRxFtAx7QooRKSo+d9Zyz8fL4unm14k/exrHkVX6N2fRbPnvtPrvB1WVTi2pS3Ra9GrNeynGomrDoXcn4LnCVcrwp4n+tWVrPE2rxN2yntvG0q8zyLqGKSupL1T3L+h4tV1bFG6Vv4s9fEZzOFsFLNpr5lFv8AiX+pmw5MLUqjceHJqDlXp2NT/wDYlf8AdJr+Nf8AaevT9exvvHa/g0/9DtOpE8ZTht8GSPGyMn6VDb/motyytx8OMYT3R2ynJyad+i4X1PNh6njatW/hxb/WitJ1Hxc2PFDFki/GxqcnxGMO7brt2OOp2lGHey1C9V+RilqEYpwXqjDJI8GaYUZ5ZyXnMccTfkZI6ZlJQl5hORnWmMkcBUePYw8FnvWEfhDI13gsfhs2Phh4QyNd4bFsZsXhJeAZHg2ge3wBgdDQUUBQRQFCZIlgMVAITKoVEiWSZKE0BBNGRoTRORikjUdc6NHUxqSjuXaTVs3bQtpet5rOYS+Y6z2K1MU1jufLaayQnV/x7TnNV7I9STf+y5ZfGKg7+kmfcKFR3nd3nvhbql8Gj7J9RvnRZ35f3aX82ZMPsV1RvjSZYx/x5MMa+sj7qJj3q3pB1PlfTfYfWRpzxx3efiZoxivyhbf1R0ui9ms0eZ5IR+GONJfI61iIvutS0YRMy1OLpCXeTkeuGiivI9QGeZVYVhSK2IyCIEbUG0oAIoKKAhKNoNFiCEUKiwAjaBVCA3AABUIGAAJAAEhMAAAAAATEAEiWSwAlJMQASESAAJgxAAgACEAQwAkGAEAAAATAAAAAAAAAD//Z" alt="Álcool perfumado 800ml">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Álcool perfumado 800ml</h3>
                        <p class="product-description">Álcool com fragrância agradável para limpeza e desinfecção de superfícies.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Limpador perfumado -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="300" data-category="cleaning">
                    <div class="product-image">
                        <img src="https://p.turbosquid.com/ts-thumb/dg/EoF5s4/iO/fabric_softener_01_blank_thumbnail_0002/jpg/1680889531/600x600/fit_q87/11c78080c295f795cd9ed5d0beb9327995d3288e/fabric_softener_01_blank_thumbnail_0002.jpg" alt="Limpador perfumado 5lts">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Limpador perfumado 5lts</h3>
                        <p class="product-description">Limpador com fragrância duradoura para pisos e superfícies em geral.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Sabonete líquido -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="100" data-category="cleaning">
                    <div class="product-image">
                        <img src="https://p.turbosquid.com/ts-thumb/dg/EoF5s4/iO/fabric_softener_01_blank_thumbnail_0002/jpg/1680889531/600x600/fit_q87/11c78080c295f795cd9ed5d0beb9327995d3288e/fabric_softener_01_blank_thumbnail_0002.jpg" alt="Sabonete líquido 5lts">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Sabonete líquido 5lts</h3>
                        <p class="product-description">Sabonete líquido para higienização das mãos com fragrância agradável.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Limpa pedra -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="200" data-category="cleaning">
                    <div class="product-image">
                        <img src="https://p.turbosquid.com/ts-thumb/dg/EoF5s4/iO/fabric_softener_01_blank_thumbnail_0002/jpg/1680889531/600x600/fit_q87/11c78080c295f795cd9ed5d0beb9327995d3288e/fabric_softener_01_blank_thumbnail_0002.jpg" alt="Limpa pedra 5lts">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Limpa pedra 5lts</h3>
                        <p class="product-description">Produto específico para limpeza de pedras e pisos rústicos com alto poder de limpeza.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Detergente neutro -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="300" data-category="cleaning">
                    <div class="product-image">
                        <img src="https://p.turbosquid.com/ts-thumb/dg/EoF5s4/iO/fabric_softener_01_blank_thumbnail_0002/jpg/1680889531/600x600/fit_q87/11c78080c295f795cd9ed5d0beb9327995d3288e/fabric_softener_01_blank_thumbnail_0002.jpg" alt="Detergente neutro 5lts">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Detergente neutro 5lts</h3>
                        <p class="product-description">Detergente neutro concentrado para limpeza de louças e superfícies em geral.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Álcool 70% -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="100" data-category="cleaning">
                    <div class="product-image">
                        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTEhMVFhUXGBcaFxcXFxgXFxYWGBUWFhUXFxoYHSggGBolHRUXITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGi0lICUtLS0tLS0vMC0tLS0tLy0tLS0tLS0tLy0tLS0tLS0tLS0tKy0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAABQQGAgMHAQj/xABBEAABAwIEAgYIAwYFBQEAAAABAAIRAyEEBRIxQVEGEyJhcfAjMoGRobHB0Qfh8RQVQlJiciQzU5KyNEOCotJz/8QAGQEAAwEBAQAAAAAAAAAAAAAAAAECAwQF/8QAKREAAgICAQIEBwEBAAAAAAAAAAECEQMSITFBBCJR8BNhgZGhseHxMv/aAAwDAQACEQMRAD8A7ihCEACFQPxW6d1csFAUWU3Ordb2qmohvV9XHZaRMl/O0KtdAPxYxWLxtPDV6VHTU1gPph7C0tpveJDnOBnRHDddC8NkeP4i6C2V0dkQsWOlZLnGCEn6X5ycHg6+JDQ402SGmwJJDRMcJIXFR+OGODx6LDPbPqhlVpjkDrN++Fvi8Nkyxco9hOSR9BIUbBYoVGNeP4mg+8T9VJWAwQhcK6R/jPjKeIrU6NPDhtOo9gD21HOcGPLQ4kPAvG0LbDgnlbUewm6O6oVS/DnpY/MMIK9RjWP1uYQ2dJgNIIm4kOHNW1Zyi4tpjBCFzH8UvxHrZdiKeHoMpEupCoXVA5273MDQGuH8hMyqxYpZZax6ibo6chcp/C/8TMRj8Q7D4ilSbFNz2vphzbtcwaSHE8HzM8F1VplGTHLHLWQJ2eoQq1+IfSV2X4J2IYxr3BzGgOnTLjEmLmBKmMXKSiurGWVC4LlH41Yx2IpsqUsO6m5zWu0NqMcAXAEgl7thJ2Xdqb5WmbBPE6kJOzYhCxqvgE8gT7liMyQvn3E/jljSZZSwwb/IW1CQJP8AFrE+7iuxdCekJxuDo4lzAxzw7U0SQHNe5hibxLV0ZvDZMSuQlJMsCEIXOMEIQgAWFWoGiSQAOJWap3SLHelqB5IZTAN/VjQHk9+6qMdmJuiH0wwGExr6bqwe7qg8NhxaO3Go2IP8ISTKei+X0MQzEUmVG1GEkHWSLgtdIJPBxTN2dYUCespRxIAMeMCx7lqfmmG1R1tOfEfDhwXUpzUNFdE1zZe8uxjXiWkH5jxU6Vz0Zyym3rGuBa0xLIPGIturDn+NIYxontuIMdwm/cubR2VZj0sfQr0KmGqEua+A7SYsHB0T4hULEdCcsfGqnUtyqO/+k9GZ4dstc+mHAkEGC6QJNt1pq5zhYnraUTHAXvv/ALT7l0wlOEajZLVlryLGU9LabXeq0NGrchoie82T5pXO6GPpEwx7CbmAWk2Ik/EKw5bnGrCOqtJOkVNxeWFw+i5pRdlJjnHY9lP1jfkN1y7F9D8ueX66dQl7nPcdbrucdRNjzTmpmNJpBrPa0uBM1DvETJdxutb83w1x1lMEAkyACAN9wt8blj/5v6EvkmdD8LhcEw0aBc1jna4eZhxABvy7IV3pVAQuc0c0w9i2rTuYFxvMRHin3R/MwarqUmQ0OiLAExZZZE275Gi0V67WCXEAd6590oynBYvEdfWa9zgwUxDi0aA5z9gebipmbZiC+o6oYaxxbLtgAYt3KI7OMMP+5S5bAibcYjiFpiUoPZXfyE+SF0b6P4HB1+voNqNeQWmXFwLXQTYnmAujYHEte2WkEdy5/wDvTDTHW058QOX3HvU7B5u1r6Ra4EPe1gLQIMmLwpy7TduxrgvhKqXTJmGxdLqKupzA9rzpMSWzAkbi639IcaZZTvBBJjYwQLpC3N8MBepTtvsSIOm4iQJ4pY4tNSBu+BHU6FZY5wdoqhwuHB7rEGQbmN10vK8wY/Y35cVS6mb4Y6fS0+1tsOQ9nrDfmt1HMacE03tOkSdMEjcg222V5ZSn1sUVR0MFL81zCmxpaTcgiBuJEexLDm5ODFZpd2msgj1u04Ce43SF2PosdpqPYHETDokySLTubFZRg2NsQVOhGWaQw06kDb0ju8/zd5Vw6JNw+FpNw9EltNpdp1mfWcXkT4uO6UPzjCkE9ZTgRNgCJvyniihmVAkaKlMk2ABaZN7R7FvlnOaqViSo6LTdKzVZ6M5lrNRkk6CAeQkTA7lZWlcrVFnqEISAFR83g4us2x9SeP8A22iCOCvCR5zgJd1je7UPDYhXCWpLVlFxtOn1gcKjG0xZ7OqBuPFtp29yR1MIQe1iaMg8aQs3jPY3kGPFdFIhYaj3LeOeu3v7EuMvX8f0QYnLW9UWs7IkHsDTNxyGx49yf9I3QKP9zoE/08BxWyjQ1mCAR754pri8DrZHEXHj3rL4nKbKceKKRm9FpGlrmsqXMlmokaXCPVPH5JHjaAJ7NekGWn0IuRE20xxP+5X0Uy2xssHOK0jm17e/sS4y9ff3KzkWBb1YdLHv7Qc9jA2ZMxsOGn3BP8so6MBUaSTDat3G8S7cnuUhoJMCE3weDGjTFiDtbff5rOWW3ZSjwVCroNPU8NuCASNUEi3A2SHFYfsloxDOs1EyaI9W4g9i8yJPuV7qYM03EHbgeY+61PKuOauxOr9SlZJgGF5DqlKrYEAU2gtIjUfVFpKteQYXTiHuk3Y2x2HavHuCkye5MMtwt9UCTE+A2HxU5MuxUY11K+8B1WsCAQKj54jeYPf3JHjKbC5zm1mNYWu0N6oGHloDb6Np7SvOY5eQ7WNjvzB5+CiusmstdidX2Zz6nhPSN116Lu0JaaQuydp07kGPZ7rKMvh9HT2Q2qww2wPakggcOPinIJ7vet+Fw+ogkCxkePNOebbsOMX3Iufu9LS5ljuN923j3JBnFJhs17aZbd/o9UguYb9kzafeNlecwy/W0Ees3bvncJYGQFMclVwDi+xz7MMNJJbiKTWX0zSHAOE+r/MWn/xTvL8vb1I0lsuZDn02hskAgkQOcqxFx8lZMYXGLd/FXLPaqvf2EovuR3N05e0E7NpEkmL62m5Pel2Lawt7UNc6A1xbJad+RVwp4EGnoiBAHhG3ySo4YsJB+Gx71nHJQ3F9ig4rDnqwG4ilrE6yaIAggAN9Thcz9FNyPAsJf26dQtILSKYa5ovvbdW55XgnkFo8/lqvf2EoO+X7+5h0Vw+ipWuTLmm/Ds7DkLq4sSbK8NEmBJuYG9oHjZOmhc8nbstHqEISGCjY9wDCT5lSUmz6v6rfb9B9U0rYEB7pUebrwFaw660pE2NssiYTsCyrmCqQ8d/68z804x1fTScfZ77LMoV4mqC4wodUrzUtbzdaUibJmEjUO9WHDCyq7H7d3nmfkrJg6khZtFEHNag1RyHzSyqUYmvqcXcz+nwWmofPkLRLgkzp+fMqwYACFXaLvPkp1lFS0crKJIaJOZvAb4/qkj3SpWd15eG8h8T+UJaT58hVFcAz1u6a5XCTU3X8/cJjltSHeP0SkgTHz4DZOyr1WpJKaZtXinHMgfU/JIQ5EUDCobqXgY1Je43UmjUuDyj8+J+iJISLPRFknzKqNZA4WTOnVhpJ4An3KtPqSZPH6pRQ2ZVSiiditNQ+fIWVJ1vP3+iqSEizYMWUtLcrqy0JksygQhCABVjO3zVPcAPhP1VnKqObv9M/xA/9WqodRM0nb8vyKiurQeXtA+q2ucI4fD6hQau+/wAQP+IW6RLGuGrS5viPMppm9T0bR3/IH7pBhX9pviOfPvTfN32YP7vhp+6ya8xXYgt8+YKj16keQPnCzDh5/RRcT59X6BaJEslUcRI3+M/Kyf4arFEn+k/JVWi63H4n52Vgo1P8OT/T9YWc1yNC4LCsY4efaAvNXnyFqr+fV+ytIDKhiBO/xH0KdZNUufPnZVqib7n3n6QnmROu72fVLJGgiY5g+ajj3/K30Ud+35fkjFP7bj/U74OIWp5EcPh9QhIDV14B/MD6pjga0vb7fkkrt9/j/wDITDL3+kb49/LvTnFUJDbO6nqDuJ+SWjz5gqXnL+00f0z8T9kv1Du8+IUxXA2a6tWD+g+cLbTryN/jP5KFiPH4j6BZ0n2/U/P7K3FUJPktFer6B3eB8SB9UkBTLEP9AO/R8wlId58grOBTCu6PMfMBY0MQOfxH0K14jz6v2Wig7vPvJ+y11VE9y05K+R7U8CrnR91j4/QKxtXO+pZ6hCEgPCqjmbPS1P7vd2G2VuKqWbYaarzadVp72suI2Nvmrh1Ezn/TTNcZh3jqyG03QGkMDr2nVq4i5gRbwKk9Ecfia7ddYDRFnQGum0iBY8Z+vBtiwK1PR6OozQWwHtcTUAJa/wB7Y3m/u2MpuY2HEU2tFMRLGtAFRweAbWDNF7eANh1vJHTWuSNXZKduzvewf+wP0TrNmz1d+D7e1nn2pRTwh0shwPpWukmZZr7N+J0x5unGbUdQbyLXjuuWb89lzurRZUulNbEU6RfQjs3fbU4N5gbc5VV6M59ja9QNMPFi6WNaA0wZJbtxHeRsrviKjmlzGup65Dg0vAhmkdnSbgEtI2/im3DRgMD1ZIYwU2OeT2dG3pfp1cC/zA6IZIqDTSslp2TWBNMFfBibS0fF0pTltLUA7WHHQGv7QcBVgF3q2Bvt4QE4wNEjCBpuQ0THiCVzyooV49r9LurjXB06tp4THBc1d0kxwrGkTfVp09W2dXLn5B2XScXFJ2oloBLgAXBmp7u0B2jBNnd6XNwhNVtUsYXgFrqjdJlv8JHsIHDjuN98U4xvZWS0yRgNZY01GgPjtAbA+fHxKcdHz6Sr3dWPg4/VKadIuOk1O32Dp1NBLbCqNLeFzeN4unWTUCKtV1od1cewGZ96xm1TGkRa7Lu49p//ADcuedLc7xuHq6WkBhks0sa4Fok7u47A8iRwK6DmOGPbdIBHWXNtPacZB4b/AC5JRj6IxFiynUZLSwamO0lrmhxJvuHHmIbte+uKai7asUlZD6MYqvVp66zRB9RwEFwveNo2vaU+w/8Am0hzcfgx33UQAjT1j9A1AGXMZbqRMQZHpJsD8FPwuEcHUJIJa5xcTxJY7a3NTkkm2xpE/Nm9sf2C3/k5UvpnjMTRp9ZQjSPWIaHOB4b2A74V1zehqdcWLWb3BLXl0fL3pDVfvTmm+HHrGl7TLHH1NLr+q6b8hwKWKSVOrBqypdE84xdd8Ph7BZ50hseBad9oF1caxhjjGzSfcCoWDwbqdMsaBTADyI0b6WxJPHVO/v2U9mHDmVCx4c1zCGnVqAMFrr8pA9oKvJOMpWlSEkx1Vb/h2Cf9P6JFm4qim40QDUi07d8d8bd6sD6Z6hg5aJjugJDXHVQNTBLSGguDZIjtEE3jjCxxuimc6wHSTHPrdXOoyRpNNou2NUwQRx5RpMromHBgagAYEgGRPGDyUFmDcHuqtptD3MIc8aCXVBqEjuJDT7gRxE6hSl5HWAlrpLdQJ0aezLW7doC9jE81vlnGXRUSk0OejBnrP/0I9zWj6K0tVa6O0S01Ji9QkRyIbv3qytXJLqWj1CEKQBV3pDg9TmuuIIMjmOHtCsS1V6QcIKcXTsTVnO8bk4cTNOk8GP8AMa2eO5DfqsaeUXGqnRAE3DGlwneNTTvDfcrhWyocJC0jLO8rb43BOhDwdO4G8Rfw8E0x+G1UiPf4QQfmt2FwIamAZZZOXNllBxeW6gBDXxA9I1pERFpaTP5qCzJoBAo4cA7jTYxMcD/M7hxKvWKywEyLeChnK+8rVZiNBRgMNobpHuAaAO4BoCseEo9mO6Frw+XAGUzo0oCylK2UlRTcZl93g8TJBALZjiCCINuCUfuW89Th5iCdIuIgiwFvYug4zBB249qp/T9xwmAxFZpIcGhrTydUcKbT7C6fYtseRyaj6kuKOcdI+mhw9R1LCNpCoCRUqNYzTq/iDeyC50zJJInmqk/pXjidX7ZiAf6ajmD3NIA9yhYDLKlVtV1MAijTNR8uaCGAgFwBMugkTE7jmmdTodjAQDSaZNIAtq0nNJrVXUWAOa4iesa5p5EXtdeyoYocOr+ZnyMco/ELFMe04h5rsEzMCqARBh38R4w6ZjcLo9DCU8QxtakyhUY+7XuYNRHfDRDgRBHcuQYzoxi6VN1WpRLWNY15dqaQWuqiiC0g9o6yAQLiQTYhX38EMSan7RhiTDQ2qwcpOip7PUPtK5/EQhpvCuBpW6ZbaGVdoFzKTYEAsY3UO4FzTA34qwYJkuCktyzvKn4XBhq8ueTY0UaIedYPXSi8cY3Exf4Ks4/LNZktpv3nrGtPDh2SY9qv7qdoSvEZWDtI8EoZHEHGyksyaBpFLDgf2C3gC0jgPcnWDoaQGjbhYCPY0AAJn+7O8qTh8vAVSy2CjRm2hNMju/RVfGZbIc2xkk6XhpbJ3BBae/grxTpwFDxmADrxfmFEJuI2rKEMnhxcKWHBJmdN54bDuHDgmGW4EUxYNbP8LGta0Xts0E+1PnZX3lbKOWjxWkstolQoyytictWjD0IUhYFghCEACEKBmOaMpW3d/KN/byTSsDj/AONvSDF08bToUK1WmwUGvLadU0pc6o9pJLSCbACFD/BLpLiquMqUa+Jq1WGk5wbUe6pDmvpgEF0xYkQCujYzFOe/WaILoidBJgbCVHo4rS4O6lgcOIbBg7iV3vJH4Hw9efUz72XqmbLNK8uzEPgEFruR+h4qbicWym3U8wPifAcV59GhTfxizWth8uL6D3U3uq02amnS6DJIB4TG4XDsm6W4+ni6OrF4iOsZqa+u+o1zdYBBBJBkSF37NMyNWB1UtBkamzfgfillSrwfQYfFi9DBkjDE4uN2ZvqXig6VvVeyrNps9pb38PbyT0VREkgDnwXA1RoY4urpY938rXH3AlfJeZdIcZXYP2jEVnseZIdWcWOMmPRzpEFvL+FfTeYZ2CC2m0uGxMGPYEhc8gR1LY/ssu3wmRYrbjdmcuTgmTZw7DisG06T+upGk7rA8wxxBdo0PbBJDbmfVHfLpnT6uHhzcPhQAyiwM01tA/Z366BANaQWuk2MGTIKn9LOgtXrHVcJTLmElxpN9Zh3OgfxN7hcbXVHq0XNOlzXNPJzSD7iF6a+Fl5I5Q/x3TTF1cO7DPc00nU6bHNg3NOsawqC8CoXGCQACIEWBCbA46tS1OoVKlMxDnU6hpmN4JaQSLTHcmuRdEcViXDTTdTZxqPaQAP6QbvPhbvC7Jk+XNwtFtGjR7LRdzmy5x3LnHiSVE8uPFwlfyDliH8CekOIrnE08RXqVg0UyzrHF7myagd2nXg9njwXZGKj4TGaHSKTQdiQ2CRylWvAY5rxxB4g2P5rx872m5JUaxZPXM/xxzmvh6GHbh6j6ZqVSHFjyxxAZOnULgSefBdCxuPZSEuPgBcnwCrWZY91Ug9VMTplpMTvdGB6zUmrSCXQ4t+H/SrG/vLDsqYqs5j3hrmVKr6jXBwiO0SJvM9y+k6LpCoprXl1FkggiWXBBkEcirHleaggBwLTz4H28Fp4qanLZKhRHiTdMsY+jgMVVpu0vZQquY7i1wYS0ieRhNX12taXOIAHEqv5nnHWAsYzU02MtkEeHJYQXmRTZ821+lWYAtccZiWkwZ/aKhBsDJbq2vMRxX0z0Rx5rYTD1XmXPo0nOPNxY0k+0qvPqkb0Wx3sTPKMz0w3q9LRtpFmjw5eC6/F5FkrWNER4LWELVQrBwkGQtq4TQEIQgAKoGY4pwfWcG6yKrgGt3ID9PHiL+5X4qi1abuurSDHWPiYvcmRB2WuOubJlfAufnbp/wCmqxx9WRaTIB4eKjnPrx+z1vEAHgDeD4+5ba+U63uqHD9tzS0nrRYOEEi28WS+h0aa1zCMO+WvDgetaeI35tG8d3hHQo42uf3/AEjf3TGuFzU6qDg0tL3tBa/suAm4jiU76QViatNto0OPf6wCXnAjXSOmdNRpBja+/cp2e03dbTIBjSZNo3Ft5n2LFa7L6lO6Epzl4EHDVZv/ACwRMdm8nccOKj1M9Npw9WTuOzII0nnfc/7SpeZYA1Y1UdYZdp6wNky1xBEW9WPftKV4vo6HuLnYd0mbCq2BIItbvK1isb6/v+kuVf4TKOb6mvPVPZpE+kGkG07zwVhqY1xwDXWDiKU8RJe0ECOCUYPLQ2i1hZADNOgkOsBpAJ2dYJrWokYFrQDIbSsImzm8yFk9NlXqVzQprZi6m4jqXvbAOpsaZJcIMm0QOfrKNUzx0GcPUBAttDtpv7eXBMK1Fxbp0B4PrDUG2seIuCkmI6ONcxjP2dwDDaKwkki5Ji+wHtWkVB9ff5E5V/hJoZ3qc1vUVhPEtGltpuQfYrH0Tx7nuqttDHgCDO4vPI9yQZPk4pmpFI0w4h13hwm8hoHqgW96sHRzDBj6sNiXA7RJ0iT3rPJorURxbYmdjnhofoNQl1wzeL3v4fFaKmeuF/2arF5jSSN9xMTIjdTMIx4aezcTDSQDvsSJAS+tkk6/8Pep6x60SO1qMW4kBaeW+Sdmka3Z+QSP2etYx2QHT4X8E0yvMT+0UWgQHhxIdZw7BO3jAKUYDo+GVGOFBwiRqNVrolsEkcbWT/C4ICvSdpuNd42BaRE8vspyLGuhUW2bs7rk1yNwGNIHG+r7JN++3wP8NV1QJBLdyDtEzEb2TjNqbv2iYOnQ29oO+15n2JVjsuNR4e6hqLCNPpAAQNXCP6pjuHK5HWlYroi1c+uP8PVgjk2Qb2InuHvCydm5NJ7xTcwt2FUaJMDv24KDiejDXFxOHeS7f0zbbGRax4e/mneIwGqiQWbt9X1iDG1tyCqmsaqvf5BSbHWdYl3UUtu09sz/AGOJjvskNbNHMLm9RUcLQ4QGm0m5MjiNined03dTT0gyHt5W7LhJk7JVjsKajOrNPW079oNgjbcHjB9gUQ1pA20yDXz0gXw9WeXZ27r79y9wuca3BvU1W29ZzQG+Ez4/DmouK6PNcWk4Y9loaAKoggFxg2vJcZTDJ8q6thb1ZZeYLw8mQJMhXJY9b9/sFJssPQ7GmpTcTFqj2iDIgR8VaAqx0Ww4Y1wDdI6xxiI3jZWdq5pVbotHqEIUjBJ81wIJ1ix49/5pwl2b1tLQOJ+Q8hCASPYtQ8Stzn+fIWlhv5+6vUVk3AYeTO6Z4vAh7IO/A8lFyt/BNcRUDWE8h+igZW3UoWgg8ypD6slR3uur1FZuw9LUdzCeUcMC2CLckpwTxq8fPNWCibKBler4PQSBccOcKM8Kdj8RLzGwt7lCquVqIrPGtm0lOsvw8BJ6Tog+fmrFgjZSxi3McAA7UOO47+aXvanGc14hvtPyH1Sh7/PkKlGxWah4lMcuw/Hil9Mjz+qdZW+R8EmqGZZhgA9s7EbH6HuSh9OFYcdV0sJ9g8Sq+akoirEaI7ypGEo6jxUcm6n5e8ao8/NElQWNDhQ5mkixSWrhtBI3hWRpsq9icRqcT5jgklYyI8LKmySBJXlVy2YdwBB9/mVTVCsdYChATEKPhTZSFAwQhCABVzOq01CP5QB9fqrEVUse+aj/AO4/OFUeomayfPkLBj7+fyXlTw+H5KGa0H9B8z9FrVkj3L6kP8fPm6nZzWhjRzPwA+8JLgKsvb+vBTc6fdg7j8SPssq8xRBBWtxuvQbefsVErVIP5fchapWSxlTqbHl55n6J/wBfppudyB/JVOlXkfmPkE+xNT0B79PzCylGmUhVqWNQ+fIXjStOIMfp+QWqRJJpP8+T9E9yqp2R52VVoV/MgfIlP8kfb2rOaopEbMq+qo7xj3WUZx8+QsHukk8yfiVjV22+H5K0hGVJ9/P3CaZVU7RCrza8H9B83JtlVSX+z7KZxoExhnlf1W+J+g+qUgqVnD/SeDR9T9VCO3n7FOPQGearqXh6naae/wCduZSmrUg/kB8yFIoV5j2cZ+WycougTLRjK8UXHuj32VeDkzzN/oh3uHyKUt8+YKmHQbCofPkLZTfbz9/ooeIdH6fovKGI8yPkCVTjwSW7LaktCYJNkrpaPb8ynIWJYIQhAHhVKxT5e4/1O+DiFdSqTiqjQ5w27TzxgDW65Ow2K0gJmpzweHwH2URzb2HyH0VH6c5BXFTrGF72vJ/mcWug6WwLxJtwgRymydG8ufh6Xpqhk30uNmcYk8ecWt7T1vGow2UiLt9Cw4F8VGTxMfAn6KfnDu2ByaD7y77JZhz6ajG2p3vDSPumecOAfJ/lbwJ3c4AQFzNeYvsL9fd8vsotdvd8AknTXKKlejrouJLAewCSHbgkAbuF7cdkn6D5NWb6V7nMYCYaZ7YvEhx27zuRbmumONabbfQhvmqLqwkDw8+CfYl/oB36Piq/WcCx+kgkNdteLJ/W/wAhniz5Lml1RSFRd5t9QtNeDw+AWnMsMMRScxjy0uEgiQeYkWJafiFznKujuKOJcw6maT2n9qAARpIM3nhFzuYhdGPGpJtuqJk/kdHoyP1+wCf5C/su7nEf+oP1SKjAhpdJAAuRqOwkgd5HvTjo56tSf9R/wAA+ELDJyikQA+wPMA+8LGo4EbfAL3W2ANrN58QIE7TcW71zPpN0dxDMQ3RrqNeZY7tEky0EOM2MA3NtjwMbYsak6boTdHQWtvb6D6JllL/SgHiD8I+6RZJgnUKTWVKmo95sNhpaTePunOVn07eXVuI9pb+SzyLqgiSs1d6R3dp/4g/VQy/u+X2UzNXtFR08S0bEydAPDayofTzJqlRorUnOcABqaCSA2buYB3bx48E8UFJpN0EnRZazb2HwA+i2NfAk7D2/oqp0KyitSZ1lV7mgizDIB5OIO21uN1Z8Q4FhLTN2zF7awD8iqyRp6p2JepYc2d2GDm4/BpSnXHkfUJrmzgGNJ4FxnlDTKq/SDLjiKLmU3lrtwJLQTcaXjePkQDwWWNJ1ZbJmIAPD4BY0Zj8/oIXO+i+Q4l1ZxcX0gw9o3BDpMtF4JiNrDe836PSIJiRPLjxP0PuW+WGnCdkLksXR98sHi4e5xH0T4KudFD6Fp73z463SrGFxS6s0PUIQkB4VTM1ptBc1xOo9ZEWLhJMXtPa4q6FIM6wMu1wD9LQfYQrg0nyJ/IpeJrgk6xXZr06poOcBoc1zY0hw4O5g6vYt1Co1pbDKjzIdLaLgI6sUrueRG03M/NTqmWtnsuc3ubAHyRSy1oPaJf3Phw8dt1v5a6k3L0JeFwTQ6iBMUyY220Ft1NzloHbcYbpAnkQ43t/cF7l9KTKY5jgtbIie48RxCx283JT6FJxdXS6NNaGOLmubT6wEl2p12EmLubBAN+O6iUOr0W6xwhw/6eoCCadMbEDkD4zxBTzE4BpM3aeJbAPtkbrR+7BxfUPcSCPiFsnGupNy9DZSoNex50uYajYIcAHCAWiQNjHM8k8qUfQgD+HT7hZQMHhx6rQAOQEAe5WCnh5YRzCxk+SkUvGVGj1BUcDLXaGh+kAwRBIcNyJAIEJc1zHEias6TTh2HqC1mgk6bkBzeMbnhaxY7Lm3a5oF5mBvzEhQTlg/1KkeI+y2TiS9vQ8wBa90inUbpcXNL2aAZaWwAbmN9hwT3JcOG64ntPc73gfZLMJhGs9UXO5gaj4kC6sWXUYCym/QpfMrOOAaI7Re0NOlsdrS4AQHEA3Ebz8ElxVVpJDuubJ1nVh6h7Wio0wWA8C0bz2bGSCLhm2AAcXFoIPMTYmSD3SkrssHB729zSAPgFpFxaJexDpBhdo0VDq60OcKRa0Cq8PkudAsDHHj4J9gsMOta69mFvxb9lAoYBrTJlx4F8GO8WsnmXUTMqMjXYavuRc2YA6XGNRbBE2OnTw8D71WsVVixFcBoLGnqi9paQWF0051A9k8I0iyu+bYLU0GJjh8iO9VzEZe0mQSw8dMDjubbpwca5B32FVN7IENqvvaKD5/zS7YgAbEcLQeKbNwrX0yIc3WWuLTEtPZkWtNr73laW5Y2e057hycQQe4ghNcFQuAAABwFh4JzaXQFfdEzMKcsaTsCZHcWkKr417dgKzmPAlzGh/EjTvqbtxBsru/DamEKtYvL27Fukg2IAkXkwSNlGNruN32ENGoxxLiahJLHOBw9Vt2FrjYt3OgiL7iOMtMra10O0PaW6wNbdEh7g6dO9ogTHFY/uwf6lT/AHD7Kbg8M1tmgX3sJPeY3Wk9a4ZKvuht0dw4ZTDRsC7fve531T8Jbl1KAmS527ZYIQhIAWFRkrNCAF1XL2ngFg3Lm8gmi8hAEejhgFvLVkhAEKvgw7cBR/3a3kE1XkIAhUsGApjWwskIAj18OHbhQ3Za3kE0XkIAX0sCBwU2lThbEIA11acqDUy5p4BMkIAWMy4DgFLo4cBb4XqAMXNUOvgWncBTkIAVjLW8gpFHCAKXC9QBiGqPXwoduFKQgBWctbyC2UsCBwTCEIAwp04WaEIAEIQgAQhCABCEIAEIQgAQhCABCEIAEIQgAQhCABCEIAEIQgAQhCABCEIAEIQgAQhCABCEIAEIQgD/2Q==" alt="Álcool 1lt 70% cx com 12 unidades">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Álcool 1lt 70% cx com 12 unidades</h3>
                        <p class="product-description">Álcool 70% para desinfecção de superfícies e ambientes, caixa com 12 unidades.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Saco de lixo 20lts -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="200" data-category="garbage">
                    <div class="product-image">
                        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUTExIVFhUXGRYaGBgYFxgbGBgYFRcYGBcYGxoYHSggGB8lHRUXITEhJSkrMS4uGB8zODMsNygtLisBCgoKDQ0NFQ0PFSsZFRktNysrKystNy0tKysrNysrKysrLS0rLTcrLSstKysrLS0rKzcrNystKystKy4rKystK//AABEIAOIA3wMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABgIDBAUHAQj/xABEEAACAQIDBAgDBgMFBwUAAAABAgMAEQQSIQUxQVEGBxMiYXGBkTJCoRQjUrHB0WJy8DNTgpKyCBUWQ8Lh8VRjc4PS/8QAFQEBAQAAAAAAAAAAAAAAAAAAAAH/xAAVEQEBAAAAAAAAAAAAAAAAAAAAEf/aAAwDAQACEQMRAD8A7jSlKBSlKBSlKBSlKBSlKBSlKBSlKDR9Meka4DDGdkMhuFVAQCSQTvPAAE6XOm41y7bPXVMWVcNBFGDlBaUs5DG2YBFy3tm56+Fdg2zsqLFRNDMuZG9weDKeBHOvmfrL6Jy7Nms+Z45GLRTDS/Aq/JwLeB3jfYBjbR6ytqTy3OLePvCwTuKNeS79/G9brZu3No4vERZcfiT8IU8c1tQqR91rniwOg141zzDkFgXzEcf/AD619H9S/RyOPCJjGT72XNkv8kWayheWYKGJ43oOgYDtOyTtbdplXPbdmt3retZFKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUCla7b224MHC02IkCIOe9jwVRvZjyFcb6Rdd05YLhYFiS/xyWeQjmFByr63oO61EusjZ+ExmDkw088MbkZomkdVySqDkbvHxIPgxrgWP6dbSxCs0mNmVCSAqME9+zC3rQ4Ux3Mkgzm53nUnmefr+lBjQ4ELNGk0ixKSMz3EgUXBJtHmubfL719L9HusfZBRYYsTlEaKozRyKLKAosStq+bsXGhCtusxBHAA6g/Q0hUq5VSOBU81PDTd5+FB9h4LGxzKHikV1NiCrAjXdurIr5dwO2pI1EkReKRTZuzYgkbwdNDfy3+dS/YvXHiV7skceItwv2Up1tpvRz4aEkaXoO50qIdEesXB49uzVjDPe3Yy2Vyd5Ci/eIsdBrpUvoFKUoFKUoFKUoFKUoFKUoFKUoFKUoFKVYxuLSJGkkNlUXJ/IADUkmwAGpJAoK55lRS7sFVQSzMQAAN5JOgFc02t1tLJN9m2bEJ5TcCRzkiuASco+KTd4A8zUS6ytuSY7EJh7PlS5aG/dVt4DgfE6rfMNcpuBuJMXx8seEKFQ32xdQqgLHArKLZ7i7PqTbhccRQZvTuHENaXH4oyTkEiJbBYQDYd0Gygnja9qgB7500G797Vm7Rd5ZDncuxPea97njrc3F+PGsvo3GrSliLrHY7tCeHhwoM/ZPRPF7QYRYWLuJYM7HKiX4ljv3Hdc150u6JybPZI2JZSNHtYF/nUfmOYINdh6qWKrK+pQkLmsdSneJHPVzpv18KowsMW0Jcfh5WDxSZGW5+EquUMv4WFgcw3i3A0HCoEBuDut+v56XrHmGRk4jUDyuNPqa3eM2UcPM+HkPeDABhaxBNgSL6CxB9/TExmEKZcw0zAjUEHL8WvoPegCYg/Q+NevZu9uPHS/rbj4ivThHKmQKcmYKWtorMCVBtzCnwryOK5y6qbXBPEWvfXgeBoMrHxMojaYEodYZ0JzKVOoDfMAeB7y+1TLor1q4vBFY8VfF4ews4I7YAcQx/tP8Wum+ofsvHCMNDL3sNIRnFicjWsJFG8EaXG8hfAVXtHZZw9wcrwupeGQEEML8LbjY68xY8dA+nOj23sPjoRPhpRIh0Nt6tYEqw3qwuNDzHOtnXyX0U6RT7PxCzwsQGID6EpIBqUdQdSL6Eajxr6W6IdK4Now9pEbOAO0iJGeMnde29TY2YaG3gQA31KUoFKUoFKUoFKUoFKUoFKUoFc72nts4raTRXthsCjyvyaWMaFuaqToPxITwFTTpBtD7Ph5ZeKqcvix0Ue5Fcs6NbLzYGbOcv2qZxLJxGGgGaU+rdoPWghOJ2oMIr7QYXmxBf7KrWNgfixLA+JIUcTc7qv7F6vJ8bhDMjFsSwWZlZh94shcDvHc/cLC5sQeG+td0x2bJLj8xjbs3WMRJfREsBCgHDuZCRzY8a+hOi2zxCuW25UH+UW4UHAOknQyTZ0aNimRWe4CqcxFgN5AsDqN16xurTYz4jtuyQyMCLDNlA0JzHQ3tpYaaka1vevbbBnkhQfCO0I8R2jop9RED61hbF2VG0xjglbDolmaVjmEZS2d7ra652A13DUnfQde6vNmvHCwcRgdoxyKzEKQAPh46BTqTvB41AehCZMRiFABdWcrfRQplyqtsp1bQgW57rV1DotsTFYct2+IimuiqGVCjEJ8GYZipIBIuLaWHAVAcIww+1mgYayzynT5USBTC3uWH+Kgs9aWyMjwTHKe2kCPZdEsODfFvJ18xaoj0rw3ZYiHCsLBUZzc3B+7c5tf5RwrsvSDACa8TgHuZ4+NpEBuR6H86gXTDZZfb+GjtpJhHt5/Z8SPzAoIJsLGGBjHIheCXNFPH+Ix6sFPBxmV0PM24mpt1odGckOFxmFcyQdhFESAPhjW8bm3BgxvfiBzrXdOcNEXiSOMK7wI5ddD2kQuhbhrGJBfeSEHCpH1WbSXF4afZeI0DqzRjXc2sijkASrr4MwHwUHMdv4qN3jZECqYluB+MFgxv6D6+dZewMG+JQ4cSAIokkjznQOApdAflzLduV04XJrV7ewDYfESQPvRiv7Gsropj+wmGb4WsACL3OYWHkQSPI0GVslm+/wgCkTKVQOBbtIczLb8JY3W4/ENazOgfSJsE0cg+AlsjG9wlwHRgPiA0uOAKsoB37/AKNdHGxODx2TSaLEnsr71kgVSDr+MNY+QPlpsJgkZyWUdg80E4XdlXF54MTH/CY5VVfDsxzoPovZePSeJJUN1YAjW+/xG/z41lV899XXTVtn437FI4bCySFbm/3bMbJIPAki48b87/QlApSlApSlApSlApSlApSlBDutHFhMKgJtmkHrlR3P+moxtLEZlweyYh97KsZxBH/LRz2zr4E6k+AHOsrr0uYMPlPejkMoHMIAjXH/ANlc32PtpxtCOW+Z1kZhcnV2GW/rmIoOl4LZAxWOTEsgEUeInRLb3aPOFb+RRCviWPIazeSfsklc/Irn/ICfysag22ekIwkWDSLXKZRmI3lWWN3PmWkPjvqQY3aIxGzsRMhF2gmW3JsrBb+NiKDhOPftcdCZAGXC4WB3B+YxQIWHrKcvrUu6vsKC4imAPb7NxDtpa6yzmxt/JlrVYbYMmJkxYjGuJxEcCHfljJM0rHkoQRny866DtDYz4XamHmCH7OMFLCz27oKAsA3K4UflQY3VJ0rcGXZWKYtPhcwib+9iTQAeIFiOakcjWN1qYYRYvCY+MjLIBG511BtZt/4GP+UcqgXT7Dy4XHR4uA2cFZEcbrAi1zuK778LEg6VPNv7RXF7KkzRFcimYKT3o2ExjmQHdZCxtzUrQTWaRWjSVbnsyLEa3QnKfS16jHTV0h2tsrFy92JlmhL8AzowjB5X7Q+xrI6ott/aMLFGwAZVIAB3xxkIrHkSedWOtLEw4jC4cSC0bYiRbi2ZCiyIGXxB1oOVdINps0rZ1ytAoijtc/f4aRSSwG9cquTfmKzsDMyGPEwD7yBg6gXN43uyrzJF5EtxAccRUd2ckg2iisAztKIzfQMZj2RJ5Ah71OMBsMQYt8GGaSNfupJCtsrsocHwUN2qgn+9HMXC31wYHtnw20IrGLEqFJA+GRb906Xva414qahUWCMsXcH3i3ItvYrvA8bbh4aVPZMflwWJwMx73aGXDsTfJLG7HKT8veRd/Fzzpsfo9mxDODkjBViSLACRS9hzNiunJheg2HU5twFsQjnvSLBIuo7xVOxlOv8AFFr51Z6y8MmGw8wjF+1lV0tujZpI5Zlv+EtFnHIuw0G/XYyeOLa0MkKjIqZCLaMygliTpbSYXPgazunEvbYKQjUZkbmNHB3271t3LT5hrQcx6SoBOSDmzBHuNAe0UPp4a19Q9AdrnF7Ow07G7tGoc83TuufUqT618rbUU9q2bU34+Fd96g9oh8A0PGGQ6eDgEfUNQdMpSlApSlApSlApSlApSlByTrrndJ8I4N0UMHS18yyEf/j61zBg0Euew35kccr3Vr8dw9bjhU969dp9niEj/FEv0dz/ANX0rlOIvZSeNz4W03fWgnHSvbqTyLHGV7KELHGb3zBL3YnxNtazeifSgLDPg3fKZ8givwkd1X2sb/4a5mKob1oO6dWa/wC75J4Zh2qGRjBiEuxe5VJFMYGZWHZpmFtLW3AE73b215H2XtHUiXDfaEuRr3Rmjax/9tlNQXo90sywx4xmOVikGNtqUlUAQ4sKN5O5gN4IGuUCt51g4nJBi2DALOrPodHBwJizAjeC7IPSg5Z0P2mX2jDFiy0sc98PKHJOZcR3VIJ3WYowbhaui7IjaNdo7PluzJBKyOfmikgKh/UwwkjgzNyrjEEhfs7aSJqjDfp3h7EV3tpxN2eMQraXBzm9xcJJEWkjYbxaYKwP/wAg5WCNdVe0zgtj7Qx2mZSEizfCXygILcRnlF/KsfpxtKNcFgQHZlmabEpcagSZTlNuIZ3HkKgx6QE7NXZ6Xt24lLDc10y5T5NY1ldMdqLKuCjXRYMMiW8SxJProaC0drKmIjmse0jINiLd5d3kRofMCt50y6dmfERzYdzFmiDSlTZhKxTMpsLWQRIF36a8agrHUHyr2NdToDdTQSh5WkhkZnLMzqosR96C+VpAeBIYAnTVOdTbaXSqH+wUEBLI10PdYLYIM1gzWW1yQO781c3faarhYIhqw7xOuhEsjADx7+u7cN9Yb7RZiWZiSWLb+JNz7m3tQSbaOJWedmBygCM68rspNuNj2ZO7duFhUlw0/bYN420YXRhyNv6Nc5XH2dXHC4PiGqQ4PbYVr30YBW8cvwH6ke1BpOkkWXEuP5Pqi3+t66D/ALPeOyYueI7pYwR5xsxH0dqgm35VkdXHEWPmGNvo30qW9SrgbVjAtrDKfoun50H0VSlKBSlKBSlKBSlKBSlKD5+688h2gLuwdY0sLXU7zv3qdfKoUkKNYfCWBOQ6ob/Mh3ofcVLOu+Qf71ZSCfuYbW3g9+/n5flUEDsABe6i1uY8uXlQUOjglWIBH18RVLLWW5zb9fzqhhoNN3HnQZvRraKwu6S/2E69nL/CD8Mg8UJv6msbbGJxMathJJHyxkrk+WxbPp/Cxs41tqKxyovqDbzFX8diRKq5rlkAQE2uUHwg87bh4WHCg1WGfKQRvUhl8wb10vYO2Fk2XNhwe9AJ8njHMjnU79DK4t/CK502EG8HzFZOyMeIWe+5lK28/Kg1cRtXt68QVdyXoLDE0znnV84YcZFFeDDx/jY+S/vQYrN41Ur1lps8NopN+RKAnyuwvXsuzmQgMQPO1/oTQeYWBn3Lcen61vMLhsq5SB41jYaNFXTMfLNqfIVmbOhkmfJGmQcWkJ+ii7E+AFBW+ARge7r4EipJ1MwAbYQX+COf3yqOP81a3F4JYAczNIwvoAVTS2+3eYajlqQOYrY9TUg/3vE3F1xC+NhGjAn6+1B9G0pSgUpSgUpSgUpSgUpSg+fuufDkbUMpGhjVRfccqgn2zfWoLJh8+crw7xGu7S53cLgnzPKugdceLSedXQgiOSeFrb8yCAm/uR/hNRTojiFTEwGS5TN2Uo5pNeM38PvL+lBowCOFerY+tX+kOznwuJlw7k5oXKBjvZAbxt6qQfWsFZrGgqaqSK9m36buFW6C9GapeMcLeRAt/XrVKHWmbgaDHaNQdbqfI2/M1SYQd0g9autcbjpy31aZQfCgobC2+ZattEeYPrV0rXmWgtqlZ0e0nXcE9UX9qsBa8IoNzsvFzzyCPMddAFXUnflAA3+h8jUrhRIZmshZYB2fZg3bE4uXdESN+UWLDvAHwq30NkjiwcmI7NTiBK0cZJOVRkRybE2Frm7bzYCtnh4IMJhnxGKmCylHGFizfekyf2uIIHwySEmxPwrbdwCJba2h3jEzBmdh2hUaWB+BB+Bbtb8V83zGt51TYq+2YnAIVnxNhe+XOklh4bgKh8Km7TnKDdsg4Fz3UC/wqWFv5DyqY9ENlfYdq4LDkgyiRe0a91BeMkoD4bvMmg+kaUpQKUpQKUpQKUpQKx9o4sQxSStujRnPkqkn8qyKhnW5jjFsyULbNKUiA59owDD/AChqDhP2svhnWXWR52xBPIzK2f8A0p7GrJwtsP2oO+XsnA4B0zRP4XKyj/CK9xd2zNxZSfUW9tGq5hcUq4fFRN86xlf545VP5NJbyNBuOsSEzw4THk96SFFkJvcugswFhbQ5t+unGoNkvz9qn3RnGLi8DJgGvnTO8Wu+5LEedyagIUgkHeLj2oL0Av3d993ieXgeVUNER/5H76HwqkGstvvELfMvxi28fj/f3oMMjUVTJo1VS7gbVROdb0HjGqb169U0HhNeUoKD0mvYhc/l51RWVFCfgA7x38lXj/X70HqYqUqYlYiMksR8tyACT/lX2FeqwN1QFhxJHekYmygcQCSPH8qt4iUfAnwjeeZq9s7F9ge1AvItil9ytrZyOJXeBuva+61BN9iYSFWuy5xhRZSSFUtHcMddO9O0xBO4LUan6TyNio50jHbCZZFIJ71pMyL7aX434Vb2rti2HTDxnu5UaVj80hGYoDxUMzEniSeA1ydgYLs80jDNIqPK4O6KJELBDwzyGy5flVuZ0D6tia6g2tcA25X4VXWl6GbWGLwOGxAOrxrm1vZ1GVx6MGHpW6oFKVxTpf00xM8rJFK8MKkhQhys1j8TMNdeQOnjQdmnxKILu6qObED861OL6W4GP4sVF/hbOfZL1wRlZzd2LHmxLH3NDDUHZMV1l4FPhMkn8qEf68tajEdbkI+DDSH+Z1X8s1cwMIqjsKUT7Fdbsx/s8NGP5mZvyy1F+k/THE48IsyxBY2LKEVhclSveu5vox5Vq+wqtMPQYAB/CvsTzvvPia8fD33hNf4E/atgYbVWkQqUYeCwzKQy90jcVAB9wKrl2bG/xpqTfMNG99x9Qa2KmqZWqiN47o8wN4nDj8J7rj37re48q1wV42BIKniCLacdDwqUuKrRQwswDDkdfzpRFMXhtCyi6nX+W2/0rANTR9kJYqpK3BH4gLjxN/rWjn6MYhfhCyfyNr/lax9r1aNOaoNXZoyjZXUqw4MCD7HWqCKCivbV6BXoQkgDedw4mgvYJLnQXPyjx5nwG/2q/ItlKrr+J/xHkPCszD4UIlvmPxft5VZbDs5sNfAcPM7h/WlBrswGg1NZeLwPZBQxUuwuwBuE/hJGl+fL0NXXwqJvIJGpC7h5sd59qwZnZzYDU/ReFBiSvrccN3pxrc4faci4HEI2W0piA/Fo2dj5HIPY1qTHrYWPiN1ZGDwrTSxQ31kdVJ5AkD6C9B3zqCxr/ZJMLILNAysNdSuIXtRpw3/Wuo1wXoHt9cPt+RGFkxKRRDgFYRoY/cqV9a71QRTrIxkkWFDx4lYGDcTYyAA3RW3g8fSuA7RxGISRpH+9ViS+lnF9S38X5Hw3133rA6MjGRBxIEaIMRmNkINibn5d2+uF4jPEx/5kRv8ACQSuurRsDZhxye1qgYbFqyhka6n6eBHA1lxzA1p58FcibDuATxHwSW+VhwPnu+tMJjs7ZCMkg3oePip4jw/Og3mhplrDhlrMBvQe7qqBq0TVBeoq/QVj9p/V6vRoTRF4CqWWq1hPOrohoMXsqqVLVfMXiBWFLtKBTbNnb8Ka0GQB4VdMVhdu75kD6amo/jOkrrcKI4RzY5nPoNfzqP47aysbs0kvPMcq+1rH1ApBMsXtaIgxt98PwhQwHq2i+dxUY2k+EOqjsj4O0g8iAth6Ma0k2PdtNw5C9h5A3A9BVuCZQe8mcfzEfUVRkk1nYKMrrbXieQ5VkptWBrkwgBRobWbla43+tU4bFKy5h3R4628qovNYC8jWHBRe5/U/Tyr0zMwsB2UY4nQ+wrF+1quoGvM/Eb+fwisTFylj943ki6/X9aBLKCcoNl48z51b7VddCQeANs3Aa8hpoOXGrRcHQLbw3n151X9nfl7/ANaUHid0W41JOrzC58WZTbLChOv4muq/r7VGhhieZPIC/wD2HvUi2JtWTBwOsKL20jXMjm4jCiyhV3E7zc8+NB502R1xwkRshbKyHUENGqkHUaa2r6e6NbWGLwsGJUWEsatbkSO8PQ3HpXyFtLaMk7KGIdwfi1uxPMnfX0D/ALP+0A2z2gaRS8crnJmBYI9muRfcWLUG/wCsnaMC4V4ZJhG7gMoysxIRgdQoJANrXrhELB7yYeTS/fjbcT/EN6H+IV3LrA6NnEqHQDOo08RyvXFNq7GKuWGaKVfmGh8mHzCoMMA5iYxlfe8THuuOdx9HGvMUnhjnXUG6+jxnh6ab9xr1pwbLOuRge7Ivwk8wf+WfPSvJkKkZjlbcsoGhv8rjdY+x8DRWOuMeEhZtVOiyj6Bx+v51t45beu7kQawxJmvG6gHivysOa3/07x476wWgeDWLvxbzGd688p/r1ojePJXgNa6PaKlDIDdRv/EDyI51pptvSX0JUfhW1wPFiDr5Cgl8UV+NXzIifE6jzYD86gT7YkfS8h/xn/pAFWAxGuVB4m7H6k0ipxN0mw6aBi55KCfqdKxcR0la2irGp+Zzmb0Rf1NRMYtwLZ2t/DZR7irQQnULfxsW+p0ojb4jbefg8p/jOVfRE/esDEY6Ru6SEX8K2Uey6n1NWjA53kDwLfoK9+zqN7X8gF/PX6UFjsx4n6D9TXhKjgPqTWR935nxzH9qGdRuUX8FX9b0GKNeF/pTsid27nV53LG5t4bifYVWiX3gnz/YX/SgphTN3VF7a67vP/tWQYJNxUm3lb6Uw+JZGtH8R0AUXJvpa2tfRPQLoSjYGBsbAv2gqS3A2JJTMBubLa/jQfOowcpNzp+lVps62+5/rwr6pPQjBf3C15/wNgv7lao+XR3dBp6VQZ14m/mf03V9Tf8ABGC/uFoOg+B/9OnsKD5a+2rzFGJk0yu1+AVj+Qr6qXodghugQegrIh6O4Zd0S+1B8ybJ6G4qf+xw0l+FxkHqZLV1vo91Qdg6YlcdNFOAf7MIQuYEFQWXvCxO8eNdRhwyr8KgVdoKWW9RXpX0SjxKkgWcbj+h51LK8NB857c2K8DFJF/ZhUeeN4R3Bnj4xk6qP4D+hr6U2/sCPEoVZfI8R5VxrpN0Zkwr6gleDfvUEMjKSL93dkG9NzxnmvLy3ciNxuRTkak3H493o44Hx9wOPuN2dc51JSQbmHHwI41rTjTmyyfdy7swHcfkGHLx9rUFza0cRu2qsdO783gRuP8A2rTohHdCajefi18/hFVYzF5iPlZDuGq6cvDw10qy2JY213fTy5elBe7Mnebeo/r2Br3uDxPt9WufYCsUAndc+Q/U172fl73PstBkfa8puqqDzClj7yXsfEWqzJiXbffzJ/bSgi8/ov53NVCHwHqCf9RAqiz2njfy/YfvQoeVvM2rJUC28+Q3fS1FAvouv9ctaDGER5+w/oVdTDDjr/X9ca3OzujuLnI7OBjfiRYe7a/SplsfqgxcusrqgPAC59zp9Kg5wBwFh/X9bwarhgL6KrMeQ1+g0+ld82N1NYWOxlLSHxOnsKm2y+ieFgA7OJR6CqOH9EOgUzyI7JIACCCGKEe1fQGzo3CgPvtWUkYGgAFV0ClKUClKUClKUClKUClKUHlYG1NmJMpVlBvzrYUoOKdLOhzQksgunLlUB2hs9XGVxfkeIr6ixOGVxYiud9LOgma7xDXkKD56xezVjJBkB5Ab/Xl5a1SsYXkPMC/1ufoKkOI6CY1JCBCzb7MNN58tDrWy2b1V42Ui6Kn81yfraoIYxB3kk+p/PT6Uz8hbzP6D9q7HsvqUOnbSk+A0H0FTLZHVbg4bfdgnxoPnXCbNnlNo43N/wrYfWpRsjqxx0xuUCA87k+1fRuC2JBELLGB6VsFQDcKo4zsfqUXQzyM3hew+lTnZHV3goLZYVvztr71L6UGLh9nxp8KAelZIFe0oFKUoFKUoFKUoFKUoFKUoFKUoFKUoFKUoFeGlKDHKC+4e1XYxSlBcpSlApSlApSlApSlApSlApSlApSlApSlApSlApSlB/9k=" alt="Saco de lixo 20lts com 100un">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Saco de lixo 20lts com 100un</h3>
                        <p class="product-description">Sacos de lixo resistentes para uso doméstico e comercial, pacote com 100 unidades.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Saco de lixo 60lts -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="300" data-category="garbage">
                    <div class="product-image">
                        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUTExIVFhUXGRYaGBgYFxgbGBgYFRcYGBcYGxoYHSggGB8lHRUXITEhJSkrMS4uGB8zODMsNygtLisBCgoKDQ0NFQ0PFSsZFRktNysrKystNy0tKysrNysrKysrLS0rLTcrLSstKysrLS0rKzcrNystKystKy4rKystK//AABEIAOIA3wMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABgIDBAUHAQj/xABEEAACAQIDBAgDBgMFBwUAAAABAgMAEQQSIQUxQVEGBxMiYXGBkTJCoRQjUrHB0WJy8DNTgpKyCBUWQ8Lh8VRjc4PS/8QAFQEBAQAAAAAAAAAAAAAAAAAAAAH/xAAVEQEBAAAAAAAAAAAAAAAAAAAAEf/aAAwDAQACEQMRAD8A7jSlKBSlKBSlKBSlKBSlKBSlKBSlKDR9Meka4DDGdkMhuFVAQCSQTvPAAE6XOm41y7bPXVMWVcNBFGDlBaUs5DG2YBFy3tm56+Fdg2zsqLFRNDMuZG9weDKeBHOvmfrL6Jy7Nms+Z45GLRTDS/Aq/JwLeB3jfYBjbR6ytqTy3OLePvCwTuKNeS79/G9brZu3No4vERZcfiT8IU8c1tQqR91rniwOg141zzDkFgXzEcf/AD619H9S/RyOPCJjGT72XNkv8kWayheWYKGJ43oOgYDtOyTtbdplXPbdmt3retZFKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUCla7b224MHC02IkCIOe9jwVRvZjyFcb6Rdd05YLhYFiS/xyWeQjmFByr63oO61EusjZ+ExmDkw088MbkZomkdVySqDkbvHxIPgxrgWP6dbSxCs0mNmVCSAqME9+zC3rQ4Ux3Mkgzm53nUnmefr+lBjQ4ELNGk0ixKSMz3EgUXBJtHmubfL719L9HusfZBRYYsTlEaKozRyKLKAosStq+bsXGhCtusxBHAA6g/Q0hUq5VSOBU81PDTd5+FB9h4LGxzKHikV1NiCrAjXdurIr5dwO2pI1EkReKRTZuzYgkbwdNDfy3+dS/YvXHiV7skceItwv2Up1tpvRz4aEkaXoO50qIdEesXB49uzVjDPe3Yy2Vyd5Ci/eIsdBrpUvoFKUoFKUoFKUoFKUoFKUoFKUoFKUoFKVYxuLSJGkkNlUXJ/IADUkmwAGpJAoK55lRS7sFVQSzMQAAN5JOgFc02t1tLJN9m2bEJ5TcCRzkiuASco+KTd4A8zUS6ytuSY7EJh7PlS5aG/dVt4DgfE6rfMNcpuBuJMXx8seEKFQ32xdQqgLHArKLZ7i7PqTbhccRQZvTuHENaXH4oyTkEiJbBYQDYd0Gygnja9qgB7500G797Vm7Rd5ZDncuxPea97njrc3F+PGsvo3GrSliLrHY7tCeHhwoM/ZPRPF7QYRYWLuJYM7HKiX4ljv3Hdc150u6JybPZI2JZSNHtYF/nUfmOYINdh6qWKrK+pQkLmsdSneJHPVzpv18KowsMW0Jcfh5WDxSZGW5+EquUMv4WFgcw3i3A0HCoEBuDut+v56XrHmGRk4jUDyuNPqa3eM2UcPM+HkPeDABhaxBNgSL6CxB9/TExmEKZcw0zAjUEHL8WvoPegCYg/Q+NevZu9uPHS/rbj4ivThHKmQKcmYKWtorMCVBtzCnwryOK5y6qbXBPEWvfXgeBoMrHxMojaYEodYZ0JzKVOoDfMAeB7y+1TLor1q4vBFY8VfF4ews4I7YAcQx/tP8Wum+ofsvHCMNDL3sNIRnFicjWsJFG8EaXG8hfAVXtHZZw9wcrwupeGQEEML8LbjY68xY8dA+nOj23sPjoRPhpRIh0Nt6tYEqw3qwuNDzHOtnXyX0U6RT7PxCzwsQGID6EpIBqUdQdSL6Eajxr6W6IdK4Now9pEbOAO0iJGeMnde29TY2YaG3gQA31KUoFKUoFKUoFKUoFKUoFKUoFc72nts4raTRXthsCjyvyaWMaFuaqToPxITwFTTpBtD7Ph5ZeKqcvix0Ue5Fcs6NbLzYGbOcv2qZxLJxGGgGaU+rdoPWghOJ2oMIr7QYXmxBf7KrWNgfixLA+JIUcTc7qv7F6vJ8bhDMjFsSwWZlZh94shcDvHc/cLC5sQeG+td0x2bJLj8xjbs3WMRJfREsBCgHDuZCRzY8a+hOi2zxCuW25UH+UW4UHAOknQyTZ0aNimRWe4CqcxFgN5AsDqN16xurTYz4jtuyQyMCLDNlA0JzHQ3tpYaaka1vevbbBnkhQfCO0I8R2jop9RED61hbF2VG0xjglbDolmaVjmEZS2d7ra652A13DUnfQde6vNmvHCwcRgdoxyKzEKQAPh46BTqTvB41AehCZMRiFABdWcrfRQplyqtsp1bQgW57rV1DotsTFYct2+IimuiqGVCjEJ8GYZipIBIuLaWHAVAcIww+1mgYayzynT5USBTC3uWH+Kgs9aWyMjwTHKe2kCPZdEsODfFvJ18xaoj0rw3ZYiHCsLBUZzc3B+7c5tf5RwrsvSDACa8TgHuZ4+NpEBuR6H86gXTDZZfb+GjtpJhHt5/Z8SPzAoIJsLGGBjHIheCXNFPH+Ix6sFPBxmV0PM24mpt1odGckOFxmFcyQdhFESAPhjW8bm3BgxvfiBzrXdOcNEXiSOMK7wI5ddD2kQuhbhrGJBfeSEHCpH1WbSXF4afZeI0DqzRjXc2sijkASrr4MwHwUHMdv4qN3jZECqYluB+MFgxv6D6+dZewMG+JQ4cSAIokkjznQOApdAflzLduV04XJrV7ewDYfESQPvRiv7Gsropj+wmGb4WsACL3OYWHkQSPI0GVslm+/wgCkTKVQOBbtIczLb8JY3W4/ENazOgfSJsE0cg+AlsjG9wlwHRgPiA0uOAKsoB37/AKNdHGxODx2TSaLEnsr71kgVSDr+MNY+QPlpsJgkZyWUdg80E4XdlXF54MTH/CY5VVfDsxzoPovZePSeJJUN1YAjW+/xG/z41lV899XXTVtn437FI4bCySFbm/3bMbJIPAki48b87/QlApSlApSlApSlApSlApSlBDutHFhMKgJtmkHrlR3P+moxtLEZlweyYh97KsZxBH/LRz2zr4E6k+AHOsrr0uYMPlPejkMoHMIAjXH/ANlc32PtpxtCOW+Z1kZhcnV2GW/rmIoOl4LZAxWOTEsgEUeInRLb3aPOFb+RRCviWPIazeSfsklc/Irn/ICfysag22ekIwkWDSLXKZRmI3lWWN3PmWkPjvqQY3aIxGzsRMhF2gmW3JsrBb+NiKDhOPftcdCZAGXC4WB3B+YxQIWHrKcvrUu6vsKC4imAPb7NxDtpa6yzmxt/JlrVYbYMmJkxYjGuJxEcCHfljJM0rHkoQRny866DtDYz4XamHmCH7OMFLCz27oKAsA3K4UflQY3VJ0rcGXZWKYtPhcwib+9iTQAeIFiOakcjWN1qYYRYvCY+MjLIBG511BtZt/4GP+UcqgXT7Dy4XHR4uA2cFZEcbrAi1zuK778LEg6VPNv7RXF7KkzRFcimYKT3o2ExjmQHdZCxtzUrQTWaRWjSVbnsyLEa3QnKfS16jHTV0h2tsrFy92JlmhL8AzowjB5X7Q+xrI6ott/aMLFGwAZVIAB3xxkIrHkSedWOtLEw4jC4cSC0bYiRbi2ZCiyIGXxB1oOVdINps0rZ1ytAoijtc/f4aRSSwG9cquTfmKzsDMyGPEwD7yBg6gXN43uyrzJF5EtxAccRUd2ckg2iisAztKIzfQMZj2RJ5Ah71OMBsMQYt8GGaSNfupJCtsrsocHwUN2qgn+9HMXC31wYHtnw20IrGLEqFJA+GRb906Xva414qahUWCMsXcH3i3ItvYrvA8bbh4aVPZMflwWJwMx73aGXDsTfJLG7HKT8veRd/Fzzpsfo9mxDODkjBViSLACRS9hzNiunJheg2HU5twFsQjnvSLBIuo7xVOxlOv8AFFr51Z6y8MmGw8wjF+1lV0tujZpI5Zlv+EtFnHIuw0G/XYyeOLa0MkKjIqZCLaMygliTpbSYXPgazunEvbYKQjUZkbmNHB3271t3LT5hrQcx6SoBOSDmzBHuNAe0UPp4a19Q9AdrnF7Ow07G7tGoc83TuufUqT618rbUU9q2bU34+Fd96g9oh8A0PGGQ6eDgEfUNQdMpSlApSlApSlApSlApSlByTrrndJ8I4N0UMHS18yyEf/j61zBg0Euew35kccr3Vr8dw9bjhU969dp9niEj/FEv0dz/ANX0rlOIvZSeNz4W03fWgnHSvbqTyLHGV7KELHGb3zBL3YnxNtazeifSgLDPg3fKZ8givwkd1X2sb/4a5mKob1oO6dWa/wC75J4Zh2qGRjBiEuxe5VJFMYGZWHZpmFtLW3AE73b215H2XtHUiXDfaEuRr3Rmjax/9tlNQXo90sywx4xmOVikGNtqUlUAQ4sKN5O5gN4IGuUCt51g4nJBi2DALOrPodHBwJizAjeC7IPSg5Z0P2mX2jDFiy0sc98PKHJOZcR3VIJ3WYowbhaui7IjaNdo7PluzJBKyOfmikgKh/UwwkjgzNyrjEEhfs7aSJqjDfp3h7EV3tpxN2eMQraXBzm9xcJJEWkjYbxaYKwP/wAg5WCNdVe0zgtj7Qx2mZSEizfCXygILcRnlF/KsfpxtKNcFgQHZlmabEpcagSZTlNuIZ3HkKgx6QE7NXZ6Xt24lLDc10y5T5NY1ldMdqLKuCjXRYMMiW8SxJProaC0drKmIjmse0jINiLd5d3kRofMCt50y6dmfERzYdzFmiDSlTZhKxTMpsLWQRIF36a8agrHUHyr2NdToDdTQSh5WkhkZnLMzqosR96C+VpAeBIYAnTVOdTbaXSqH+wUEBLI10PdYLYIM1gzWW1yQO781c3faarhYIhqw7xOuhEsjADx7+u7cN9Yb7RZiWZiSWLb+JNz7m3tQSbaOJWedmBygCM68rspNuNj2ZO7duFhUlw0/bYN420YXRhyNv6Nc5XH2dXHC4PiGqQ4PbYVr30YBW8cvwH6ke1BpOkkWXEuP5Pqi3+t66D/ALPeOyYueI7pYwR5xsxH0dqgm35VkdXHEWPmGNvo30qW9SrgbVjAtrDKfoun50H0VSlKBSlKBSlKBSlKBSlKD5+688h2gLuwdY0sLXU7zv3qdfKoUkKNYfCWBOQ6ob/Mh3ofcVLOu+Qf71ZSCfuYbW3g9+/n5flUEDsABe6i1uY8uXlQUOjglWIBH18RVLLWW5zb9fzqhhoNN3HnQZvRraKwu6S/2E69nL/CD8Mg8UJv6msbbGJxMathJJHyxkrk+WxbPp/Cxs41tqKxyovqDbzFX8diRKq5rlkAQE2uUHwg87bh4WHCg1WGfKQRvUhl8wb10vYO2Fk2XNhwe9AJ8njHMjnU79DK4t/CK502EG8HzFZOyMeIWe+5lK28/Kg1cRtXt68QVdyXoLDE0znnV84YcZFFeDDx/jY+S/vQYrN41Ur1lps8NopN+RKAnyuwvXsuzmQgMQPO1/oTQeYWBn3Lcen61vMLhsq5SB41jYaNFXTMfLNqfIVmbOhkmfJGmQcWkJ+ii7E+AFBW+ARge7r4EipJ1MwAbYQX+COf3yqOP81a3F4JYAczNIwvoAVTS2+3eYajlqQOYrY9TUg/3vE3F1xC+NhGjAn6+1B9G0pSgUpSgUpSgUpSgUpSg+fuufDkbUMpGhjVRfccqgn2zfWoLJh8+crw7xGu7S53cLgnzPKugdceLSedXQgiOSeFrb8yCAm/uR/hNRTojiFTEwGS5TN2Uo5pNeM38PvL+lBowCOFerY+tX+kOznwuJlw7k5oXKBjvZAbxt6qQfWsFZrGgqaqSK9m36buFW6C9GapeMcLeRAt/XrVKHWmbgaDHaNQdbqfI2/M1SYQd0g9autcbjpy31aZQfCgobC2+ZattEeYPrV0rXmWgtqlZ0e0nXcE9UX9qsBa8IoNzsvFzzyCPMddAFXUnflAA3+h8jUrhRIZmshZYB2fZg3bE4uXdESN+UWLDvAHwq30NkjiwcmI7NTiBK0cZJOVRkRybE2Frm7bzYCtnh4IMJhnxGKmCylHGFizfekyf2uIIHwySEmxPwrbdwCJba2h3jEzBmdh2hUaWB+BB+Bbtb8V83zGt51TYq+2YnAIVnxNhe+XOklh4bgKh8Km7TnKDdsg4Fz3UC/wqWFv5DyqY9ENlfYdq4LDkgyiRe0a91BeMkoD4bvMmg+kaUpQKUpQKUpQKUpQKx9o4sQxSStujRnPkqkn8qyKhnW5jjFsyULbNKUiA59owDD/AChqDhP2svhnWXWR52xBPIzK2f8A0p7GrJwtsP2oO+XsnA4B0zRP4XKyj/CK9xd2zNxZSfUW9tGq5hcUq4fFRN86xlf545VP5NJbyNBuOsSEzw4THk96SFFkJvcugswFhbQ5t+unGoNkvz9qn3RnGLi8DJgGvnTO8Wu+5LEedyagIUgkHeLj2oL0Av3d993ieXgeVUNER/5H76HwqkGstvvELfMvxi28fj/f3oMMjUVTJo1VS7gbVROdb0HjGqb169U0HhNeUoKD0mvYhc/l51RWVFCfgA7x38lXj/X70HqYqUqYlYiMksR8tyACT/lX2FeqwN1QFhxJHekYmygcQCSPH8qt4iUfAnwjeeZq9s7F9ge1AvItil9ytrZyOJXeBuva+61BN9iYSFWuy5xhRZSSFUtHcMddO9O0xBO4LUan6TyNio50jHbCZZFIJ71pMyL7aX434Vb2rti2HTDxnu5UaVj80hGYoDxUMzEniSeA1ydgYLs80jDNIqPK4O6KJELBDwzyGy5flVuZ0D6tia6g2tcA25X4VXWl6GbWGLwOGxAOrxrm1vZ1GVx6MGHpW6oFKVxTpf00xM8rJFK8MKkhQhys1j8TMNdeQOnjQdmnxKILu6qObED861OL6W4GP4sVF/hbOfZL1wRlZzd2LHmxLH3NDDUHZMV1l4FPhMkn8qEf68tajEdbkI+DDSH+Z1X8s1cwMIqjsKUT7Fdbsx/s8NGP5mZvyy1F+k/THE48IsyxBY2LKEVhclSveu5vox5Vq+wqtMPQYAB/CvsTzvvPia8fD33hNf4E/atgYbVWkQqUYeCwzKQy90jcVAB9wKrl2bG/xpqTfMNG99x9Qa2KmqZWqiN47o8wN4nDj8J7rj37re48q1wV42BIKniCLacdDwqUuKrRQwswDDkdfzpRFMXhtCyi6nX+W2/0rANTR9kJYqpK3BH4gLjxN/rWjn6MYhfhCyfyNr/lax9r1aNOaoNXZoyjZXUqw4MCD7HWqCKCivbV6BXoQkgDedw4mgvYJLnQXPyjx5nwG/2q/ItlKrr+J/xHkPCszD4UIlvmPxft5VZbDs5sNfAcPM7h/WlBrswGg1NZeLwPZBQxUuwuwBuE/hJGl+fL0NXXwqJvIJGpC7h5sd59qwZnZzYDU/ReFBiSvrccN3pxrc4faci4HEI2W0piA/Fo2dj5HIPY1qTHrYWPiN1ZGDwrTSxQ31kdVJ5AkD6C9B3zqCxr/ZJMLILNAysNdSuIXtRpw3/Wuo1wXoHt9cPt+RGFkxKRRDgFYRoY/cqV9a71QRTrIxkkWFDx4lYGDcTYyAA3RW3g8fSuA7RxGISRpH+9ViS+lnF9S38X5Hw3133rA6MjGRBxIEaIMRmNkINibn5d2+uF4jPEx/5kRv8ACQSuurRsDZhxye1qgYbFqyhka6n6eBHA1lxzA1p58FcibDuATxHwSW+VhwPnu+tMJjs7ZCMkg3oePip4jw/Og3mhplrDhlrMBvQe7qqBq0TVBeoq/QVj9p/V6vRoTRF4CqWWq1hPOrohoMXsqqVLVfMXiBWFLtKBTbNnb8Ka0GQB4VdMVhdu75kD6amo/jOkrrcKI4RzY5nPoNfzqP47aysbs0kvPMcq+1rH1ApBMsXtaIgxt98PwhQwHq2i+dxUY2k+EOqjsj4O0g8iAth6Ma0k2PdtNw5C9h5A3A9BVuCZQe8mcfzEfUVRkk1nYKMrrbXieQ5VkptWBrkwgBRobWbla43+tU4bFKy5h3R4628qovNYC8jWHBRe5/U/Tyr0zMwsB2UY4nQ+wrF+1quoGvM/Eb+fwisTFylj943ki6/X9aBLKCcoNl48z51b7VddCQeANs3Aa8hpoOXGrRcHQLbw3n151X9nfl7/ANaUHid0W41JOrzC58WZTbLChOv4muq/r7VGhhieZPIC/wD2HvUi2JtWTBwOsKL20jXMjm4jCiyhV3E7zc8+NB502R1xwkRshbKyHUENGqkHUaa2r6e6NbWGLwsGJUWEsatbkSO8PQ3HpXyFtLaMk7KGIdwfi1uxPMnfX0D/ALP+0A2z2gaRS8crnJmBYI9muRfcWLUG/wCsnaMC4V4ZJhG7gMoysxIRgdQoJANrXrhELB7yYeTS/fjbcT/EN6H+IV3LrA6NnEqHQDOo08RyvXFNq7GKuWGaKVfmGh8mHzCoMMA5iYxlfe8THuuOdx9HGvMUnhjnXUG6+jxnh6ab9xr1pwbLOuRge7Ivwk8wf+WfPSvJkKkZjlbcsoGhv8rjdY+x8DRWOuMeEhZtVOiyj6Bx+v51t45beu7kQawxJmvG6gHivysOa3/07x476wWgeDWLvxbzGd688p/r1ojePJXgNa6PaKlDIDdRv/EDyI51pptvSX0JUfhW1wPFiDr5Cgl8UV+NXzIifE6jzYD86gT7YkfS8h/xn/pAFWAxGuVB4m7H6k0ipxN0mw6aBi55KCfqdKxcR0la2irGp+Zzmb0Rf1NRMYtwLZ2t/DZR7irQQnULfxsW+p0ojb4jbefg8p/jOVfRE/esDEY6Ru6SEX8K2Uey6n1NWjA53kDwLfoK9+zqN7X8gF/PX6UFjsx4n6D9TXhKjgPqTWR935nxzH9qGdRuUX8FX9b0GKNeF/pTsid27nV53LG5t4bifYVWiX3gnz/YX/SgphTN3VF7a67vP/tWQYJNxUm3lb6Uw+JZGtH8R0AUXJvpa2tfRPQLoSjYGBsbAv2gqS3A2JJTMBubLa/jQfOowcpNzp+lVps62+5/rwr6pPQjBf3C15/wNgv7lao+XR3dBp6VQZ14m/mf03V9Tf8ABGC/uFoOg+B/9OnsKD5a+2rzFGJk0yu1+AVj+Qr6qXodghugQegrIh6O4Zd0S+1B8ybJ6G4qf+xw0l+FxkHqZLV1vo91Qdg6YlcdNFOAf7MIQuYEFQWXvCxO8eNdRhwyr8KgVdoKWW9RXpX0SjxKkgWcbj+h51LK8NB857c2K8DFJF/ZhUeeN4R3Bnj4xk6qP4D+hr6U2/sCPEoVZfI8R5VxrpN0Zkwr6gleDfvUEMjKSL93dkG9NzxnmvLy3ciNxuRTkak3H493o44Hx9wOPuN2dc51JSQbmHHwI41rTjTmyyfdy7swHcfkGHLx9rUFza0cRu2qsdO783gRuP8A2rTohHdCajefi18/hFVYzF5iPlZDuGq6cvDw10qy2JY213fTy5elBe7Mnebeo/r2Br3uDxPt9WufYCsUAndc+Q/U172fl73PstBkfa8puqqDzClj7yXsfEWqzJiXbffzJ/bSgi8/ov53NVCHwHqCf9RAqiz2njfy/YfvQoeVvM2rJUC28+Q3fS1FAvouv9ctaDGER5+w/oVdTDDjr/X9ca3OzujuLnI7OBjfiRYe7a/SplsfqgxcusrqgPAC59zp9Kg5wBwFh/X9bwarhgL6KrMeQ1+g0+ld82N1NYWOxlLSHxOnsKm2y+ieFgA7OJR6CqOH9EOgUzyI7JIACCCGKEe1fQGzo3CgPvtWUkYGgAFV0ClKUClKUClKUClKUClKUHlYG1NmJMpVlBvzrYUoOKdLOhzQksgunLlUB2hs9XGVxfkeIr6ixOGVxYiud9LOgma7xDXkKD56xezVjJBkB5Ab/Xl5a1SsYXkPMC/1ufoKkOI6CY1JCBCzb7MNN58tDrWy2b1V42Ui6Kn81yfraoIYxB3kk+p/PT6Uz8hbzP6D9q7HsvqUOnbSk+A0H0FTLZHVbg4bfdgnxoPnXCbNnlNo43N/wrYfWpRsjqxx0xuUCA87k+1fRuC2JBELLGB6VsFQDcKo4zsfqUXQzyM3hew+lTnZHV3goLZYVvztr71L6UGLh9nxp8KAelZIFe0oFKUoFKUoFKUoFKUoFKUoFKUoFKUoFKUoFeGlKDHKC+4e1XYxSlBcpSlApSlApSlApSlApSlApSlApSlApSlApSlApSlB/9k=" alt="Saco de lixo 60lts com 100un">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Saco de lixo 60lts com 100un</h3>
                        <p class="product-description">Sacos de lixo resistentes para uso comercial, pacote com 100 unidades.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>

                <!-- Saco de lixo 200lts -->
                <div class="product-card" data-aos="fade-up" data-aos-delay="100" data-category="garbage">
                    <div class="product-image">
                        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUTExIVFhUXGRYaGBgYFxgbGBgYFRcYGBcYGxoYHSggGB8lHRUXITEhJSkrMS4uGB8zODMsNygtLisBCgoKDQ0NFQ0PFSsZFRktNysrKystNy0tKysrNysrKysrLS0rLTcrLSstKysrLS0rKzcrNystKystKy4rKystK//AABEIAOIA3wMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABgIDBAUHAQj/xABEEAACAQIDBAgDBgMFBwUAAAABAgMAEQQSIQUxQVEGBxMiYXGBkTJCoRQjUrHB0WJy8DNTgpKyCBUWQ8Lh8VRjc4PS/8QAFQEBAQAAAAAAAAAAAAAAAAAAAAH/xAAVEQEBAAAAAAAAAAAAAAAAAAAAEf/aAAwDAQACEQMRAD8A7jSlKBSlKBSlKBSlKBSlKBSlKBSlKDR9Meka4DDGdkMhuFVAQCSQTvPAAE6XOm41y7bPXVMWVcNBFGDlBaUs5DG2YBFy3tm56+Fdg2zsqLFRNDMuZG9weDKeBHOvmfrL6Jy7Nms+Z45GLRTDS/Aq/JwLeB3jfYBjbR6ytqTy3OLePvCwTuKNeS79/G9brZu3No4vERZcfiT8IU8c1tQqR91rniwOg141zzDkFgXzEcf/AD619H9S/RyOPCJjGT72XNkv8kWayheWYKGJ43oOgYDtOyTtbdplXPbdmt3retZFKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUCla7b224MHC02IkCIOe9jwVRvZjyFcb6Rdd05YLhYFiS/xyWeQjmFByr63oO61EusjZ+ExmDkw088MbkZomkdVySqDkbvHxIPgxrgWP6dbSxCs0mNmVCSAqME9+zC3rQ4Ux3Mkgzm53nUnmefr+lBjQ4ELNGk0ixKSMz3EgUXBJtHmubfL719L9HusfZBRYYsTlEaKozRyKLKAosStq+bsXGhCtusxBHAA6g/Q0hUq5VSOBU81PDTd5+FB9h4LGxzKHikV1NiCrAjXdurIr5dwO2pI1EkReKRTZuzYgkbwdNDfy3+dS/YvXHiV7skceItwv2Up1tpvRz4aEkaXoO50qIdEesXB49uzVjDPe3Yy2Vyd5Ci/eIsdBrpUvoFKUoFKUoFKUoFKUoFKUoFKUoFKUoFKVYxuLSJGkkNlUXJ/IADUkmwAGpJAoK55lRS7sFVQSzMQAAN5JOgFc02t1tLJN9m2bEJ5TcCRzkiuASco+KTd4A8zUS6ytuSY7EJh7PlS5aG/dVt4DgfE6rfMNcpuBuJMXx8seEKFQ32xdQqgLHArKLZ7i7PqTbhccRQZvTuHENaXH4oyTkEiJbBYQDYd0Gygnja9qgB7500G797Vm7Rd5ZDncuxPea97njrc3F+PGsvo3GrSliLrHY7tCeHhwoM/ZPRPF7QYRYWLuJYM7HKiX4ljv3Hdc150u6JybPZI2JZSNHtYF/nUfmOYINdh6qWKrK+pQkLmsdSneJHPVzpv18KowsMW0Jcfh5WDxSZGW5+EquUMv4WFgcw3i3A0HCoEBuDut+v56XrHmGRk4jUDyuNPqa3eM2UcPM+HkPeDABhaxBNgSL6CxB9/TExmEKZcw0zAjUEHL8WvoPegCYg/Q+NevZu9uPHS/rbj4ivThHKmQKcmYKWtorMCVBtzCnwryOK5y6qbXBPEWvfXgeBoMrHxMojaYEodYZ0JzKVOoDfMAeB7y+1TLor1q4vBFY8VfF4ews4I7YAcQx/tP8Wum+ofsvHCMNDL3sNIRnFicjWsJFG8EaXG8hfAVXtHZZw9wcrwupeGQEEML8LbjY68xY8dA+nOj23sPjoRPhpRIh0Nt6tYEqw3qwuNDzHOtnXyX0U6RT7PxCzwsQGID6EpIBqUdQdSL6Eajxr6W6IdK4Now9pEbOAO0iJGeMnde29TY2YaG3gQA31KUoFKUoFKUoFKUoFKUoFKUoFc72nts4raTRXthsCjyvyaWMaFuaqToPxITwFTTpBtD7Ph5ZeKqcvix0Ue5Fcs6NbLzYGbOcv2qZxLJxGGgGaU+rdoPWghOJ2oMIr7QYXmxBf7KrWNgfixLA+JIUcTc7qv7F6vJ8bhDMjFsSwWZlZh94shcDvHc/cLC5sQeG+td0x2bJLj8xjbs3WMRJfREsBCgHDuZCRzY8a+hOi2zxCuW25UH+UW4UHAOknQyTZ0aNimRWe4CqcxFgN5AsDqN16xurTYz4jtuyQyMCLDNlA0JzHQ3tpYaaka1vevbbBnkhQfCO0I8R2jop9RED61hbF2VG0xjglbDolmaVjmEZS2d7ra652A13DUnfQde6vNmvHCwcRgdoxyKzEKQAPh46BTqTvB41AehCZMRiFABdWcrfRQplyqtsp1bQgW57rV1DotsTFYct2+IimuiqGVCjEJ8GYZipIBIuLaWHAVAcIww+1mgYayzynT5USBTC3uWH+Kgs9aWyMjwTHKe2kCPZdEsODfFvJ18xaoj0rw3ZYiHCsLBUZzc3B+7c5tf5RwrsvSDACa8TgHuZ4+NpEBuR6H86gXTDZZfb+GjtpJhHt5/Z8SPzAoIJsLGGBjHIheCXNFPH+Ix6sFPBxmV0PM24mpt1odGckOFxmFcyQdhFESAPhjW8bm3BgxvfiBzrXdOcNEXiSOMK7wI5ddD2kQuhbhrGJBfeSEHCpH1WbSXF4afZeI0DqzRjXc2sijkASrr4MwHwUHMdv4qN3jZECqYluB+MFgxv6D6+dZewMG+JQ4cSAIokkjznQOApdAflzLduV04XJrV7ewDYfESQPvRiv7Gsropj+wmGb4WsACL3OYWHkQSPI0GVslm+/wgCkTKVQOBbtIczLb8JY3W4/ENazOgfSJsE0cg+AlsjG9wlwHRgPiA0uOAKsoB37/AKNdHGxODx2TSaLEnsr71kgVSDr+MNY+QPlpsJgkZyWUdg80E4XdlXF54MTH/CY5VVfDsxzoPovZePSeJJUN1YAjW+/xG/z41lV899XXTVtn437FI4bCySFbm/3bMbJIPAki48b87/QlApSlApSlApSlApSlApSlBDutHFhMKgJtmkHrlR3P+moxtLEZlweyYh97KsZxBH/LRz2zr4E6k+AHOsrr0uYMPlPejkMoHMIAjXH/ANlc32PtpxtCOW+Z1kZhcnV2GW/rmIoOl4LZAxWOTEsgEUeInRLb3aPOFb+RRCviWPIazeSfsklc/Irn/ICfysag22ekIwkWDSLXKZRmI3lWWN3PmWkPjvqQY3aIxGzsRMhF2gmW3JsrBb+NiKDhOPftcdCZAGXC4WB3B+YxQIWHrKcvrUu6vsKC4imAPb7NxDtpa6yzmxt/JlrVYbYMmJkxYjGuJxEcCHfljJM0rHkoQRny866DtDYz4XamHmCH7OMFLCz27oKAsA3K4UflQY3VJ0rcGXZWKYtPhcwib+9iTQAeIFiOakcjWN1qYYRYvCY+MjLIBG511BtZt/4GP+UcqgXT7Dy4XHR4uA2cFZEcbrAi1zuK778LEg6VPNv7RXF7KkzRFcimYKT3o2ExjmQHdZCxtzUrQTWaRWjSVbnsyLEa3QnKfS16jHTV0h2tsrFy92JlmhL8AzowjB5X7Q+xrI6ott/aMLFGwAZVIAB3xxkIrHkSedWOtLEw4jC4cSC0bYiRbi2ZCiyIGXxB1oOVdINps0rZ1ytAoijtc/f4aRSSwG9cquTfmKzsDMyGPEwD7yBg6gXN43uyrzJF5EtxAccRUd2ckg2iisAztKIzfQMZj2RJ5Ah71OMBsMQYt8GGaSNfupJCtsrsocHwUN2qgn+9HMXC31wYHtnw20IrGLEqFJA+GRb906Xva414qahUWCMsXcH3i3ItvYrvA8bbh4aVPZMflwWJwMx73aGXDsTfJLG7HKT8veRd/Fzzpsfo9mxDODkjBViSLACRS9hzNiunJheg2HU5twFsQjnvSLBIuo7xVOxlOv8AFFr51Z6y8MmGw8wjF+1lV0tujZpI5Zlv+EtFnHIuw0G/XYyeOLa0MkKjIqZCLaMygliTpbSYXPgazunEvbYKQjUZkbmNHB3271t3LT5hrQcx6SoBOSDmzBHuNAe0UPp4a19Q9AdrnF7Ow07G7tGoc83TuufUqT618rbUU9q2bU34+Fd96g9oh8A0PGGQ6eDgEfUNQdMpSlApSlApSlApSlApSlByTrrndJ8I4N0UMHS18yyEf/j61zBg0Euew35kccr3Vr8dw9bjhU969dp9niEj/FEv0dz/ANX0rlOIvZSeNz4W03fWgnHSvbqTyLHGV7KELHGb3zBL3YnxNtazeifSgLDPg3fKZ8givwkd1X2sb/4a5mKob1oO6dWa/wC75J4Zh2qGRjBiEuxe5VJFMYGZWHZpmFtLW3AE73b215H2XtHUiXDfaEuRr3Rmjax/9tlNQXo90sywx4xmOVikGNtqUlUAQ4sKN5O5gN4IGuUCt51g4nJBi2DALOrPodHBwJizAjeC7IPSg5Z0P2mX2jDFiy0sc98PKHJOZcR3VIJ3WYowbhaui7IjaNdo7PluzJBKyOfmikgKh/UwwkjgzNyrjEEhfs7aSJqjDfp3h7EV3tpxN2eMQraXBzm9xcJJEWkjYbxaYKwP/wAg5WCNdVe0zgtj7Qx2mZSEizfCXygILcRnlF/KsfpxtKNcFgQHZlmabEpcagSZTlNuIZ3HkKgx6QE7NXZ6Xt24lLDc10y5T5NY1ldMdqLKuCjXRYMMiW8SxJProaC0drKmIjmse0jINiLd5d3kRofMCt50y6dmfERzYdzFmiDSlTZhKxTMpsLWQRIF36a8agrHUHyr2NdToDdTQSh5WkhkZnLMzqosR96C+VpAeBIYAnTVOdTbaXSqH+wUEBLI10PdYLYIM1gzWW1yQO781c3faarhYIhqw7xOuhEsjADx7+u7cN9Yb7RZiWZiSWLb+JNz7m3tQSbaOJWedmBygCM68rspNuNj2ZO7duFhUlw0/bYN420YXRhyNv6Nc5XH2dXHC4PiGqQ4PbYVr30YBW8cvwH6ke1BpOkkWXEuP5Pqi3+t66D/ALPeOyYueI7pYwR5xsxH0dqgm35VkdXHEWPmGNvo30qW9SrgbVjAtrDKfoun50H0VSlKBSlKBSlKBSlKBSlKD5+688h2gLuwdY0sLXU7zv3qdfKoUkKNYfCWBOQ6ob/Mh3ofcVLOu+Qf71ZSCfuYbW3g9+/n5flUEDsABe6i1uY8uXlQUOjglWIBH18RVLLWW5zb9fzqhhoNN3HnQZvRraKwu6S/2E69nL/CD8Mg8UJv6msbbGJxMathJJHyxkrk+WxbPp/Cxs41tqKxyovqDbzFX8diRKq5rlkAQE2uUHwg87bh4WHCg1WGfKQRvUhl8wb10vYO2Fk2XNhwe9AJ8njHMjnU79DK4t/CK502EG8HzFZOyMeIWe+5lK28/Kg1cRtXt68QVdyXoLDE0znnV84YcZFFeDDx/jY+S/vQYrN41Ur1lps8NopN+RKAnyuwvXsuzmQgMQPO1/oTQeYWBn3Lcen61vMLhsq5SB41jYaNFXTMfLNqfIVmbOhkmfJGmQcWkJ+ii7E+AFBW+ARge7r4EipJ1MwAbYQX+COf3yqOP81a3F4JYAczNIwvoAVTS2+3eYajlqQOYrY9TUg/3vE3F1xC+NhGjAn6+1B9G0pSgUpSgUpSgUpSgUpSg+fuufDkbUMpGhjVRfccqgn2zfWoLJh8+crw7xGu7S53cLgnzPKugdceLSedXQgiOSeFrb8yCAm/uR/hNRTojiFTEwGS5TN2Uo5pNeM38PvL+lBowCOFerY+tX+kOznwuJlw7k5oXKBjvZAbxt6qQfWsFZrGgqaqSK9m36buFW6C9GapeMcLeRAt/XrVKHWmbgaDHaNQdbqfI2/M1SYQd0g9autcbjpy31aZQfCgobC2+ZattEeYPrV0rXmWgtqlZ0e0nXcE9UX9qsBa8IoNzsvFzzyCPMddAFXUnflAA3+h8jUrhRIZmshZYB2fZg3bE4uXdESN+UWLDvAHwq30NkjiwcmI7NTiBK0cZJOVRkRybE2Frm7bzYCtnh4IMJhnxGKmCylHGFizfekyf2uIIHwySEmxPwrbdwCJba2h3jEzBmdh2hUaWB+BB+Bbtb8V83zGt51TYq+2YnAIVnxNhe+XOklh4bgKh8Km7TnKDdsg4Fz3UC/wqWFv5DyqY9ENlfYdq4LDkgyiRe0a91BeMkoD4bvMmg+kaUpQKUpQKUpQKUpQKx9o4sQxSStujRnPkqkn8qyKhnW5jjFsyULbNKUiA59owDD/AChqDhP2svhnWXWR52xBPIzK2f8A0p7GrJwtsP2oO+XsnA4B0zRP4XKyj/CK9xd2zNxZSfUW9tGq5hcUq4fFRN86xlf545VP5NJbyNBuOsSEzw4THk96SFFkJvcugswFhbQ5t+unGoNkvz9qn3RnGLi8DJgGvnTO8Wu+5LEedyagIUgkHeLj2oL0Av3d993ieXgeVUNER/5H76HwqkGstvvELfMvxi28fj/f3oMMjUVTJo1VS7gbVROdb0HjGqb169U0HhNeUoKD0mvYhc/l51RWVFCfgA7x38lXj/X70HqYqUqYlYiMksR8tyACT/lX2FeqwN1QFhxJHekYmygcQCSPH8qt4iUfAnwjeeZq9s7F9ge1AvItil9ytrZyOJXeBuva+61BN9iYSFWuy5xhRZSSFUtHcMddO9O0xBO4LUan6TyNio50jHbCZZFIJ71pMyL7aX434Vb2rti2HTDxnu5UaVj80hGYoDxUMzEniSeA1ydgYLs80jDNIqPK4O6KJELBDwzyGy5flVuZ0D6tia6g2tcA25X4VXWl6GbWGLwOGxAOrxrm1vZ1GVx6MGHpW6oFKVxTpf00xM8rJFK8MKkhQhys1j8TMNdeQOnjQdmnxKILu6qObED861OL6W4GP4sVF/hbOfZL1wRlZzd2LHmxLH3NDDUHZMV1l4FPhMkn8qEf68tajEdbkI+DDSH+Z1X8s1cwMIqjsKUT7Fdbsx/s8NGP5mZvyy1F+k/THE48IsyxBY2LKEVhclSveu5vox5Vq+wqtMPQYAB/CvsTzvvPia8fD33hNf4E/atgYbVWkQqUYeCwzKQy90jcVAB9wKrl2bG/xpqTfMNG99x9Qa2KmqZWqiN47o8wN4nDj8J7rj37re48q1wV42BIKniCLacdDwqUuKrRQwswDDkdfzpRFMXhtCyi6nX+W2/0rANTR9kJYqpK3BH4gLjxN/rWjn6MYhfhCyfyNr/lax9r1aNOaoNXZoyjZXUqw4MCD7HWqCKCivbV6BXoQkgDedw4mgvYJLnQXPyjx5nwG/2q/ItlKrr+J/xHkPCszD4UIlvmPxft5VZbDs5sNfAcPM7h/WlBrswGg1NZeLwPZBQxUuwuwBuE/hJGl+fL0NXXwqJvIJGpC7h5sd59qwZnZzYDU/ReFBiSvrccN3pxrc4faci4HEI2W0piA/Fo2dj5HIPY1qTHrYWPiN1ZGDwrTSxQ31kdVJ5AkD6C9B3zqCxr/ZJMLILNAysNdSuIXtRpw3/Wuo1wXoHt9cPt+RGFkxKRRDgFYRoY/cqV9a71QRTrIxkkWFDx4lYGDcTYyAA3RW3g8fSuA7RxGISRpH+9ViS+lnF9S38X5Hw3133rA6MjGRBxIEaIMRmNkINibn5d2+uF4jPEx/5kRv8ACQSuurRsDZhxye1qgYbFqyhka6n6eBHA1lxzA1p58FcibDuATxHwSW+VhwPnu+tMJjs7ZCMkg3oePip4jw/Og3mhplrDhlrMBvQe7qqBq0TVBeoq/QVj9p/V6vRoTRF4CqWWq1hPOrohoMXsqqVLVfMXiBWFLtKBTbNnb8Ka0GQB4VdMVhdu75kD6amo/jOkrrcKI4RzY5nPoNfzqP47aysbs0kvPMcq+1rH1ApBMsXtaIgxt98PwhQwHq2i+dxUY2k+EOqjsj4O0g8iAth6Ma0k2PdtNw5C9h5A3A9BVuCZQe8mcfzEfUVRkk1nYKMrrbXieQ5VkptWBrkwgBRobWbla43+tU4bFKy5h3R4628qovNYC8jWHBRe5/U/Tyr0zMwsB2UY4nQ+wrF+1quoGvM/Eb+fwisTFylj943ki6/X9aBLKCcoNl48z51b7VddCQeANs3Aa8hpoOXGrRcHQLbw3n151X9nfl7/ANaUHid0W41JOrzC58WZTbLChOv4muq/r7VGhhieZPIC/wD2HvUi2JtWTBwOsKL20jXMjm4jCiyhV3E7zc8+NB502R1xwkRshbKyHUENGqkHUaa2r6e6NbWGLwsGJUWEsatbkSO8PQ3HpXyFtLaMk7KGIdwfi1uxPMnfX0D/ALP+0A2z2gaRS8crnJmBYI9muRfcWLUG/wCsnaMC4V4ZJhG7gMoysxIRgdQoJANrXrhELB7yYeTS/fjbcT/EN6H+IV3LrA6NnEqHQDOo08RyvXFNq7GKuWGaKVfmGh8mHzCoMMA5iYxlfe8THuuOdx9HGvMUnhjnXUG6+jxnh6ab9xr1pwbLOuRge7Ivwk8wf+WfPSvJkKkZjlbcsoGhv8rjdY+x8DRWOuMeEhZtVOiyj6Bx+v51t45beu7kQawxJmvG6gHivysOa3/07x476wWgeDWLvxbzGd688p/r1ojePJXgNa6PaKlDIDdRv/EDyI51pptvSX0JUfhW1wPFiDr5Cgl8UV+NXzIifE6jzYD86gT7YkfS8h/xn/pAFWAxGuVB4m7H6k0ipxN0mw6aBi55KCfqdKxcR0la2irGp+Zzmb0Rf1NRMYtwLZ2t/DZR7irQQnULfxsW+p0ojb4jbefg8p/jOVfRE/esDEY6Ru6SEX8K2Uey6n1NWjA53kDwLfoK9+zqN7X8gF/PX6UFjsx4n6D9TXhKjgPqTWR935nxzH9qGdRuUX8FX9b0GKNeF/pTsid27nV53LG5t4bifYVWiX3gnz/YX/SgphTN3VF7a67vP/tWQYJNxUm3lb6Uw+JZGtH8R0AUXJvpa2tfRPQLoSjYGBsbAv2gqS3A2JJTMBubLa/jQfOowcpNzp+lVps62+5/rwr6pPQjBf3C15/wNgv7lao+XR3dBp6VQZ14m/mf03V9Tf8ABGC/uFoOg+B/9OnsKD5a+2rzFGJk0yu1+AVj+Qr6qXodghugQegrIh6O4Zd0S+1B8ybJ6G4qf+xw0l+FxkHqZLV1vo91Qdg6YlcdNFOAf7MIQuYEFQWXvCxO8eNdRhwyr8KgVdoKWW9RXpX0SjxKkgWcbj+h51LK8NB857c2K8DFJF/ZhUeeN4R3Bnj4xk6qP4D+hr6U2/sCPEoVZfI8R5VxrpN0Zkwr6gleDfvUEMjKSL93dkG9NzxnmvLy3ciNxuRTkak3H493o44Hx9wOPuN2dc51JSQbmHHwI41rTjTmyyfdy7swHcfkGHLx9rUFza0cRu2qsdO783gRuP8A2rTohHdCajefi18/hFVYzF5iPlZDuGq6cvDw10qy2JY213fTy5elBe7Mnebeo/r2Br3uDxPt9WufYCsUAndc+Q/U172fl73PstBkfa8puqqDzClj7yXsfEWqzJiXbffzJ/bSgi8/ov53NVCHwHqCf9RAqiz2njfy/YfvQoeVvM2rJUC28+Q3fS1FAvouv9ctaDGER5+w/oVdTDDjr/X9ca3OzujuLnI7OBjfiRYe7a/SplsfqgxcusrqgPAC59zp9Kg5wBwFh/X9bwarhgL6KrMeQ1+g0+ld82N1NYWOxlLSHxOnsKm2y+ieFgA7OJR6CqOH9EOgUzyI7JIACCCGKEe1fQGzo3CgPvtWUkYGgAFV0ClKUClKUClKUClKUClKUHlYG1NmJMpVlBvzrYUoOKdLOhzQksgunLlUB2hs9XGVxfkeIr6ixOGVxYiud9LOgma7xDXkKD56xezVjJBkB5Ab/Xl5a1SsYXkPMC/1ufoKkOI6CY1JCBCzb7MNN58tDrWy2b1V42Ui6Kn81yfraoIYxB3kk+p/PT6Uz8hbzP6D9q7HsvqUOnbSk+A0H0FTLZHVbg4bfdgnxoPnXCbNnlNo43N/wrYfWpRsjqxx0xuUCA87k+1fRuC2JBELLGB6VsFQDcKo4zsfqUXQzyM3hew+lTnZHV3goLZYVvztr71L6UGLh9nxp8KAelZIFe0oFKUoFKUoFKUoFKUoFKUoFKUoFKUoFKUoFeGlKDHKC+4e1XYxSlBcpSlApSlApSlApSlApSlApSlApSlApSlApSlApSlB/9k=" alt="Saco de lixo 200lts com 100un">
                        <span class="product-badge">Atacado/Varejo</span>
                    </div>
                    <div class="product-content">
                        <h3 class="product-title">Saco de lixo 200lts com 100un</h3>
                        <p class="product-description">Sacos de lixo super resistentes para uso industrial, pacote com 100 unidades.</p>
                        <div class="product-meta">
                            <div class="product-pricing">
                                <span class="product-wholesale">Atacado: Consulte</span>
                                <span class="product-retail">Varejo: Consulte</span>
                            </div>
                            <span class="product-availability">Disponível</span>
                        </div>
                        <div class="product-actions">
                            <a href="#quote" class="btn product-btn">Solicitar Cotação</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="text-center mt-5" data-aos="fade-up">
                <a href="#quote" class="btn">Ver Catálogo Completo</a>
            </div>
        </div>
    </section>
   <!-- Quote Section -->
    <section id="quote" class="quote section-padding">
        <div class="container">
            <div class="quote-content">
                <h2 data-aos="fade-up">Solicite uma Cotação</h2>
                <p data-aos="fade-up" data-aos-delay="100">Preencha o formulário abaixo com seus dados e produtos de interesse. Nossa equipe entrará em contato em até 24 horas com sua cotação personalizada para atacado ou varejo.</p>

                <div class="quote-form" data-aos="zoom-in" data-aos-delay="200">
    <h3 class="form-title">Formulário de Cotação</h3>

    <form action="send_email.php" method="post" id="quote-form">
        <div class="form-grid">
            <div class="form-group">
                <label for="name" class="form-label">Nome Completo / Empresa</label>
                <input type="text" id="name" name="name" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="email" class="form-label">E-mail</label>
                <input type="email" id="email" name="email" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="phone" class="form-label">Telefone</label>
                <input type="tel" id="phone" name="phone" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="type" class="form-label">Tipo de Compra</label>
                <select id="type" name="type" class="form-control" required>
                    <option value="">Selecione</option>
                    <option value="atacado">Atacado</option>
                    <option value="varejo">Varejo</option>
                    <option value="ambos">Ambos</option>
                </select>
            </div>

            <div class="form-group full-width">
                <label class="form-label">Produtos de Interesse</label>
                <div class="checkbox-container">
                    <!-- Produtos de Limpeza -->
                    <h4 class="checkbox-category">Produtos de Limpeza</h4>
                    <div class="checkbox-group">
                        <input type="checkbox" id="prod1" name="products[]" value="Desinfetante 5lts">
                        <label for="prod1">Desinfetante 5lts</label>
                    </div>
                    <div class="checkbox-group">
                        <input type="checkbox" id="prod2" name="products[]" value="Amaciante 5lts">
                        <label for="prod2">Amaciante 5lts</label>
                    </div>
                    <div class="checkbox-group">
                        <input type="checkbox" id="prod3" name="products[]" value="Alvejante sem cloro 5lts">
                        <label for="prod3">Alvejante sem cloro 5lts</label>
                    </div>
                    <div class="checkbox-group">
                        <input type="checkbox" id="prod4" name="products[]" value="Água sanitária tipo q boa 5lts">
                        <label for="prod4">Água sanitária 5lts</label>
                    </div>
                    <div class="checkbox-group">
                        <input type="checkbox" id="prod5" name="products[]" value="Sabão líquido lava roupa 5lts">
                        <label for="prod5">Sabão líquido 5lts</label>
                    </div>
                    <div class="checkbox-group">
                        <input type="checkbox" id="prod6" name="products[]" value="Multiuso 5lts">
                        <label for="prod6">Multiuso 5lts</label>
                    </div>
                    <div class="checkbox-group">
                        <input type="checkbox" id="prod7" name="products[]" value="Hipoclorito 5lts">
                        <label for="prod7">Hipoclorito 5lts</label>
                    </div>
                    <div class="checkbox-group">
                        <input type="checkbox" id="prod8" name="products[]" value="Álcool perfumado 800ml">
                        <label for="prod8">Álcool perfumado 800ml</label>
                    </div>

                    <!-- Papéis e Descartáveis -->
                    <h4 class="checkbox-category">Papéis e Descartáveis</h4>
                    <div class="checkbox-group">
                        <input type="checkbox" id="prod15" name="products[]" value="Papel higiênico 300mts">
                        <label for="prod15">Papel higiênico 300mts</label>
                    </div>
                    <div class="checkbox-group">
                        <input type="checkbox" id="prod16" name="products[]" value="Papel toalha interfolha">
                        <label for="prod16">Papel toalha interfolha</label>
                    </div>
                    <div class="checkbox-group">
                        <input type="checkbox" id="prod17" name="products[]" value="Papel toalha bobina 200mts">
                        <label for="prod17">Papel toalha bobina 200mts</label>
                    </div>

                    <!-- Sacos de Lixo -->
                    <h4 class="checkbox-category">Sacos de Lixo</h4>
                    <div class="checkbox-group">
                        <input type="checkbox" id="prod20" name="products[]" value="Saco de lixo 20lts com 100un">
                        <label for="prod20">Saco de lixo 20lts - 100un</label>
                    </div>
                    <div class="checkbox-group">
                        <input type="checkbox" id="prod21" name="products[]" value="Saco de lixo 40lts com 100un">
                        <label for="prod21">Saco de lixo 40lts - 100un</label>
                    </div>
                    <div class="checkbox-group">
                        <input type="checkbox" id="prod22" name="products[]" value="Saco de lixo 60lts com 100un">
                        <label for="prod22">Saco de lixo 60lts - 100un</label>
                    </div>
                    <div class="checkbox-group">
                        <input type="checkbox" id="prod23" name="products[]" value="Saco de lixo 100lts com 100un">
                        <label for="prod23">Saco de lixo 100lts - 100un</label>
                    </div>
                </div>
            </div>

            <div class="form-group full-width">
                <label for="message" class="form-label">Mensagem / Detalhes</label>
                <textarea id="message" name="message" class="form-control" rows="5"></textarea>
            </div>
        </div>

        <div class="form-submit">
            <button type="submit" class="btn">Enviar Solicitação</button>
        </div>
    </form>
</div>
            </div>
        </div>
    </section>
    <!-- Testimonials Section -->
    <section class="testimonials section-padding">
        <div class="container">
            <h2 class="section-title" data-aos="fade-up">O que Nossos Clientes Dizem</h2>

            <div class="testimonial-slider" data-aos="fade-up" data-aos-delay="100">
                <div class="testimonial-track">
                    <div class="testimonial-slide">
                        <div class="testimonial-card">
                            <div class="testimonial-content">
                                <p>Utilizamos os produtos da WK em nossa rede de hotéis há mais de 5 anos. A qualidade é incomparável e o atendimento é sempre impecável. Recomendo fortemente!</p>
                            </div>
                            <div class="testimonial-author">
                                <div class="author-avatar">
                                    <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=60&q=80" alt="Avatar">
                                </div>
                                <div>
                                    <div class="author-name">Ricardo Mendes</div>
                                    <div class="author-company">Gerente de Compras - Rede Astória Hotéis</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="testimonial-slide">
                        <div class="testimonial-card">
                            <div class="testimonial-content">
                                <p>Produtos de excelente qualidade e durabilidade. Conseguimos reduzir nossos custos em cerca de 30% desde que começamos a comprar com a WK. Entrega sempre no prazo!</p>
                            </div>
                            <div class="testimonial-author">
                                <div class="author-avatar">
                                    <img src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=60&q=80" alt="Avatar">
                                </div>
                                <div>
                                    <div class="author-name">Carla Oliveira</div>
                                    <div class="author-company">Administradora - Condomínio Villa Real</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="testimonial-slide">
                        <div class="testimonial-card">
                            <div class="testimonial-content">
                                <p>O atendimento diferenciado e a flexibilidade nas negociações fazem da WK nosso parceiro ideal. Os produtos são de altíssima qualidade e o suporte pós-venda é exemplar.</p>
                            </div>
                            <div class="testimonial-author">
                                <div class="author-avatar">
                                    <img src="https://images.unsplash.com/photo-1568602471122-7832951cc4c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=60&q=80" alt="Avatar">
                                </div>
                                <div>
                                    <div class="author-name">Paulo Resende</div>
                                    <div class="author-company">Diretor - Resende Facilities</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="testimonial-nav">
                    <button class="testimonial-btn prev-btn">
                        <i class="fas fa-chevron-left"></i>
                    </button>
                    <button class="testimonial-btn next-btn">
                        <i class="fas fa-chevron-right"></i>
                    </button>
                </div>

                <div class="testimonial-dots">
                    <span class="testimonial-dot active"></span>
                    <span class="testimonial-dot"></span>
                    <span class="testimonial-dot"></span>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact Section -->
    <section id="contact" class="contact section-padding">
    <div class="container">
        <h2 class="section-title" data-aos="fade-up">Entre em Contato</h2>

        <div class="contact-container">
            <!-- Informações de Contato -->
            <div class="contact-info" data-aos="fade-right" data-aos-delay="100">
                <h3 class="contact-info-title">Informações de Contato</h3>

                <div class="contact-detail">
                    <div class="contact-icon">
                        <i class="fas fa-phone"></i>
                    </div>
                    <div class="contact-text">
                        <h4>Telefones</h4>
                        <p>(41) 3283-7121</p>
                        <p>(41) 9 9725-6352</p>
                    </div>
                </div>

                <div class="contact-detail">
                    <div class="contact-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <div class="contact-text">
                        <h4>E-mail</h4>
                        <p>WK.KARLA@HOTMAIL.COM</p>
                    </div>
                </div>

                <div class="contact-detail">
                    <div class="contact-icon">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <div class="contact-text">
                        <h4>Endereço</h4>
                        <p>Rua Tiradentes, 406</p>
                        <p>CEP: 83.050-220</p>
                        <p>São José dos Pinhais - PR</p>
                    </div>
                </div>

                <div class="contact-detail">
                    <div class="contact-icon">
                        <i class="fas fa-building"></i>
                    </div>
                    <div class="contact-text">
                        <h4>CNPJ</h4>
                        <p>30.459.625/0001-87</p>
                    </div>
                </div>

                <div class="social-links">
                    <a href="#" class="social-link"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="social-link"><i class="fab fa-whatsapp"></i></a>
                    <a href="#" class="social-link"><i class="fab fa-linkedin-in"></i></a>
                </div>

                <div class="contact-map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3598.5723993917765!2d-49.20772032452552!3d-25.535249241736723!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94dcf0b8f14c57e3%3A0x1a983c159bb03dad!2sR.%20Tiradentes%2C%20406%20-%20S%C3%A3o%20Jos%C3%A9%20dos%20Pinhais%2C%20PR%2C%2083050-220!5e0!3m2!1spt-BR!2sbr!4v1713490897886!5m2!1spt-BR!2sbr" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
<style>
    /* Correção para os títulos da seção de contato */

/* Título principal da seção de contato */
.contact-info-title {
    color: #212529 !important; /* Preto */
    font-weight: 700;
}

/* Subtítulos (Telefones, E-mail, Endereço, etc.) */
.contact-text h4 {
    color: #212529 !important; /* Preto */
    font-weight: 600;
}

/* Textos de informação de contato */
.contact-text p {
    color:rgb(240, 240, 240) !important; /* Cinza escuro */
}

/* Ícones de contato */
.contact-icon {
    color: #005294 !important; /* Azul primário - mantendo apenas os ícones azuis */
}

/* Título da seção geral de contato */
.contact .section-title {
    color: #212529 !important; /* Preto */
}

/* Adicione essas regras para garantir que o texto seja visível em todos os temas */
.contact-container {
    background-color: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

/* Melhorias opcionais para o visual da seção de contato */
.contact-detail {
    border-bottom: 1px solid #e9ecef;
    padding-bottom: 15px;
    margin-bottom: 15px;
}

.contact-detail:last-child {
    border-bottom: none;
}
</style>
            <!-- Formulário de Contato -->
            <div class="contact-form" data-aos="fade-left" data-aos-delay="100">
                <h3 class="form-title">Envie uma Mensagem</h3>

                <form action="send_email.php" method="post" id="contact-form">
                    <div class="form-group">
                        <label for="contact-name" class="form-label">Nome</label>
                        <input type="text" id="contact-name" name="contact-name" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="contact-email" class="form-label">E-mail</label>
                        <input type="email" id="contact-email" name="contact-email" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="contact-phone" class="form-label">Telefone</label>
                        <input type="tel" id="contact-phone" name="contact-phone" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="contact-subject" class="form-label">Assunto</label>
                        <input type="text" id="contact-subject" name="contact-subject" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="contact-message" class="form-label">Mensagem</label>
                        <textarea id="contact-message" name="contact-message" class="form-control" rows="5" required></textarea>
                    </div>

                    <div class="form-submit">
                        <button type="submit" class="btn">Enviar Mensagem</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- Adicione este CSS para corrigir a exibição em dispositivos móveis: -->
<style>
/* Estilos para a seção de contato */
.contact-container {
    display: flex;
    gap: 40px;
}

.contact-info,
.contact-form {
    flex: 1;
}

.contact-detail {
    display: flex;
    margin-bottom: 25px;
}

.contact-icon {
    min-width: 40px;
    height: 40px;
    background-color: rgba(0, 82, 148, 0.1);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 15px;
    font-size: 18px;
    color: var(--primary-blue);
}

.contact-text h4 {
    font-size: 18px;
    margin-bottom: 5px;
    color: var(--primary-blue);
}

.contact-map {
    border-radius: 10px;
    overflow: hidden;
    height: 200px;
    margin-top: 30px;
}

.contact-map iframe {
    width: 100%;
    height: 100%;
    border: none;
}

.social-links {
    display: flex;
    gap: 15px;
    margin-top: 20px;
}

.social-link {
    width: 40px;
    height: 40px;
    background-color: var(--primary-blue);
    color: var(--white);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    transition: all 0.3s ease;
}

.social-link:hover {
    background-color: var(--accent-blue);
    transform: translateY(-3px);
}

/* Ajustes responsivos */
@media (max-width: 991px) {
    .contact-container {
        flex-direction: column;
    }
    
    .contact-info,
    .contact-form {
        width: 100%;
    }
    
    .contact-form {
        margin-top: 40px;
    }
}

@media (max-width: 768px) {
    .section-padding {
        padding: 60px 0;
    }
    
    .contact-container {
        gap: 30px;
    }
    
    .contact-icon {
        min-width: 35px;
        height: 35px;
        font-size: 16px;
    }
    
    .contact-text h4 {
        font-size: 16px;
    }
    
    .contact-map {
        height: 180px;
    }
    
    .form-submit .btn {
        width: 100%;
    }
}

@media (max-width: 576px) {
    .section-padding {
        padding: 40px 0;
    }
    
    .contact-detail {
        margin-bottom: 20px;
    }
    
    .contact-map {
        height: 150px;
    }
}
</style>
    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-top">
                <div class="footer-col footer-about">
                    <h3>Sobre Nós</h3>
                    <p>A WK Produtos de Limpeza é uma empresa especializada no fornecimento de soluções completas em higiene e limpeza, atendendo clientes no atacado e varejo com produtos de alta qualidade.</p>
                    <div class="social-links">
                        <a href="#" class="social-link"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-whatsapp"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>

                <div class="footer-col footer-links">
                    <h3>Links Rápidos</h3>
                    <ul>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Início</a></li>
                        <li><a href="#about"><i class="fas fa-chevron-right"></i> Sobre Nós</a></li>
                        <li><a href="#services"><i class="fas fa-chevron-right"></i> Serviços</a></li>
                        <li><a href="#products"><i class="fas fa-chevron-right"></i> Produtos</a></li>
                        <li><a href="#quote"><i class="fas fa-chevron-right"></i> Cotação</a></li>
                        <li><a href="#contact"><i class="fas fa-chevron-right"></i> Contato</a></li>
                    </ul>
                </div>

                <div class="footer-col footer-links">
                    <h3>Produtos</h3>
                    <ul>
                        <li><a href="#products"><i class="fas fa-chevron-right"></i> Produtos de Limpeza</a></li>
                        <li><a href="#products"><i class="fas fa-chevron-right"></i> Papéis e Descartáveis</a></li>
                        <li><a href="#products"><i class="fas fa-chevron-right"></i> Sacos de Lixo</a></li>
                        <li><a href="#products"><i class="fas fa-chevron-right"></i> Álcool e Higienizadores</a></li>
                        <li><a href="#products"><i class="fas fa-chevron-right"></i> Acessórios de Limpeza</a></li>
                    </ul>
                </div>

                <div class="footer-col footer-newsletter">
                    <h3>Newsletter</h3>
                    <p>Inscreva-se em nossa newsletter e fique por dentro das novidades, lançamentos e promoções especiais.</p>
                  <div class="newsletter-form">
    <form action="send_email.php" method="post" id="newsletter-form">
        <input type="email" name="newsletter-email" class="newsletter-input" placeholder="Seu e-mail" required>
        <button type="submit" class="newsletter-btn"><i class="fas fa-paper-plane"></i></button>
    </form>
</div>
                </div>
            </div>

            <div class="footer-bottom">
                <p class="copyright">&copy; 2025 WK Produtos de Limpeza. Todos os direitos reservados. | Desenvolvido por <a href="#" style="color: var(--accent-blue);">LFM TECNOLOGIA</a></p>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <a href="#" class="back-to-top" id="back-to-top">
        <i class="fas fa-arrow-up"></i>
    </a>

    <!-- WhatsApp Float Button -->
    <a href="https://wa.me/5541997256352" class="whatsapp-float" target="_blank">
        <i class="fab fa-whatsapp"></i>
        <span class="whatsapp-tooltip">Fale conosco pelo WhatsApp</span>
    </a>
    <!-- JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script>
        // Inicializar AOS (Animate On Scroll)
        document.addEventListener('DOMContentLoaded', function() {
            AOS.init({
                duration: 800,
                easing: 'ease-in-out',
                once: true
            });

            // Mobile Navigation Toggle
            const mobileNavToggle = document.getElementById('mobile-nav-toggle');
            const navMenu = document.getElementById('nav-menu');

            if (mobileNavToggle) {
                mobileNavToggle.addEventListener('click', function() {
                    navMenu.classList.add('active');
                });
            }

            // Close mobile nav when clicking outside
            document.addEventListener('click', function(e) {
                if (!navMenu.contains(e.target) && !mobileNavToggle.contains(e.target)) {
                    navMenu.classList.remove('active');
                }
            });

            // Header scroll effect
            const header = document.querySelector('.header');

            window.addEventListener('scroll', function() {
                if (window.scrollY > 100) {
                    header.classList.add('scrolled');
                } else {
                    header.classList.remove('scrolled');
                }
            });

            // Back to top button
            const backToTopButton = document.getElementById('back-to-top');

            window.addEventListener('scroll', function() {
                if (window.scrollY > 300) {
                    backToTopButton.classList.add('active');
                } else {
                    backToTopButton.classList.remove('active');
                }
            });

            backToTopButton.addEventListener('click', function(e) {
                e.preventDefault();
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });

            // Product Category Tabs
            const categoryTabs = document.querySelectorAll('.category-tab');
            const productCards = document.querySelectorAll('.product-card');

            categoryTabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    // Remove active class from all tabs
                    categoryTabs.forEach(t => t.classList.remove('active'));

                    // Add active class to clicked tab
                    this.classList.add('active');

                    const category = this.getAttribute('data-category');

                    // Show/hide products based on category
                    productCards.forEach(card => {
                        if (category === 'all') {
                            card.style.display = 'block';
                            // Add fade-in animation
                            card.classList.add('animate__animated', 'animate__fadeIn');
                        } else {
                            if (card.getAttribute('data-category') === category) {
                                card.style.display = 'block';
                                // Add fade-in animation
                                card.classList.add('animate__animated', 'animate__fadeIn');
                            } else {
                                card.style.display = 'none';
                            }
                        }
                    });
                });
            });

            // Testimonial Slider
            const testimonialTrack = document.querySelector('.testimonial-track');
            const testimonialSlides = document.querySelectorAll('.testimonial-slide');
            const prevBtn = document.querySelector('.prev-btn');
            const nextBtn = document.querySelector('.next-btn');
            const dots = document.querySelectorAll('.testimonial-dot');

            let currentIndex = 0;

            // Set slide width
            function setSlidePosition() {
                testimonialSlides.forEach((slide, index) => {
                    slide.style.left = index * 100 + '%';
                });
            }

            // Move to slide
            function moveToSlide(index) {
                testimonialTrack.style.transform = 'translateX(-' + (index * 100) + '%)';
                currentIndex = index;

                // Update dots
                dots.forEach(dot => dot.classList.remove('active'));
                dots[currentIndex].classList.add('active');
            }

            // Initialize slider
            setSlidePosition();

            // Previous button click
            if (prevBtn) {
                prevBtn.addEventListener('click', function() {
                    if (currentIndex === 0) {
                        moveToSlide(testimonialSlides.length - 1);
                    } else {
                        moveToSlide(currentIndex - 1);
                    }
                });
            }

            // Next button click
            if (nextBtn) {
                nextBtn.addEventListener('click', function() {
                    if (currentIndex === testimonialSlides.length - 1) {
                        moveToSlide(0);
                    } else {
                        moveToSlide(currentIndex + 1);
                    }
                });
            }

            // Dot clicks
            dots.forEach((dot, index) => {
                dot.addEventListener('click', function() {
                    moveToSlide(index);
                });
            });

            // Auto slide (optional)
            setInterval(function() {
                if (currentIndex === testimonialSlides.length - 1) {
                    moveToSlide(0);
                } else {
                    moveToSlide(currentIndex + 1);
                }
            }, 5000);

            // Form Validation and Animation
            const forms = document.querySelectorAll('form');

            forms.forEach(form => {
                const formGroups = form.querySelectorAll('.form-group');

                form.addEventListener('submit', function(e) {
                    // Validate the form but don't prevent submission if valid
                    let isValid = true;

                    formGroups.forEach(group => {
                        const input = group.querySelector('input, textarea, select');
                        if (input && input.required && !input.value.trim()) {
                            isValid = false;
                            group.classList.add('error');

                            // Add animation
                            input.classList.add('animate__animated', 'animate__shakeX');

                            // Remove animation class after animation ends
                            setTimeout(() => {
                                input.classList.remove('animate__animated', 'animate__shakeX');
                            }, 1000);
                        } else {
                            group.classList.remove('error');
                        }
                    });

                    // If not valid, prevent form submission
                    if (!isValid) {
                        e.preventDefault();
                    }

                    // If valid, let the form submit normally to send_email.php
                    // The success message will be shown when redirected back with status=success
                });
            });

            // Add floating animation to product images
            const productImages = document.querySelectorAll('.product-image img');

            productImages.forEach(img => {
                img.style.animation = 'float 3s ease-in-out infinite';
            });

            // Smooth scrolling for navigation links
            const navLinks = document.querySelectorAll('.nav-link');

            navLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    const targetId = this.getAttribute('href');

                    if (targetId !== '#') {
                        e.preventDefault();

                        const targetElement = document.querySelector(targetId);
                        const headerHeight = document.querySelector('.header').offsetHeight;

                        window.scrollTo({
                            top: targetElement.offsetTop - headerHeight,
                            behavior: 'smooth'
                        });

                        // Close mobile menu if open
                        navMenu.classList.remove('active');

                        // Update active link
                        navLinks.forEach(l => l.classList.remove('active'));
                        this.classList.add('active');
                    }
                });
            });

            // Update active nav link on scroll
            window.addEventListener('scroll', function() {
                const sections = document.querySelectorAll('section');
                const headerHeight = document.querySelector('.header').offsetHeight;

                sections.forEach(section => {
                    const sectionTop = section.offsetTop - headerHeight - 100;
                    const sectionBottom = sectionTop + section.offsetHeight;
                    const scrollPosition = window.scrollY;

                    if (scrollPosition >= sectionTop && scrollPosition < sectionBottom) {
                        const id = '#' + section.getAttribute('id');

                        navLinks.forEach(link => {
                            link.classList.remove('active');
                            if (link.getAttribute('href') === id) {
                                link.classList.add('active');
                            }
                        });
                    }
                });
            });

            // WhatsApp button pulse animation
            const whatsappFloat = document.querySelector('.whatsapp-float');

            // Add tooltip functionality
            if (whatsappFloat) {
                // Add extra pulse animation on page load
                setTimeout(() => {
                    whatsappFloat.style.transform = 'scale(1.2)';
                    setTimeout(() => {
                        whatsappFloat.style.transform = 'scale(1)';
                    }, 300);
                }, 3000);
            }
        });
    </script>
</body>
</html>